#!/usr/bin/env python

import os
import re
import sys
import csv
import logging
import cx_Oracle
import common
from generate_sql_procedure import parse_markts_cycls_config


#def get_all_markets():
def get_query_result(query):
        query_answer = db_cursor.execute(query)
        answer = []
        for i in query_answer.fetchall():
            answer.append(i[0])
        return answer


def get_depend_markets(cfgpath):
        common.check_file_exist(cfgpath, True)
        common.info_output("Parsing config file markets_cycles_settings.cfg")
        m_c_info = parse_markts_cycls_config(cfgpath)
        result = []
        for i in m_c_info['MARKETS']:
            result.append(i.replace(' ', ''))
        return result


if __name__ == '__main__':
        script_directory = os.path.dirname(os.path.abspath(__file__))
        script_home_directory = os.path.dirname(script_directory)
        temp_directory = os.path.join(script_home_directory, 'temp')
        result_file = os.path.join(temp_directory, 'instr_exceptions.csv') 
        logs_directory = os.path.join(script_home_directory, 'logs')
        try:
            logfilename = str(sys.argv[1])
        except IndexError:
            logname = (os.path.basename(__file__) + '.log')
            logfilename = os.path.join(logs_directory, logname)
        with open(logfilename, 'w') as x:
            x.write('')
        logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.INFO, filename=logfilename)
        cfg_directory = os.path.join(script_home_directory, 'cfg', 'TradingCyclesSettings')
        ats_db_string = common.get_db_string('ATS')
        db_connect = cx_Oracle.connect(ats_db_string)
        db_cursor = db_connect.cursor()

        # Get list of ALL markets
        query = "SELECT MARKET_ID FROM ATSD_MAR_ALL"
        all_markets = get_query_result(query)
        
        # Get list of markets which start time depends on the exchange system start time.
        markts_cycls_config = os.path.join(cfg_directory, 'markets_cycles_settings.cfg')
        markets_from_timecfg = get_depend_markets(markts_cycls_config)

        # STEP 1. Take the list of markets which start time does not depend on the exchange system start time.
        except_market = [i for i in all_markets if i not in markets_from_timecfg]
        common.info_output('all_markets: ' + str(all_markets), logfilename)
        common.info_output('markets in the conf:' + str(markets_from_timecfg), logfilename)
        common.info_output('exception markets:' + str(except_market), logfilename)

        TB = {"-1": "NONE", 
              "0": "DARK1/M",
              "1": "Integrated/I",
              "2": "DARK2/C",
              "4": "Auction/A",
              "5": "BlockAuction/B",
              "6": "EU_DARK1/EM",
              "7": "EU_Integrated/EI",
              "8": "EU_Auction/EA"}
        TBval = {"Integrated/I": 0,
                 "EU_Integrated/EI": 0,
                 "BlockAuction/B": 0,
                 "DARK1/M": 1,
                 "EU_DARK1/EM": 1,
                 "Auction/A": 3,
                 "EU_Auction/EA": 3}
        SVval = {"Integrated/I": 5, 
                 "EU_Integrated/EI": 14,
                 "BlockAuction/B": 13,
                 "DARK1/M": 6,
                 "EU_DARK1/EM": 15,
                 "Auction/A": 12,
                 "EU_Auction/EA": 16}
        gtp_instrument_ids = []
        for marketid in except_market:
            common.debug_output('MarketID: ' + str(marketid), logfilename)
            # Find InstrumentID for this MarketID
            query = "SELECT INSTRUMENT_ID FROM ATSD_INS_EQUITY WHERE MARKET_ID = '{m}'".format(m=marketid)
            except_instrs = get_query_result(query)
            for instr in except_instrs:
                query = "SELECT LSEG_TARGET_BOOK FROM ATSD_INS_EQUITY WHERE INSTRUMENT_ID = '{i}'".format(i=instr)
                except_tb = get_query_result(query)[0]
                hr_tb = TB[str(except_tb)]
                common.info_output("EXCH InstrumentID: " + str(instr), logfilename)
                common.debug_output("RD TargetBook: " + str(except_tb), logfilename)
                common.debug_output("human readable TB:" + str(hr_tb), logfilename)
                common.debug_output("final value of TB:" + str(TBval[hr_tb]), logfilename)
                common.debug_output("final value of SV:" + str(SVval[hr_tb]), logfilename)
                exchid = 0
                ext = 0
                subid_todel = re.search('_[A-Za-z0-9]{1,}', instr)
                if subid_todel:
                    instr = instr.replace(subid_todel.group(0), '')
                for char in instr[::-1]:
                    common.debug_output(char + ": " + str(ord(char)), logfilename)
                    common.debug_output("ext: " + str(ext), logfilename)
                    exchid += ord(char) * 2**ext
                    ext += 7
                try:
                    gtp_instr_id = int(TBval[hr_tb]) * 2**61 + int(SVval[hr_tb]) * 2**56 + exchid
                    common.debug_output(str(TBval[hr_tb]) + "* 2^61 + " + str(SVval[hr_tb]) + " * 2^56 + " + str(exchid), logfilename)
                    common.info_output("GTP InstrumentID: " + str(gtp_instr_id), logfilename)
                    gtp_instrument_ids.append(str(gtp_instr_id) + "_3")
                except KeyError as a:
                    common.error_output("There are no TZ for this TargetBook: " + str(a), logfilename)
                
        db_cursor.close()
        db_connect.close()
        with open(result_file, 'w') as z:
            for gtp_instr in gtp_instrument_ids:
                z.write(gtp_instr + '\n')
