#! /usr/bin/env python

import os
import re
import pwd
import sys
import shutil
import datetime
import csv
import tarfile
import common
import logging
import cx_Oracle


if __name__ == '__main__':
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)

    tables = ['ATS_OFF_BOOK_TCR_1', 'ATS_OFF_BOOK_TCR_2', 'ATS_OFF_BOOK_TCR_3', 'ATS_OFF_BOOK_TCR_4',
              'ATS_PTTPS_PTGW_CLIENT_1', 'ATS_PTTPS_PTGW_CLIENT_2', 'ATS_PTTPS_PTGW_CLIENT_3', 'ATS_PTTPS_PTGW_CLIENT_4',
              'ATS_PTTPS_TP_TCR_MAP_1', 'ATS_PTTPS_TP_TCR_MAP_2', 'ATS_PTTPS_TP_TCR_MAP_3', 'ATS_PTTPS_TP_TCR_MAP_4',
              'ATS_TRADE_CAPTURE_REPORTS_1', 'ATS_TRADE_CAPTURE_REPORTS_2', 'ATS_TRADE_CAPTURE_REPORTS_3',
              'ATS_TRADE_CAPTURE_REPORTS_4', 'ATS_TRADE_PRINT_1', 'ATS_TRADE_PRINT_2', 'ATS_TRADE_PRINT_3',
              'ATS_TRADE_PRINT_4', 'ATS_TCR_TMP_1', 'ATS_TCR_TMP_2', 'ATS_TCR_TMP_3', 'ATS_TCR_TMP_4',
              'ATS_TRADE_PRINT_TMP_1', 'ATS_TRADE_PRINT_TMP_2', 'ATS_TRADE_PRINT_TMP_3', 'ATS_TRADE_PRINT_TMP_4',
              'ATS_PTTPS_PARAMETER']
    trd_connection_string = common.get_db_string('TRD')

    # getting info from tables
    common.info_output('Getting info from tables...', logfilename)
    db_connect = cx_Oracle.connect(trd_connection_string)
    for table_name in tables:
        common.info_output(table_name, logfilename)
        db_cursor = db_connect.cursor()
        csv_file_dest = table_name + ".csv"
        b = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'temp', 'download_tables', 'TRD')
        os.makedirs(b, exist_ok=True)
        csv_file_path = os.path.join(b, csv_file_dest)
        output_file = open(csv_file_path, 'w')
        output = csv.writer(output_file, dialect='excel')
        query = "select * from " + table_name
        try:
            db_cursor.execute(query)
        except cx_Oracle.DatabaseError as e:
            error, = e.args
            if error.code == 942:
                continue
            else:
                print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e), e)
        cols = []
        for col in db_cursor.description:
            cols.append(col[0])
        output.writerow(cols)
        for row_data in db_cursor: 
            output.writerow(row_data)
        output_file.close()
    db_connect.close()
    common.info_output('Collecting data from TRD tables completed', logfilename)
    common.info_output('==============\nExecution is completed', logfilename)
