#! /usr/bin/env python

import os
import re
import pwd
import time
import shutil
import datetime
import common
import logging
import subprocess


if __name__ == '__main__':
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
    parsed_global_cfg = common.parse_global_cfg()
    
    # Constants
    process_name = "Common:1:1:PriceUploader:1"
    price_uploader_directory = os.path.join(os.environ['HOME'], 'data', 'CPU')
    os.makedirs(price_uploader_directory, exist_ok=True)
    #Get host for price uploader
    price_uploader_host = common.get_host_for_process(process_name)
    common.info_output('Host with PriceUploader has been found: {p}'.format(p=price_uploader_host,), logfilename)

    # Prepare ClosingPrices_YYYYMMDD.csv file
    common.info_output('Prepare ClosingPrices_YYYYMMDD.csv file')
    new_file_path = common.closing_prices_preparing()
    print(new_file_path)
    if not new_file_path or not os.path.isfile(new_file_path):
        common.error_output('File with prices not found. Exit')
        exit(1)
    common.info_output('File with Closing prices has been prepared and copied to PriceUploader directory')
    p = subprocess.Popen("scp {nf} {h}:{cpu}".format(
                         nf=new_file_path, h=price_uploader_host, cpu=price_uploader_directory,),
        stderr=subprocess.PIPE, stdout=subprocess.PIPE,
        shell=True, universal_newlines=True
        )
    out, err = p.communicate()

    # Set flag FLAG_CP_FILE_READY and FLAG_CP_UPLOAD to NOT_STARTED state
    common.info_output('Set flags FLAG_CP_UPLOAD and FLAG_CP_FILE_READY to NOT_STARTED state', logfilename)
    for flagname in ['FLAG_CP_UPLOAD', 'FLAG_CP_FILE_READY']:
        cmd_desc = 'Update System Flag Value'
        parameters = {}
        parameters['flag_id'] = flagname
        parameters['flag_value'] = '1'
        parameters['partition'] = '1'
        parameters['script_id'] = '1'
        ssi_cmd = common.build_ssi_cmd(cmd_desc, parameters)
        if ssi_cmd:
            common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
            os.system(ssi_cmd)
    
    # Set flag FLAG_CP_FILE_READY to DONE state
    common.info_output('Set flag FLAG_CP_FILE_READY to DONE state', logfilename)
    parameters['flag_id'] = 'FLAG_CP_FILE_READY'
    parameters['flag_value'] = '3'
    ssi_cmd = common.build_ssi_cmd(cmd_desc, parameters)
    if ssi_cmd:
        common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
        os.system(ssi_cmd)
    common.info_output('File has been prepared, copied, flags have been moved to rigth status.', logfilename)

    # Start PriceUploader process
    common.info_output('Start PriceUploader process')
    cmd_desc = 'Start Sequence'
    parameters = {}
    parameters['Sequence Name'] = parsed_global_cfg['SStart_sequences']['start_price_uploader_sequence_name']
    ssi_cmd = common.build_ssi_cmd(cmd_desc, parameters)
    if ssi_cmd:
        common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
        os.system(ssi_cmd)

    # Check that PriceUploader has been started
    out = ''
    process_start_timer = int(parsed_global_cfg['General']['timer_flag'].replace('\'', '').replace('"', ''))
    process_started = False
    while not out:
        p = subprocess.Popen("ssh {h} \"ps x | grep {pn} | grep -v 'grep'\"".format(
                             h=price_uploader_host, pn='PriceUploader',),
            stderr=subprocess.PIPE, stdout=subprocess.PIPE,
            shell=True, universal_newlines=True
            )
        out, err = p.communicate()
        if out:
            common.info_output('PriceUploader started', logfilename)
            process_started = True
            break
        else:
            time.sleep(3)
            process_start_timer = process_start_timer - 3
    if not process_started:
        common.error_output('PriceUploader has not been started', logfilename)
        exit(1)
    flag_name = 'FLAG_CP_UPLOAD'
    flag_status = '03'
    
    track_flag_result = common.track_flag_status(flag_name, flag_status)
    if not track_flag_result == 'error':
        common.info_output('flag FLAG_CP_UPLOAD successfully moved to DONE state', logfilename)
    else:
        common.error_output('flag FLAG_CP_UPLOAD not moved to DONE state. Are you want to continue?', logfilename)
        input()
    
    # Stop PriceUploader process
    common.info_output('Stop PriceUploader process')
    cmd_desc = 'Start Sequence'
    parameters = {}
    parameters['Sequence Name'] = parsed_global_cfg['SStart_sequences']['stop_price_uploader_sequence_name']
    ssi_cmd = common.build_ssi_cmd(cmd_desc, parameters)
    if ssi_cmd:
        common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
        os.system(ssi_cmd)

    common.info_output('Set flag FLAG_CP_UPLOAD and FLAG_CP_FILE_READY to NOT_STARTED state', logfilename)
    for flagname in ['FLAG_CP_UPLOAD', 'FLAG_CP_FILE_READY']:
        cmd_desc = 'Update System Flag Value'
        parameters = {}
        parameters['flag_id'] = flagname
        parameters['flag_value'] = '1'
        parameters['partition'] = '1'
        parameters['script_id'] = '1'
        ssi_cmd = common.build_ssi_cmd(cmd_desc, parameters)
        if ssi_cmd:
            common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
            os.system(ssi_cmd)
    common.info_output('==============\nExecution is completed', logfilename)
