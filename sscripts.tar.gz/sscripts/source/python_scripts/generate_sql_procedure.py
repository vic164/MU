#!/usr/bin/env python

import os
import sys
import re
import logging
import xml.etree.ElementTree as ET

import datetime
import common


def parse_exactpro_common_cfg(config_file_path):
    config_info = {}
    reg = re.compile('(?P<name>\w+)(\=(?P<value>.+"))')
    with open(config_file_path) as cfg_file:
        for cfg_var in cfg_file.readlines():
            parse_line = reg.match(cfg_var)
            try:
               var_name = parse_line.group('name')
               var_value = parse_line.group('value').replace('"', '')
               config_info[var_name] = var_value
            except AttributeError:
                continue
    return config_info


def parse_markts_cycls_config(config_file_path):
    config_info = {}
    reg = re.compile('(?P<name>\w+)(\=(?P<value>.+))')
    with open(config_file_path) as cfg_file:
        for cfg_var in cfg_file.readlines():
            parse_line = reg.match(cfg_var)
            try:
                var_name = parse_line.group('name')
                var_value = parse_line.group('value')
                clear_var_value = var_value.replace('"', '').replace('\ ', '').replace('[', '').replace(']', '').replace('\'', '')
                var_value = clear_var_value.split(',')
                config_info[var_name] = var_value
            except AttributeError:
                continue
    return config_info


def parse_cycle_patterns_xml_config(config_paths):
    config_info = {}
    for config_file_path in config_paths:
        try:
            cycles_tree = ET.parse(config_file_path)
            cycles_root = cycles_tree.getroot()
            for cycle_info in cycles_root:
                cycle_pattern_name = cycle_info.tag
                full_cycle_info = []
                for session_info in cycle_info:
                    session_parameters = session_info.attrib
                    session_parameters['value'] = session_info.text
                    full_cycle_info.append(session_parameters)
                config_info[cycle_pattern_name] = full_cycle_info
        except Exception as e:
            print('Something not right with parsing config: ' + str(config_file_path))
            print(e)
            continue
    return config_info


def validate_exactpro_common_cfg(cfg_info):
    neccesary_tags = ['DAY_START', 'OFFSET_MARKETS_START', 'NO_SESSION_BEFORE_PRE_DURATION', 'DURATION_PRETRADING',
                      'DURATION_OAC', 'DURATION_RT', 'DURATION_CAC', 'DURATION_POST_CLOSE',
                      'NO_SESSION_AFTER_PC_DURATION', 'OFFSET_DAY_END']
    for tag in neccesary_tags:
        if tag not in cfg_info.keys():
            common.error_output('Tag ' + tag + ' not found in the config')
            exit(1)


def validate_and_get_patterns(cfg_info):
    patterns = []
    if 'MARKETS' not in cfg_info.keys():
        common.error_output('Tag MARKETS not found in the config')
        exit(1)
    for pattern_name in cfg_info.keys():
        if re.search('MARKETS', pattern_name):
        #if pattern_name == 'MARKETS':
            continue
        if pattern_name not in patterns:
            patterns.append(pattern_name)
        else:
            common.warning_output('Duplicate in patterns name: ' + pattern_name)
        for cycle_name in cfg_info[pattern_name]:
            for other_pattern in cfg_info.keys():
                if other_pattern == pattern_name:
                    continue
                if cycle_name in cfg_info[other_pattern]:
                    common.error_output('Duplicate cycle has been found in two different patterns: ' + pattern_name +
                                  ' and ' + other_pattern + '. Please check your configs and try again')
    return patterns


def validate_cycle_patterns_xml(cycles_patterns_info, patterns):
    for pattern in patterns:
        if pattern not in cycles_patterns_info.keys():
            common.warning_output('Pattern ' + pattern + ' has not been found in the configs. Some cycles can be not updated')


def get_datetime_format_time_value(time_hh_mm_ss):
    current_year = datetime.datetime.today().year
    current_month = datetime.datetime.today().month
    current_day = datetime.datetime.today().day
    hours, minutes, seconds = time_hh_mm_ss.split(':')
    datetime_format_time = datetime.datetime(current_year, current_month, current_day,
                                             int(hours), int(minutes), int(seconds))
    return datetime_format_time


def get_day_start_time(common_cfg_info):
    def check_valid_day_start_time(day_start_time):
        day_start_time_for_check = get_datetime_format_time_value(day_start_time)
        if day_start_time_for_check < datetime.datetime.today():
            common.error_output('DAY_START has been set in the past')
            common_cfg_info['AUTO_UPDATE'] = 'Y'
            day_start_time = get_day_start_time(common_cfg_info)
        else:
            common.info_output('Day start time has been checked.')
        return day_start_time

    try:
        if common_cfg_info['AUTO_UPDATE'].upper() == 'Y':
            common.info_output('Automatic updating of day start has been chosen')
            current_date = datetime.datetime.today()
            minutes_before_day_start = int(common_cfg_info['AUTOOFFSET_DAYSTART_MIN'])
            standard_offset = datetime.timedelta(minutes=minutes_before_day_start)
            time_for_day_start = current_date + standard_offset
            day_start = datetime.datetime.strftime(time_for_day_start, "%H:%M:%S")
            common_cfg_info['DAY_START'] = day_start
        else:
            common.info_output('Day start time : ' + common_cfg_info['DAY_START'])
            day_start = check_valid_day_start_time(common_cfg_info['DAY_START'])
            common_cfg_info['DAY_START'] = day_start
    except IndexError:
        common.info_output('Day start time : ' + common_cfg_info['DAY_START'])
        day_start = check_valid_day_start_time(common_cfg_info['DAY_START'])
        common_cfg_info['DAY_START'] = day_start
    return day_start


def get_new_timestamp(old_time, offset):
    datetime_format_old_date = get_datetime_format_time_value(old_time)
    #time_offset = datetime.timedelta(minutes=int(offset))
    time_offset = datetime.timedelta(minutes=float(offset))
    new_datetime = datetime_format_old_date + time_offset
    new_time = datetime.datetime.strftime(new_datetime, "%H:%M:%S")
    return new_time


def get_complex_duration(session_info, general_cfg_info):
    vars = session_info['var'].split('+')
    result_duration = 0
    for var in vars:
        if var not in general_cfg_info.keys():
            continue
        single_dur = int(general_cfg_info[var])
        result_duration += single_dur
    return result_duration


def get_end_time_for_perc_type(start_time, session_info, common_cfg_info):
    var_name = session_info['var']
    percent = int(session_info['value'])
    if re.search('\+', var_name):
        common_session_duration = get_complex_duration(session_info, common_cfg_info)
    else:
        if var_name not in common_cfg_info.keys():
            common.warning_output("Cannot find var " + session_info['var'])
            return None
        try:
            common_session_duration = int(common_cfg_info[var_name])
        except ValueError:
            common_session_duration = 0
        except KeyError:
            common_session_duration = 0
    session_duration = common_session_duration * percent / 100
    end_time = get_new_timestamp(start_time, session_duration)
    return end_time


def get_end_time_for_min_type(start_time, session_info):
    session_duration_min = float(session_info['value'])
    end_time = get_new_timestamp(start_time, session_duration_min)
    return end_time


def get_full_sessions_info(session_cfg_info, first_timestamp, common_cfg_info):
    full_sessions_info = []
    number_of_sessions = len(session_cfg_info)
    start_time = first_timestamp
    end_time = start_time
    for session_id in range(1, number_of_sessions+1):
        single_session_info = {}
        for session_info in session_cfg_info:
            if int(session_info['number']) == session_id:
                single_session_info['session_name'] = session_info['name']
                if session_info['type'] == 'perc':
                    end_time = get_end_time_for_perc_type(start_time, session_info, common_cfg_info)
                    if not end_time:
                        return None
                    single_session_info['start_time'] = start_time
                    single_session_info['end_time'] = end_time
                elif session_info['type'] == 'time':
                    start_time = session_info['start_time']
                    end_time = session_info['end_time']
                    if not end_time or not start_time:
                        return None
                    single_session_info['start_time'] = start_time
                    single_session_info['end_time'] = end_time
                elif session_info['type'] == 'min':
                    # pass
                    end_time = get_end_time_for_min_type(start_time, session_info)
                    if not end_time:
                        return None
                    single_session_info['start_time'] = start_time
                    single_session_info['end_time'] = end_time
        full_sessions_info.append(single_session_info)
        start_time = end_time
    return full_sessions_info


def generate_procedure_string(EVENT, PARAMETER_VALUE1, PARAMETER_VALUE2, ELEMENT, SPEC_PARAM):
    if EVENT == "DAY":
        TABLE_NAME = 'ATS_PARAMETER_VALUES'
        SET_CONDITION = 'PARAMETER_VALUE = TO_CHAR(\'' + PARAMETER_VALUE1 + '\')'
        WHERE_CONDITION = 'PARAMETER_ID IN (SELECT PARAMETER_ID FROM ATS_PARAMETER_DEFS WHERE PARAMETER_NAME = \'' + SPEC_PARAM + '\')'
    elif EVENT == "MARKET":
        TABLE_NAME = 'ATSD_MAR_ALL'
        SET_CONDITION = SPEC_PARAM + ' = TO_CHAR(\'' + PARAMETER_VALUE1 + '\')'
        WHERE_CONDITION = 'MARKET_ID IN (\'' + ELEMENT + '\')'
    elif EVENT == 'CYCLE':
        if ELEMENT == 'NOSESSION':
            return ''
        TABLE_NAME = 'ATS_SESSION_TIMES'
        SET_CONDITION1 = 'START_TIME = TO_CHAR(\'' + PARAMETER_VALUE1 + '\')'
        SET_CONDITION2 = 'END_TIME = TO_CHAR(\'' + PARAMETER_VALUE2 + '\')'
        SET_CONDITION = SET_CONDITION1 + ', ' + SET_CONDITION2
        if re.search('%', SPEC_PARAM):
            WHERE_CONDITION = 'SESSION_ID = \'' + ELEMENT + '\' AND TRADING_CYCLE_ID like \'' + SPEC_PARAM  + '\''
        else:
            WHERE_CONDITION = 'SESSION_ID = \'' + ELEMENT + '\' AND TRADING_CYCLE_ID = \'' + SPEC_PARAM + '\''
    procedure_string = 'UPDATE ' + TABLE_NAME + ' SET ' + SET_CONDITION + ' WHERE ' + WHERE_CONDITION + ';\n'
    return procedure_string


def update_rt_duration(common_cfg_info, current_date):
    y = int(datetime.datetime.strftime(current_date, "%Y"))
    m = int(datetime.datetime.strftime(current_date, "%m"))
    d = int(datetime.datetime.strftime(current_date, "%d"))
    valid_eod_time = datetime.datetime(y, m, d, 23, 00, 0, 0)
    day_max_duration = (valid_eod_time - current_date).seconds / 60
    rt_max_duration = day_max_duration
    for i in common_cfg_info.keys():
        if not i == 'DURATION_RT':
            if re.search('[0-9]', common_cfg_info[i]) and not re.search('[0-9]{2}\:[0-9]{2}\:[0-9]{2}', common_cfg_info[i]):
                if not re.search('[0-9]{4}\/[0-9]{2}\/[0-9]{2}', common_cfg_info[i]):
                    rt_max_duration -= int(common_cfg_info[i])
    common_cfg_info['DURATION_RT'] = rt_max_duration
    return common_cfg_info


def additional_updates(common_cfg_info, m_c_info, finally_procedure, day_start_time, eopc_time):
    additional_markets = []
    for k in common_cfg_info.keys():
        if re.search('OFFSET_FOR_MARKET_END_', k):
            market_group_name = k.replace('OFFSET_FOR_MARKET_END_', '')
            if int(common_cfg_info[k]) > int(common_cfg_info['OFFSET_DAY_END']):
                if market_group_name in additional_markets:
                    additional_markets.remove(market_group_name)
                else:
                    continue
            if market_group_name not in additional_markets:
                additional_markets.append(market_group_name)
        elif re.search('OFFSET_FOR_MARKET_', k):
            market_group_name = k.replace('OFFSET_FOR_MARKET_', '')
            market_end_key = 'OFFSET_FOR_MARKET_END_' + market_group_name
            if market_end_key in common_cfg_info.keys() and int(common_cfg_info[market_end_key]) > int(common_cfg_info['OFFSET_DAY_END']):
                continue
            if market_group_name not in additional_markets:
                additional_markets.append(market_group_name)
    for market_group in additional_markets:
        if market_group not in m_c_info.keys():
            common.warning_output('Market group pattern ' + str(market_group) + ' has no markets in config')
        mstart_key = 'OFFSET_FOR_MARKET_' + market_group
        mrktstart_offset = common_cfg_info[mstart_key] if mstart_key in common_cfg_info.keys() else common_cfg_info['OFFSET_MARKETS_START']
        time_for_market_start = get_new_timestamp(day_start_time, mrktstart_offset)
        mend_key = 'OFFSET_FOR_MARKET_END_' + market_group
        mrktend_offset = common_cfg_info[mend_key] if mend_key in common_cfg_info.keys() else common_cfg_info['NO_SESSION_AFTER_PC_DURATION']
        time_for_market_end = get_new_timestamp(eopc_time, mrktend_offset)
        for market_name in m_c_info[market_group]:
            market_name = market_name.replace('\'',  '').replace('\"',  '')
            if re.match(' ', market_name): 
                market_name = market_name.replace(' ',  '', 1)
            update_string = generate_procedure_string("MARKET", time_for_market_start, None, market_name, 'START_TIME')
            finally_procedure.write(update_string)
            finally_procedure.write('\n')
            update_string = generate_procedure_string("MARKET", time_for_market_end, None, market_name, 'END_TIME')
            finally_procedure.write(update_string)
            finally_procedure.write('\n')
    return finally_procedure


if __name__ == '__main__':
        script_directory = os.getcwd()
        script_home_directory = os.path.dirname(script_directory)
        logs_directory = os.path.join(script_home_directory, 'logs')
        try:
            logfilename = str(sys.argv[1])
        except IndexError:
            logname = (os.path.basename(__file__) + '.log')
            logfilename = os.path.join(logs_directory, logname)
        with open(logfilename, 'w') as x:
            x.write('')
        logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
        cfg_directory = os.path.join(script_home_directory, 'cfg', 'TradingCyclesSettings')
        exactpro_common_cfg = os.path.join(script_home_directory, 'cfg', 'ExactproSystemTimes.cfg')
        markts_cycls_config = os.path.join(cfg_directory, 'markets_cycles_settings.cfg')
        global_config = os.path.join(script_home_directory, 'cfg', 'global.cfg')
        cycle_pattern_files = []
        trading_cycles_dir_path = os.path.join(cfg_directory, 'trading_cycles')
        for file in os.listdir(trading_cycles_dir_path):
            file_path = os.path.join(trading_cycles_dir_path, file)
            if os.path.isfile(file_path) and file_path.endswith('.xml'):
                cycle_pattern_files.append(file_path)
        common.info_output(cycle_pattern_files)

        temp_directory = os.path.join(script_home_directory, 'temp')
        procedure_txt = os.path.join(temp_directory, 'EST_PROCEDURE.txt')
        with open(procedure_txt, 'w') as p:
            p.write('')
        common.info_output("Parsing config files...")
        if os.path.isfile(exactpro_common_cfg):
            common.info_output("Parsing config file ExactproSystemTimes.cfg")
            common_cfg_info = parse_exactpro_common_cfg(exactpro_common_cfg)
            validate_exactpro_common_cfg(common_cfg_info)
            common.info_output(common_cfg_info)
        else:
            common.error_output("Config file " + str(exactpro_common_cfg) + " not found. 341")
            exit(1)
        if os.path.isfile(global_config):
            common.info_output("Parsing config file global.cfg")
            global_cfg_info = parse_exactpro_common_cfg(global_config)
            common_cfg_info['AUTOOFFSET_DAYSTART_MIN'] = global_cfg_info['AUTOOFFSET_DAYSTART_MIN']
            common.info_output('common_cfg_info[AUTOOFFSET_DAYSTART_MIN]: ' + str(common_cfg_info['AUTOOFFSET_DAYSTART_MIN']))
        else:
            common.error_output("Config file " + str(global_config) + " not found")
            exit(1)

        if os.path.isfile(markts_cycls_config):
            common.info_output("Parsing config file markets_cycles_settings.cfg")
            m_c_info = parse_markts_cycls_config(markts_cycls_config)
            patterns = validate_and_get_patterns(m_c_info)
            #common.info_output(m_c_info)
        else:
            common.error_output("Config file " + str(markts_cycls_config) + " not found")
            exit(1)

        if cycle_pattern_files:
            common.info_output("Parsing config file trading_cycles/*")
            try:
                cycles_patterns_info = parse_cycle_patterns_xml_config(cycle_pattern_files)
                #common.info_output(cycles_patterns_info)
                validate_cycle_patterns_xml(cycles_patterns_info, patterns)
            except ET.ParseError as e:
                common.error_output("Something wrong with xml config")
                common.error_output(e)
        else:
            common.error_output("Config file " + str(trading_cycles_dir_path) + " not found")
            exit(1)

        """ Now we have:
         1) info from ExactproSystemTimes.cfg in common_cfg_info dict,
         2) info from markets_cycles_settings.cfg in m_c_info dict,
         3) info from times_prod_trading_cycles.xml in cycles_patterns_info
        """
        common.info_output('Day start...')
        day_start_time = get_day_start_time(common_cfg_info)
        common.info_output('day_start_time: ' + str(day_start_time))

        finally_procedure = open(procedure_txt, 'a')
        update_string = generate_procedure_string('DAY', day_start_time, None, None, 'OP_DAY_START_TIME')
        finally_procedure.write(update_string)
        finally_procedure.write('\n')
        # check that EOD will appeared at the same date
        trading_day_duration = 0
        for i in common_cfg_info.values():
            if re.search('[0-9]', i) and not re.search('[0-9]{2}\:[0-9]{2}\:[0-9]{2}',i) and not re.search('[0-9]{4}\/[0-9]{2}\/[0-9]{2}',i):
                trading_day_duration += int(i)
        dstime = datetime.datetime.strptime(day_start_time, "%H:%M:%S")
        deofset = datetime.timedelta(minutes=trading_day_duration)
        current_date = datetime.datetime.today()
        eodmoment = current_date + deofset
        if not datetime.datetime.strftime(current_date, "%Y%m%d") ==  datetime.datetime.strftime(eodmoment, "%Y%m%d"):
            common_cfg_info = update_rt_duration(common_cfg_info, current_date)
        offset_for_market = common_cfg_info['OFFSET_MARKETS_START']
        time_for_market_start = get_new_timestamp(day_start_time, offset_for_market)
        for market_name in m_c_info['MARKETS']:
            if re.match(' ', market_name):
                market_name = market_name.replace(' ',  '', 1)
            update_string = generate_procedure_string("MARKET", time_for_market_start, None, market_name, 'START_TIME')
            finally_procedure.write(update_string)
            finally_procedure.write('\n')
        offset_for_pre = common_cfg_info['NO_SESSION_BEFORE_PRE_DURATION']
        time_for_pre = get_new_timestamp(time_for_market_start, offset_for_pre)
        for pattern_name in m_c_info.keys():
            if re.search('MARKET', pattern_name.upper()):
                continue
            for cycle_name in m_c_info[pattern_name]:
                if re.match('\ ', cycle_name):
                    cycle_name = cycle_name.replace(' ', '', 1)
                try:
                    full_sessions_info = get_full_sessions_info(cycles_patterns_info[pattern_name], time_for_pre, common_cfg_info)
                except KeyError as ke:
                    common.warning_output('Key ' + str(ke) + ' not found')
                    common.info_output("Cannot found Pattern " + pattern_name + ". Skipped")
                    continue
                # full_sessions_info = [{"session_name": "Pre-Trading", 'start_time': "HH:MM:SS", "end_time": HH:MM:SS"}, ..., {}]
                if not full_sessions_info:
                    continue
                for session in full_sessions_info:
                    try: 
                        update_string = generate_procedure_string("CYCLE", session['start_time'],
                                                                  session['end_time'], session['session_name'], cycle_name)
                        finally_procedure.write(update_string)
                    except KeyError:
                        common.warning_output('Bad configuration for trading cycle ' + str(cycle_name) + '. Please, check')
                        break
        try:
            d_pre = int(common_cfg_info['DURATION_PRETRADING'])
        except ValueError:
            d_pre = 0
        except KeyError:
            d_pre = 0
        try:
            d_oac = int(common_cfg_info['DURATION_OAC'])
        except ValueError:
            d_oac = 0
        except KeyError:
            d_oac = 0
        try:
            d_rt = int(common_cfg_info['DURATION_RT'])
        except ValueError:
            d_rt = 0
        except KeyError:
            d_rt = 0
        try:
            d_cac = int(common_cfg_info['DURATION_CAC'])
        except ValueError:
            d_cac = 0
        except KeyError:
            d_cac = 0
        try:
            d_cpp = int(common_cfg_info['DURATION_CPP'])/60
        except ValueError:
            d_cpp = 0
        except KeyError:
            d_cpp = 0
        try:
            d_pc = int(common_cfg_info['DURATION_POST_CLOSE'])
        except ValueError:
            d_pc = 0
        except KeyError:
            d_pc = 0
        try:
            d_apc = int(common_cfg_info['NO_SESSION_AFTER_PC_DURATION'])
        except ValueError:
            d_apc = 0
        except KeyError:
            d_apc = 0
        offset_market_end = d_pre + d_oac + d_rt + d_cac + d_cpp + d_pc + d_apc
        time_for_market_end = get_new_timestamp(time_for_pre, offset_market_end)
        for market_name in m_c_info['MARKETS']:
            market_name = market_name.replace('\'',  '').replace('\"',  '').replace(' ',  '', 1)
            update_string = generate_procedure_string("MARKET", time_for_market_end, None, market_name, 'END_TIME')
            finally_procedure.write(update_string)
            finally_procedure.write('\n')
        time_day_end = get_new_timestamp(time_for_market_end, common_cfg_info['OFFSET_DAY_END'])
        update_string = generate_procedure_string("DAY", time_day_end, None, None, 'OP_DAY_END_TIME')
        finally_procedure.write(update_string)
        finally_procedure.write('\n')
        offset_end_of_postclose = d_pre + d_oac + d_rt + d_cac + d_cpp + d_pc
        time_for_end_of_pc = get_new_timestamp(time_for_pre, offset_end_of_postclose) 
        try:
            finally_procedure = additional_updates(common_cfg_info, m_c_info, finally_procedure, day_start_time, time_for_end_of_pc)
        except Exception as e:
            common.warning_output(e)
        finally_procedure.close()
        print(procedure_txt)

