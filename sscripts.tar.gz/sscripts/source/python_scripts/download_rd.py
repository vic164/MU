#! /usr/bin/env python

import os
import sys
import re
import pwd
import time
import copy
import tarfile
import shutil
import zipfile
import logging
import cx_Oracle
import subprocess
from datetime import datetime
import xml.etree.ElementTree as ET
import lxml.etree as etree
import common


def execute_ssi_cmd_for_flag(flag_name, status):
    flag_parameters = {}
    flag_parameters['flag_id'] = flag_name
    flag_parameters['flag_value'] = status.replace('0', '')
    flag_parameters['owner'] = 'Common'
    flag_parameters['partition'] = '1'
    flag_parameters['script_id'] = '1'
    ssi_cmd = common.build_ssi_cmd('Flag Value', flag_parameters)
    ssi_cmd = ssi_cmd.replace('\'', '').replace('\ $', '')
    common.debug_output('ssi cmd has been generated: ' + str(ssi_cmd))
    x = subprocess.Popen(ssi_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True, executable='/bin/bash', universal_newlines=True)
    x.wait()
    out, err = x.communicate()
    common.debug_output('out: ' + str(out))
    common.debug_output('err: ' + str(err))
    x.kill()


def get_flag_status(flag_name):
    query = "SELECT FLAG_VALUE FROM SG4_FLAG_VALUES WHERE FLAG_NAME = \'{f}\'".format(f=flag_name)
    db_cursor = db_connect.cursor()
    query_answer = db_cursor.execute(query)
    answer = query_answer.fetchall()
    flag_status = re.match('[0-9]{2}', answer[0][0]).group(0)
    return flag_status


def track_flag_status(flag_name, flag_status):
    common.info_output('track_flag_status. Waiting for ' + flag_name + ' become in state ' + flag_status)
    timer = TIMER_FLAG
    while timer > 0:
        current_flag_status = get_flag_status(flag_name)
        if current_flag_status == flag_status:
            return ''
        else:
            x = '{s}.'.format(s=timer)
            print(x, end='\r')
            timer -= 1
            time.sleep(1)
    common.info_output('track_flag_status. Timer expired. ' + flag_name + ' not became to state ' + flag_status)
    input('Proceed? (ctrl+c if exit)')


def clear_remote_dir(host, rmt_dir):
    common.debug_output("clear_remote_dir: ssh {h} \"rm -f {d}/*\"".format(h=host, d=rmt_dir))
    p = subprocess.Popen("ssh {h} \"rm -f {d}/*\"".format(h=host, d=rmt_dir),
                     stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                     shell=True, universal_newlines=True)
    p.wait()
    p.kill()


def get_root_xml_file(file_path):
    """ Function for parse xml files with spec symbols
    :param file_path: full path of file
    :return: parsed info - xml.etree.ElementTree root element
    """
    try:
        tree = ET.parse(file_path)
    except ET.ParseError:
        with open(file_path, encoding="ISO-8859-1") as open_file_for_encode:
            read_file_for_encode = open_file_for_encode.read()
            encoded_info = read_file_for_encode
            write_x_file = open('x_file.xml', 'w')
            write_x_file.write(encoded_info)
            write_x_file.close()
        with open('x_file.xml') as open_file_for_encode:
            read_file_for_encode = open_file_for_encode.read()
            encoded_info = read_file_for_encode
            write_result_file = open(file_path, 'w')
            write_result_file.write(encoded_info)
            write_result_file.close()
        os.remove('x_file.xml')
        tree = ET.parse(file_path)
    root = tree.getroot()
    return root



def copy_from_remote_dir(host, rmt_dir_files, local_dir):
    common.debug_output('copy_from_remote_dir: scp {h}:{d} {l}'.format(h=host, d=rmt_dir_files, l=local_dir))
    p = subprocess.Popen("scp {h}:{d} {l}/".format(h=host, d=rmt_dir_files, l=local_dir),
                     stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True, universal_newlines=True)
    time.sleep(10)
    out, err = p.communicate()
    p.wait()
    print(out)
    print(err)
    p.kill()


def get_instance_with_userid(root, val):
    for instance in root:
        user_id = instance.findall('UserID')[0].text
        if user_id == val:
            return instance
    return None


def waiting_usersxml(dir_path):
    common.info_output('Waiting for Users.xml...')
    timer = 120
    a = os.path.join(dir_path, 'Users.xml')
    b = os.path.join(dir_path, 'MarketOpsUsers.xml')
    found_flag = False
    while True:
        for i in os.listdir(dir_path):
            if i == 'Users.xml':
                found_flag = True
                break
        if found_flag:
            print('Copying completed')
            break
        time.sleep(1)
        timer -= 1
        if timer <= 0:
            common.error_output('Users cannot be copied. Exit')
            exit(1)
    time.sleep(1)


def bit_special_renaming(dir_path):
    common.info_output('BIT special renaming files if it needed')
    for i in os.listdir(dir_path):
        if re.search('_[0-9]{8}', i):
            date_namepart = re.search('_[0-9]{8}', i).group(0) 
            new_name = i.replace(date_namepart, '')
            old_file = os.path.join(dir_path, i)
            new_file = os.path.join(dir_path, new_name)
            os.rename(old_file, new_file)
    common.info_output('Renaming completed')


if __name__ == '__main__':
    start_time = time.time()
    downloader_script_name = os.path.basename(os.path.abspath(__file__))
    env_scripts_dir = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts')
    temp_dir = os.path.join(env_scripts_dir, 'temp')
    cfg_dir = os.path.join(env_scripts_dir, 'cfg')
    logs_dir = os.path.join(env_scripts_dir, 'logs')
    logfilename = os.path.join(logs_dir, downloader_script_name + '.log')
    rd_dir = os.path.join(temp_dir, 'downloaded_rd')
    os.makedirs(rd_dir, exist_ok=True)
    now = datetime.today()
    TIMER_FLAG = 900
    with open(logfilename, 'w') as x:
        x.write(datetime.strftime(now, "%Y%m%d-%H%M%S"))
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
    exman_host = common.get_host_for_process('Common:1:1:ExchangeManager:1')
    auth_host = common.get_host_for_process('Common:1:1:AuthServer:1')
    sg_db_string = common.get_db_string('SG')
    db_connect = cx_Oracle.connect(sg_db_string)

    # Download RefData from ExMan
    common.info_output("Download RefData from system (ExMan)", logfilename)
    download_dir_path = os.path.join('~', 'data', 'ExchangeRefData', 'download')
    execute_ssi_cmd_for_flag("FLAG_EM_DOWNLOAD_REFERENCE_DATA", "02")
    track_flag_status("FLAG_EM_DOWNLOAD_REFERENCE_DATA", "03")
    downloaded_em_rd = os.path.join(rd_dir, 'exman')
    os.makedirs(downloaded_em_rd, exist_ok=True)
    downloaded_files = os.path.join(download_dir_path, '*')
    copy_from_remote_dir(exman_host, downloaded_files, downloaded_em_rd)
    bit_special_renaming(downloaded_em_rd)
    waiting_usersxml(downloaded_em_rd)
    time.sleep(10)
    clear_remote_dir(exman_host, download_dir_path)
    common.info_output('Download from EM completed', logfilename)

    # Download Users.xml from Auth
    common.info_output("Download RefData from system (Auth)", logfilename)
    download_dir_path = os.path.join('~', 'data', 'AuthServer')
    execute_ssi_cmd_for_flag("FLAG_AUTH_DOWNLOAD_DATA", "02")
    track_flag_status("FLAG_AUTH_DOWNLOAD_DATA", "03")
    downloaded_auth_rd = os.path.join(rd_dir, 'auth')
    os.makedirs(downloaded_auth_rd, exist_ok=True)
    downloaded_files = os.path.join(download_dir_path, 'Users.xml')
    time.sleep(2)
    copy_from_remote_dir(auth_host, downloaded_files, downloaded_auth_rd)
    waiting_usersxml(downloaded_auth_rd)
    clear_remote_dir(auth_host, download_dir_path)
    common.info_output('Download from Auth completed', logfilename)
    
    # Combine Users.xml
    common.info_output('Combine Users.xml...', logfilename)
    em_users_filepath = os.path.join(downloaded_em_rd, 'Users.xml')
    auth_users_filepath = os.path.join(downloaded_auth_rd, 'Users.xml')
    em_users_root = get_root_xml_file(em_users_filepath)
    auth_users_root = get_root_xml_file(auth_users_filepath)
    for instance in em_users_root:
        user_id = instance.findall('UserID')[0].text
        auth_instance = get_instance_with_userid(auth_users_root, user_id)
        if not auth_instance:
            continue
        for auth_tags in auth_instance:
            t = auth_tags.tag
            if len(instance.findall(t)) == 0:
                instance.append(auth_tags)
    tree = ET.ElementTree(em_users_root)
    tree.write(em_users_filepath)
    x = etree.parse(em_users_filepath)
    prettytext = etree.tostring(x, pretty_print=True)
    with open(em_users_filepath, 'wb') as q:
        q.write(prettytext)
    common.info_output('Combine Users.xml completed', logfilename)

    # Combine MarketOpsUsers.xml
    common.info_output('Combine MarketOpsUsers.xml...', logfilename)
    em_users_filepath = os.path.join(downloaded_em_rd, 'MarketOpsUsers.xml')
    auth_users_filepath = os.path.join(downloaded_auth_rd, 'Users.xml')
    em_users_root = get_root_xml_file(em_users_filepath)
    auth_users_root = get_root_xml_file(auth_users_filepath)
    for instance in em_users_root:
        user_id = instance.findall('UserID')[0].text
        auth_instance = get_instance_with_userid(auth_users_root, user_id)
        if not auth_instance:
            continue
        for auth_tags in auth_instance:
            t = auth_tags.tag
            if len(instance.findall(t)) == 0:
                instance.append(auth_tags)
    tree = ET.ElementTree(em_users_root)
    tree.write(em_users_filepath)
    x = etree.parse(em_users_filepath)
    prettytext = etree.tostring(x, pretty_print=True)
    with open(em_users_filepath, 'wb') as q:
        q.write(prettytext)
    common.info_output('Combine MarketOpsUsers.xml completed', logfilename)

    common.info_output('Backup RedData has been completed', logfilename)
    common.info_output("--- %s seconds ---" % (time.time() - start_time), logfilename)
