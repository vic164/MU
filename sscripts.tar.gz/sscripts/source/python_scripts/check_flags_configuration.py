#! /usr/bin/env python

import os
import re
import sys
import pwd
import shutil
import datetime
import common
import logging


if __name__ == '__main__':
    flag_description_table = {'01': 'NOT STARTED', '02': 'STARTED', '03': 'DONE', '04': 'ERROR'}
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    bin_dir = os.path.join(os.path.dirname(script_directory), 'bin')
    cfg_dir = os.path.join(os.path.dirname(script_directory), 'cfg')
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
    global_cfg_fullinfo = common.parse_global_cfg()
    sg_conn_string=common.get_db_string('SG')

    if len(sys.argv) == 1:
        common.error_output('Flag configuration is not specified. Exit', logfilename)
        exit(1)
    if str(sys.argv[1]) == "SOD":
        full_flags_set = common.get_list_of_all_flags()
        flag_name = "FLAG_SPN"
        flag_status = common.get_flag_status(flag_name)
        if flag_status == '03':
            common.info_output(flag_name + ' in DONE state', logfilename)
        else:
            flag_desc = flag_description_table[flag_status]
            common.error_output(flag_name + ' in ' + flag_desc + ' state', logfilename)
            exit(1)
        for flag_name in full_flags_set: 
            if flag_name == "FLAG_SPN":
                continue
            if re.match('CM_', flag_name):
                common.debug_output(flag_name + ' skipped', logfilename)
                continue
            if re.match('FLAG_AUTH_', flag_name):
                common.debug_output(flag_name + ' skipped', logfilename)
                continue
            if re.match('FLAG_EM_', flag_name):
                common.debug_output(flag_name + ' skipped', logfilename)
                continue
            if re.match('FLAG_CP_', flag_name):
                common.debug_output(flag_name + ' skipped', logfilename)
                continue
            flag_status = common.get_flag_status(flag_name)
            if flag_status == '01':
                common.info_output(flag_name + ' in NOT_STARTED state', logfilename)
            else:
                flag_desc = flag_description_table[flag_status]
                common.error_output(flag_name + ' in ' + flag_desc + ' state', logfilename)
                exit(1)
    elif str(sys.argv[1]) == "EOD":
        eod_flags_done_configuration = global_cfg_fullinfo['Flags']['eod_set_flags_done']
        for flag_name in eod_flags_done_configuration.split(','):
            flag_status = common.get_flag_status(flag_name)
            if flag_status == '03':
                common.info_output(flag_name + ' in DONE state', logfilename)
            else:
                flag_desc = flag_description_table[flag_status]
                common.error_output(flag_name + ' in ' + flag_desc + ' state', logfilename)
                exit(1)
    elif str(sys.argv[1]) == "RESET":
        sod_reset_flags_configuration = global_cfg_fullinfo['Flags']['sod_reset_flags']
        for flag_name in sod_reset_flags_configuration.split(','):
            flag_status = common.get_flag_status(flag_name)
            print(flag_name + ': ' + flag_status)
            if flag_status == '03':
                common.info_output(flag_name + ' in DONE state. Move to NOT_STARTED', logfilename)
                ssi_parameters = {}
                cmd_desc = 'Flag Value'
                ssi_parameters['flag_id'] = flag_name
                ssi_parameters['flag_value'] = '1'
                ssi_parameters['owner'] = 'Global'
                ssi_parameters['partition'] = '1'
                ssi_parameters['script_id'] = '1'
                ssi_cmd = common.build_ssi_cmd(cmd_desc, ssi_parameters)
                if ssi_cmd:
                    common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
                    os.system(ssi_cmd)
                else:
                    common.error_output('Cannot build SSI cmd', logfilename)
                if flag_name == "FLAG_SOD_OF_LOADING":
                    ssi_parameters = {}
                    cmd_desc = 'Flag Value'
                    ssi_parameters['flag_id'] = flag_name
                    ssi_parameters['flag_value'] = '1'
                    ssi_parameters['owner'] = 'Global'
                    ssi_parameters['script_id'] = '1'
                    for p in ['1', '2', '3', '4']:
                        ssi_parameters['partition'] = p
                        ssi_cmd = common.build_ssi_cmd(cmd_desc, ssi_parameters)
                        if ssi_cmd:
                            common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
                            os.system(ssi_cmd)
                        else:
                            common.error_output('Cannot build SSI cmd', logfilename)
            elif flag_status in ['04', '02']:
                flag_desc = flag_description_table[flag_status]
                common.error_output(flag_name + ' in ' + flag_desc + ' state.', logfilename)
                exit(1)
            elif flag_status == '01':
                common.debug_output(flag_name + ' already in NOT_STARTED state.', logfilename)
    elif str(sys.argv[1]) == "CHECK_RESET":
        sod_reset_flags_configuration = global_cfg_fullinfo['Flags']['sod_reset_flags']
        for flag_name in sod_reset_flags_configuration.split(','):
            flag_status = common.get_flag_status(flag_name)
            if flag_status == '01':
                common.info_output(flag_name + ' in NOT_STARTED state.', logfilename)
            else:
                common.error_output(flag_name + ' not in NOT_STARTED state', logfilename)
                exit(1)
    else:
        common.error_output('Unknown attribute ' + str(sys.argv[1]), logfilename)
        common.error_output('Possible values: SOD, EOD, RESET, CHECK_RESET', logfilename)
        exit(1)
