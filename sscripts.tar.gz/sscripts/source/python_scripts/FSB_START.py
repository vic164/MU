#!/usr/bin/env python

import os
import socket
import common


def netcat(hostname, port, content):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((hostname, port))
    s.sendall(content)
    s.shutdown(socket.SHUT_WR)
    while 1:
        data = s.recv(1024)
        if data == b'':
            break
        print("Received:", repr(data))
    print("Connection closed.")
    s.close()


if __name__ == '__main__':
    fsb_host = common.get_host_for_process("Common:1:1:FSB:1")
    fsb_port = int(os.environ['S_REG_PORT_NO']) + 700
    print("port: " + str(fsb_port))
    cmd =  b'8=FIXT.1.1\x019=25\x0135=452\x01455=12\x01456=BRIDGE\x0110=087\x01' 
    print(fsb_host)
    print(fsb_port)
    print(cmd)
    print(type(cmd))

    netcat(fsb_host, fsb_port, cmd)

