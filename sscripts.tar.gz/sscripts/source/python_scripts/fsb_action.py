#!/usr/bin/env python
import logging
import os
import sys

import re
import datetime
import socket
import time

def netcat(hostname, port, content):
    logging.info('hostname: ' + str(hostname))
    logging.info('port: ' + str(port))
    logging.info('content: ' + str(content))
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((hostname, port))
    s.sendall(content.encode())
    s.shutdown(socket.SHUT_WR)
    while 1:
        data = s.recv(1024)
        if not data or data == "":
            break
    logging.debug("Connection closed.")
    s.close()


def get_markets(config_file_path):
    reg = re.compile('(?P<name>\w+)(\=(?P<value>.+))')
    with open(config_file_path) as cfg_file:
        for cfg_var in cfg_file.readlines():
            parse_line = reg.match(cfg_var)
            try:
                var_name = parse_line.group('name')
                if var_name == 'MARKETS':
                    var_value = parse_line.group('value')
                    clear_var_value = var_value.replace('"', '').replace('\ ', '').replace('[', '').replace(']', '')
                    var_value = clear_var_value.split(',')
                    return var_value
            except AttributeError:
                continue


def checksum_calculate(string):
    decsum = 0
    for char in string:
        if char == '|':
            decsum = decsum + 1
        else:
            decsum = decsum + ord(char)
    checksum = decsum % 256
    if len(str(checksum)) == 1:
        checksum = '00' + str(checksum)
    elif len(str(checksum)) == 2:
        checksum = '0' + str(checksum)
    else:
        checksum = str(checksum)
    return checksum


script_directory = os.getcwd()
script_home_directory = os.path.join(script_directory, os.path.pardir)

logs_directory = os.path.join(script_home_directory, 'logs/')
logname = (os.path.basename(__file__) + '.log')
logfilename = os.path.join(logs_directory, logname)
with open(logfilename, 'w') as x:
    x.write('')

logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)

cfg_directory = os.path.join(script_directory, '../cfg/')
markts_cycls_config = os.path.join(cfg_directory, 'TradingCyclesSettings', 'markets_cycles_settings.cfg')
if not os.path.isfile(markts_cycls_config):
    markts_cycls_config = os.path.join(cfg_directory, 'markets_cycles_settings.cfg')
fsb_host = sys.argv[1]
fsb_port = int(os.environ['S_REG_PORT_NO'])-12 
datetime_value =datetime.datetime.today()
current_date = datetime.datetime.strftime(datetime_value, "%Y/%m/%d")
action = str(sys.argv[2])
fsb_logon = '8=FIXT.1.1\x019=33\x0135=451\x01452=7207\x01453=1\x01456=BRIDGE\x0110=202\x01'
mm_logon = '8=FIXT.1.1\x019=149\x0135=506\x012000=2\x012003=QA_exp13\x012010=30\x012018=mit123\x012031=MITQA\x01' \
           '2032=172.25.70.148\x012033=Windows 2000\x012034=Qwert\x012035=128M\x012036=Trader\x012037=1.1.1.1\x01' \
           '2042=2\x0110=213\x01'
fsb_bridge_port = int(os.environ['S_REG_PORT_NO']) + 700
fsb_bridge = '8=FIXT.1.1\x019=25\x0135=452\x01455=12\x01456=BRIDGE\x0110=087\x01'
logging.info('FSB Bridge port creating')
logging.info('FSB_BRIDGE message: ' + fsb_bridge)
logging.info('FSB_BRIDGE port: ' + str(fsb_bridge_port))
netcat(fsb_host, fsb_bridge_port, fsb_bridge)
time.sleep(3)
if action == 'close_markets':
    markets = get_markets(markts_cycls_config)
    stopmarkets_cmd = fsb_logon + mm_logon
    for market in markets:
        if re.match(' ', market):
            market = market.replace(' ',  '', 1)
        msg_body = "35=2161|2010=1|2047=test|2306=4|2620=QA_exp13|4220=1|451=2163|2238=" + market + "|"
        msg_length = len(msg_body)
        market_fsb_string = "8=FIXT.1.1|9=" + str(msg_length) + "|" + msg_body
        checksum = checksum_calculate(market_fsb_string)
        logging.debug("checksum of " + market + ': '  + checksum)
        cmd = '8=FIXT.1.1\x019=' + str(msg_length) + '\x0135=2161\x012010=1\x012047=test\x012306=4\x01' \
                                                     '2620=QA_exp13\x014220=1\x01451=2163\x012238=' + market + \
              '\x0110=' + str(checksum) + '\x01'
        stopmarkets_cmd = stopmarkets_cmd + cmd
    logging.info('CLOSE MARKETS: ' + cmd)
    logging.info('CLOSE MARKETS PORT: ' + str(fsb_port))
    netcat(fsb_host, fsb_port, stopmarkets_cmd)
    time.sleep(2)
elif action == 'close_day':
    #endofday_msg_body = "8=FIXT.1.1|9=31|35=2161|2306=2|2002=" + current_date + "|"
    endofday_msg_body = "8=FIXT.1.1|9=45|35=2161|2620=QA_exp13|2306=2|2002=" + current_date + "|"
    checksum = checksum_calculate(endofday_msg_body)
    #cmd = '8=FIXT.1.1\x019=31\x0135=2161\x012306=2\x012002=' + current_date + '\x0110=' + str(checksum) + '\x01'
    cmd = '8=FIXT.1.1\x019=45\x0135=2161\x012620=QA_exp13\x012306=2\x012002=' + current_date + '\x0110=' + str(checksum) + '\x01'
    eod_cmd = fsb_logon + mm_logon + cmd
    logging.info('DAY END: ' + cmd)
    logging.info('DAY END PORT: ' + str(fsb_port))
    netcat(fsb_host, fsb_port, eod_cmd)
    time.sleep(2)
