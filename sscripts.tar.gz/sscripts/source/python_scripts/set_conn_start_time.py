#! /usr/bin/env python

import cx_Oracle
import common
import generate_sql_procedure
import os
import subprocess
from sys import argv


# get list of dictionaries from cursor query result
#
def rows_to_dict_list(cursor):
    columns = [i[0] for i in cursor.description]
    return [dict(zip(columns, row)) for row in cursor]


# retrieve list with names of primary processes
# for a certain partition def name
# example:
#     find_all_pri_proc_names(db_str, part_def='Common') - will retrieve
#         all primary process names that in Common process group:
#         ['Common:1:1:AuthServer:1', 'Common:1:1:CheckPointer:1', ..., 'Common:1:1:ServiceDesk:1']
# by default db_str is only required - all primary process names in the system will be returned
# given values in other args will narrow down the result list
#
def find_all_pri_proc_names(sg_db_str, part_def='%', part_inst_id='%', part_inst_sub_id='%', proc_def='%'):
    connection = cx_Oracle.connect(sg_db_str)
    cursor = connection.cursor()
    query = """select PART_DEF, PART_INST_ID, PART_INST_SUB_ID, PROC_DEF, PROC_INST_ID
    from SG4_INSTANCES
    where PART_DEF like '{partdef}'
    and PART_INST_ID like '{partinstid}'
    and PART_INST_SUB_ID like '{partinstsubid}'
    and PROC_DEF like '{procdef}'
    and PROC_INST_ID = 1""".format(partdef=part_def,
                                            partinstid=part_inst_id,
                                            partinstsubid=part_inst_sub_id,
                                            procdef=proc_def)
    result = cursor.execute(query)
    result = [':'.join(map(str, x)) for x in result.fetchall()]
    connection.close()
    
    return result


if __name__ == '__main__':
    # path to EST config
    EST_CFG_PATH = argv[1]

    # get ATS db string
    schema_name = 'ATS'
    ats_db_str = common.get_db_string(schema_name)

    # get SG db string
    schema_name = 'SG'
    sg_db_str = common.get_db_string(schema_name)

    # get DAY START TIME from ATS
    connection = cx_Oracle.connect(ats_db_str)
    cursor = connection.cursor()
    query = """select PARAMETER_VALUE
    from ATS_PARAMETER_VALUES
    where PARAMETER_ID = (
        SELECT PARAMETER_ID
        FROM ATS_PARAMETER_DEFS
        WHERE PARAMETER_NAME = 'OP_DAY_START_TIME'
    )"""
    result = cursor.execute(query)
    result = rows_to_dict_list(result)
    DAY_START_TIME = result[0]['PARAMETER_VALUE']
    connection.close()

    # get time windows between day start <-> market start <-> pre-trading start
    est_config = generate_sql_procedure.parse_exactpro_common_cfg(EST_CFG_PATH)
    offset_market_start = est_config['OFFSET_MARKETS_START']
    offset_pretrading = est_config['NO_SESSION_BEFORE_PRE_DURATION']

    # get time for start of markets and connection start time
    MARKET_START_TIME = generate_sql_procedure.get_new_timestamp(DAY_START_TIME, offset_market_start)
    offset_conn_start_time = int(offset_pretrading) / 2
    CONNECTION_START_TIME = generate_sql_procedure.get_new_timestamp(MARKET_START_TIME, offset_conn_start_time)

    # find names of all pricing servers in the system
    pricing_names = find_all_pri_proc_names(sg_db_str, part_def='Pricing')

    # generate ssi command and execute it to set connection start time to appropriate value
    params = {
        'Config Group': 'OUTBOUND_CONNECTIONS',
        'Config ID': 'CONNECTION_START_TIME',
        'Value': CONNECTION_START_TIME,
    }
    for proc_name in pricing_names:
        params['Process ID'] = proc_name
        ssi_cmd = common.build_ssi_cmd('Update Process Config Value', params)
        os.system(ssi_cmd)


