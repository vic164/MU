#! /usr/bin/env python

import os
import re
import pwd
import sys
import time
import shutil
import datetime
import csv
import tarfile
import common
import logging
import cx_Oracle
import pandas as pd
import xml.etree.ElementTree as ET


def get_system_date():
    sg_db_string = common.get_db_string('SG')
    sg_query = "SELECT VALUE FROM SG4_CONFIGS WHERE PARAMETER = 'SYSTEM_DATE'"
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    try:
        db_cursor.execute(sg_query)
        sdy, sdm, sdd = db_cursor.fetchone()[0].split('/')
    except cx_Oracle.DatabaseError as e:
        error = e.args
        print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e), e)
        t = datetime.datetime.today()
        sdy = datetime.datetime.strftime(t, "%Y")
        sdm = datetime.datetime.strftime(t, "%m")
        sdd = datetime.datetime.strftime(t, "%d")
    answer = "{y}{m}{d}".format(y=sdy, m=sdm, d=sdd)
    return answer
 

def get_info_from_yaan(system_date):
    yaan_db_string = common.get_db_string('YAAN')
    query = """SELECT CATEGORY, ACTION, TIMESTAMP, OWNER, DESCRIPTION, USER_COMMENT, 
             SEVERITY, REJECT_REASON, ENTITY_ID, ENTITY_INSTANCE_ID from AUDIT_TRAIL 
             where TIMESTAMP like '{t}-%' AND CATEGORY = 'Market Manager' 
             ORDER BY TIMESTAMP DESC, SEQUENCE DESC""".format(t=system_date)
    db_connect = cx_Oracle.connect(yaan_db_string)
    db_cursor = db_connect.cursor()
    try:
        db_cursor.execute(query)
        answer = db_cursor.fetchall()
    except cx_Oracle.DatabaseError as e:
        logging.error('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e), e)
        logging.error('Cannot found AuditTrail table. Something went wrong')
        exit()
    return answer
    

def reformat_audit_trail_info(at):
    pd.set_option('display.max_columns', 11)
    header = ['Category', 'Action', 'Timestamp', 'Owner', 'Description', 'User Comment', 
              'Severity', 'Reject Reason', 'Entity', 'Entity Instance ID']
    result = pd.DataFrame(at, columns=header)
    return result


def get_action_entity_map():
    result = {}
    config = os.path.join(os.environ['HOME'], 'current', 'configs', 'MarketManager', 
                          'SpTemplates', 'Resources', 'Enums.spres')
    ctree = ET.parse(config)
    croot = ctree.getroot()
    for enum in croot:
        if enum.attrib['name'] in ['MM_ActivityLog_Action', 'MM_ActivityLog_Entity_Id']:
            main_key = enum.attrib['name']
            map = {}
            for i in enum:
                value = i.attrib['value']
                description = i.text
                map[value] = description
            result[main_key] = map
    return result


def update_audit_trail(at, cfg):
    def update_action():
        at['Action'] = at['Action'].apply(str)
        for i, row in at.iterrows():
            old_value = str(row['Action'])
            if old_value == '3000':
                logging.warning('FSB ERROR Found. Skip')
                continue
            new_value = cfg['MM_ActivityLog_Action'][old_value]
            at.at[i, 'Action'] = new_value

    def update_entity_id():
        at['Entity'] = at['Entity'].apply(str)
        for i, row in at.iterrows():
            old_value = str(row['Entity'])
            try:
                cfg_key = re.search('[0-9]{1,}', old_value).group(0)
                new_value = cfg['MM_ActivityLog_Entity_Id'][cfg_key]
                if new_value == 'Instruments':
                    new_value = 'Instrument'
                elif new_value == 'Markets':
                    new_value = 'Market'
            except Exception:
                new_value = 'None'
            at.at[i, 'Entity'] = new_value

    def update_timestamps():
        now_timestamp = time.time()
        offset = datetime.datetime.fromtimestamp(now_timestamp) - datetime.datetime.utcfromtimestamp(now_timestamp)
        for i, row in at.iterrows():
            old_value = str(row['Timestamp'])
            datetime_moment = datetime.datetime.strptime(old_value, "%Y%m%d-%H:%M:%S")
            new_datetime_moment = datetime_moment + offset
            new_value = datetime.datetime.strftime(new_datetime_moment, "%d/%m/%Y-%H:%M:%S")
            at.at[i, 'Timestamp'] = new_value

    def update_severity():
        map = {'1': 'Information', '2': 'Warning', '3': 'Error'}
        at['Severity'] = at['Severity'].apply(str)
        for i, row in at.iterrows():
            old_value = str(row['Severity'])
            new_value = map[old_value]
            at.at[i, 'Severity'] = new_value

    update_action()
    update_entity_id()
    update_timestamps()
    update_severity()
    return at

def save_csv(at, csvpath):
    at.to_csv(csvpath, index=False)


if __name__ == '__main__':
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)

    system_date = get_system_date()
    common.info_output('Getting AuditTrail info for ' + str(system_date))
    audit_trail_info = get_info_from_yaan(system_date)
    common.info_output('Reformat AuditTrail info')
    audit_trail_reformatted = reformat_audit_trail_info(audit_trail_info)
    common.info_output('Parse MM Enum config... ')
    parsed_config = get_action_entity_map()
    common.info_output('Update AuditTrail info')
    updated_audit_trail = update_audit_trail(audit_trail_reformatted, parsed_config)
    
    whoami = pwd.getpwuid(os.getuid())[0]
    backup_folder = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'temp', 'download_tables', 'AuditTrail')
    os.makedirs(backup_folder, exist_ok=True)
    
    common.info_output('Saving csv file')
    csv_path = os.path.join(backup_folder, 'Audit_Trail.csv')
    save_csv(updated_audit_trail, csv_path)

    common.info_output('Backup Yaala Audit_Trail table completed', logfilename)
    common.info_output('==============\nExecution is completed', logfilename)
