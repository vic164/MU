#!/usr/bin/env python

import os
import re
import sys
import shutil
import logging
import subprocess
import time
import datetime
import cx_Oracle
import configparser
import tarfile


class bcolors:
    OKINFO = '\033[92m'
    WARNING = '\033[93m'
    ERRORINFO = '\033[93m'
    ENDC = '\033[0m'


# Global paths
home_path = os.environ['HOME']
system_home_path = os.environ['SYSTEM_HOME']
oracle_home_path = os.environ['ORACLE_HOME']
mitops_dir_path = os.environ['SYSTEM_OPS']

try:
    tnsnames_file_path = os.path.join(os.environ['TNS_ADMIN'], 'tnsnames.ora')
except KeyError:
    tnsnames_file_path = os.path.join(oracle_home_path, 'network', 'admin', 'tnsnames.ora')
db_cfg_file_path = os.path.join(home_path, 'current', 'mitops', 'CFG', 'db.cfg')
script_directory = os.path.dirname(os.path.realpath(__file__))
logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')


def check_file_exist(file_path, exit_if_not_exist):
    if not os.path.isfile(file_path):
        logging.error('File ' + file_path + ' not found')
        if exit_if_not_exist:
            exit(1)
        else:
            return False


""" LOGGING """
def debug_output(info_string, log_file_path=""):
    output_string = '[DEBUG]    ' + str(info_string)
    print(output_string)
    if log_file_path:
        with open(log_file_path, 'a') as x:
            x.write(output_string + '\n')


def info_output(info_string, log_file_path=""):
    output_string = '[INFO]     ' + str(info_string)
    print(bcolors.OKINFO + output_string + bcolors.ENDC)
    if log_file_path:
        with open(log_file_path, 'a') as x:
            x.write(output_string + '\n')


def error_output(info_string, log_file_path=""):
    output_string = '[ERROR]    ' + str(info_string)
    print(bcolors.ERRORINFO + output_string + bcolors.ENDC)
    if log_file_path:
        with open(log_file_path, 'a') as x:
            x.write(output_string + '\n')


def warning_output(info_string, log_file_path=""):
    output_string = '[WARN]     ' + str(info_string)
    print(bcolors.WARNING + output_string + bcolors.ENDC)
    if log_file_path:
        with open(log_file_path, 'a') as x:
            x.write(output_string + '\n')


""" Work with database """
def get_connectstring_from_envvar(schemaname):
    var_name = schemaname.upper() + '_DB_STRING'
    try:
        conn_string = os.environ[var_name]
    except KeyError:
        conn_string = ''
    return conn_string


def get_connectstring_from_dbcfg(schemaname):
    conn_string = ''
    var_name = schemaname.upper() + ':'
    db_cfg_path = os.path.join(os.environ['SYSTEM_OPS'], 'CFG', 'db.cfg')
    with open(db_cfg_path) as cfg_contain:
        for cfg_line in cfg_contain.readlines():
            if re.search(var_name, cfg_line):
                conn_string = cfg_line.replace(var_name, '').replace('\n', '')
                if conn_string.startswith('wallet:/'):
                    conn_string = conn_string.replace('wallet:/', '').replace('/', '/@')
    return conn_string


def get_connectstring_from_tnsnames(schemaname):
    conn_string = ''
    tns_filepath = os.environ['TNS_ADMIN']
    if not tns_filepath:
        return conn_string
    tns_file = os.path.join(tns_filepath, 'tnsnames.ora')
    var_name = schemaname.lower()
    with open(tns_file) as cfg_contain:
        for cfg_line in cfg_contain.readlines():
            if re.search(var_name, cfg_line):
                split_string = cfg_line.split('/')
                n = len(split_string) -1
                last = split_string[n]
                conn_string = '/@' + last.replace('.tns', '').replace('\n', '')
    return conn_string


def get_db_string(schema_name):
    # try to connect with environment variable
    db_string = get_connectstring_from_envvar(schema_name)
    if not db_string:
        db_string = get_connectstring_from_dbcfg(schema_name)
    if not db_string:
        return ''
    try:
        connection = cx_Oracle.connect(db_string)
        connection.close()
    except Exception as e:
        db_string = get_connectstring_from_tnsnames(schema_name)
        try:
            connection = cx_Oracle.connect(db_string)
            connection.close()
        except Exception as e:
            error_output('something not right with connection string')
            error_output(e)
    return db_string


def build_ssi_cmd(cmd_desc, parameters):
    usage_desc = []
    ssi_code = None
    ssi_general_help = os.popen('SSI').read()
    for ssi_help_string in ssi_general_help.split('\n'):
        if re.search(cmd_desc, ssi_help_string):
            ssi_code = re.search('[0-9]{1,}', ssi_help_string).group(0)
    if not ssi_code and cmd_desc == 'Flag Value':
        ssi_code = '1'
    try:
        ssi_code_help = os.popen('SSI ' + ssi_code).read()
        for ssi_help_string in ssi_code_help.split('\n'):
            if re.search('Usage', ssi_help_string):
                usage_desc = ssi_help_string
    except NameError:
        logging.error('SSI code for description " ' + cmd_desc + '" not found. Exit')
        exit(1)
    if not usage_desc:
        logging.error('SSI decription not found..')
        exit(1)
    full_ssi_cmd = 'SSI {s} '.format(s=ssi_code,)
    for i in range(1, len(usage_desc.split('<'))):
        ssi_cmd_parameter = usage_desc.split('<')[i].replace('> ', '').replace('>', '')
        if ssi_cmd_parameter not in parameters.keys():
            logging.error('Parameter "' + ssi_cmd_parameter + '" not found in the given set:')
            logging.debug(parameters)
            exit(1)
        full_ssi_cmd = '{f} {p} '.format(f=full_ssi_cmd, p=parameters[ssi_cmd_parameter],)
    return full_ssi_cmd


def get_admin_process_list(path=os.path.join(mitops_dir_path, 'CFG', 'user.cfg')):
    # admin_process_list = ""
    admin_process_list = []
    with open(path) as admin_config:
        admin = False
        for config_line in admin_config.readlines():
            if re.search('<ADMIN_BIN_LIST>', config_line):
                admin = True
                continue
            if re.search('<\/ADMIN_BIN_LIST>', config_line):
                break
            if admin and not re.search('#', config_line):
                process_name = config_line.replace(" ", "").replace("\n", "").split('=')[1]
                if process_name:
                    admin_process_list.append(process_name)
    return admin_process_list


def is_binary_file_exist(process_name):
    admin_path = os.path.join(home_path, 'current', 'admin')
    if process_name in os.listdir(admin_path):
        return True
    else:
        return False


def check_process_on_all_machines(process_name, hosts):
    for host in hosts:
        if host == '':
            continue
        ps = subprocess.Popen(["ssh", host, "ps x"], stdout=subprocess.PIPE)
        if re.search(process_name, str(ps.stdout.read())):
            logging.debug("Process " + process_name + " has been started on " + host)
        else:
            logging.error("Process " + process_name + " has not been started on " + host)
            return False
    return True


def check_processes(process_list, hosts):
    for process_name in process_list:
        if process_name == 'SGA':
            check_result = check_process_on_all_machines(process_name, hosts)
            if not check_result:
                return False
            continue
        elif process_name in ['SerLS', 'SGCM', 'SSM']:
            full_process_name = 'SysGuard:1:1:{name}:1'.format(name=process_name,)
            host = get_host_for_process(full_process_name)
            ps = subprocess.Popen(["ssh", host, "ps x"], stdout=subprocess.PIPE)
            if re.search(process_name, str(ps.stdout.read())):
                logging.debug("Process " + process_name + " has been started on " + host)
            else:
                logging.error("Process " + process_name + " has not been started on " + host)
                return False
        else:
            ps = subprocess.Popen(["ps x"], shell=True, stdout=subprocess.PIPE)
            file_exist = is_binary_file_exist(process_name)
            if file_exist:
                if re.search(process_name, str(ps.stdout.read())):
                    logging.debug("Process " + process_name + " has been started")
                else:
                    logging.error("Process " + process_name + " has not been started")
                    return False
    return True


def check_processes_stopped(process_list, hosts):
    for process_name in process_list:
        if process_name == 'SGA':
            check_result = check_process_on_all_machines(process_name, hosts)
            if check_result:
                return False
            continue
        elif process_name in ['SerLS', 'SGCM', 'SSM']:
            full_process_name = 'SysGuard:1:1:{name}:1'.format(name=process_name,)
            host = get_host_for_process(full_process_name)
            ps = subprocess.Popen(["ssh", host, "ps x"], stdout=subprocess.PIPE)
            if re.search(process_name, str(ps.stdout.read())):
                logging.debug("Process " + process_name + " has been started on " + host)
                return False
            else:
                logging.error("Process " + process_name + " has not been started on " + host)
        else:
            ps = subprocess.Popen(["ps x"], shell=True, stdout=subprocess.PIPE)
            file_exist = is_binary_file_exist(process_name)
            if file_exist:
                if re.search(process_name, str(ps.stdout.read())):
                    logging.debug("Process " + process_name + " has been started")
                    return False
                else:
                    logging.error("Process " + process_name + " has not been started")
    return True


def closing_prices_preparing():
    cfg_dir = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'cfg')
    closing_prices_file = None
    for file_name in os.listdir(cfg_dir):
        if re.match('ClosingPrices_', file_name):
            if os.path.splitext(file_name)[1] == '.csv':
                closing_prices_file = os.path.join(cfg_dir, file_name)
                break
    if closing_prices_file:
        today_date = datetime.datetime.today()
        today = datetime.datetime.strftime(today_date, "%Y%m%d")
        new_name = 'ClosingPrices_' + today + '.csv'
        new_path = os.path.join(cfg_dir, new_name)
        os.rename(closing_prices_file, new_path)
        return str(new_path)
    else:
        return None


def get_list_of_strings(list_of_tuples):
    new = []
    for i in list_of_tuples:
        new.append(i[0])
    return new


def get_host_for_process(process_name):
    """ Function for find host of single process
    :param process_name: full name (Example: SysGuard:1:1:SerLS:1)
    PART_DEF:PART_INST_ID:PART_INST_SUB_ID:PROC_DEF:PART_INST_SUB_ID
    :return: host_name
    """
    sg_db_string = get_db_string('SG')
    part_def, part_inst_id, part_sub_id, proc_def, proc_id = process_name.split(':')
    query = "SELECT MACHINE FROM SG4_INSTANCES WHERE PART_DEF = '{partdef}' and PART_INST_ID = '{pinstid}' and PART_INST_SUB_ID = '{psubid}' and " \
            "PROC_DEF = '{procdef}' and PROC_INST_ID = '{pid}'".format(partdef=part_def, pinstid=part_inst_id, psubid=part_sub_id, procdef=proc_def, pid=proc_id,)
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    query_answer = db_cursor.execute(query)
    answer = query_answer.fetchall()
    try:
        machine = answer[0][0]
    except IndexError:
        error_output('Machine for ' + str(process_name) + ' not found')
        return ''
    query = "SELECT HOST FROM SG4_MACHINES WHERE NAME = '{m}'".format(m=str(machine),)
    query_answer = db_cursor.execute(query)
    answer = query_answer.fetchall()
    db_cursor.close()
    db_connect.close()
    try:
        process_host = answer[0][0]
    except IndexError as e:
        error_output('Host for machine ' + str(machine) + ' not found: ' + str(e))
        return ''
    return process_host


def parse_global_cfg():
    global_cfg_path = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'cfg', 'global.cfg')
    config_parser = configparser.ConfigParser()
    config_parser.read(global_cfg_path)
    parsed_info = {}
    for section in config_parser.sections():
        section_info = {}
        for parameter in config_parser[section]:
            parameter_value = config_parser[section][parameter]
            section_info[parameter] = parameter_value.replace('\'', '').replace('"', '')
        parsed_info[section] = section_info
    return parsed_info

    
def get_all_hosts():
    db_conn_string = get_db_string('SG') 
    sg_con = cx_Oracle.connect(db_conn_string)
    sg_cur = sg_con.cursor()
    sg_cur.execute("select HOST from SG4_MACHINES")
    hosts_db = sg_cur.fetchall()
    hosts = get_list_of_strings(hosts_db)
    sg_cur.close()
    sg_con.close()
    return hosts


def get_flag_status(flag_name):
    sg_db_string = get_db_string('SG')
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    query = "SELECT FLAG_VALUE FROM SG4_FLAG_VALUES WHERE FLAG_NAME = \'{f}\'".format(f=flag_name)
    query_answer = db_cursor.execute(query)
    answer = query_answer.fetchall()
    flag_status = re.match('[0-9]{2}', answer[0][0]).group(0)
    db_cursor.close()
    db_connect.close()
    return flag_status


def get_flag_status_part_specific(flag_name, partition):
    sg_db_string = get_db_string('SG')
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    query = "SELECT FLAG_VALUE FROM SG4_FLAG_VALUES WHERE FLAG_NAME = \'{f}\'".format(f=flag_name)
    query_answer = db_cursor.execute(query)
    answer = query_answer.fetchall()
    flag_status = '0' + answer[0][0][:int(partition)+1][int(partition):]
    # flag_status = re.match("[0-9]{p}", answer[0][0]).group(0)
    return flag_status


def track_flag_status(flag_name, flag_status, timer=0):
    full_global_cfg_info = parse_global_cfg()
    if timer == 0:
        timer = int(full_global_cfg_info['General']['timer_flag'].replace('\'', '').replace('"', ''))
    while timer > 0:
        current_flag_status = get_flag_status(flag_name)
        if current_flag_status == flag_status:
            return ''
        else:
            x = '{s}.'.format(s=timer)
            print(x, end='\r')
            timer -= 1
            time.sleep(1)
    return 'error'


def get_list_of_all_flags():
    sg_db_string = get_db_string('SG')
    query = "SELECT FLAG_ID FROM SG4_FLAGS" 
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    query_answer = db_cursor.execute(query)
    answer = query_answer.fetchall()
    list_of_all_flags = get_list_of_strings(answer)
    db_cursor.close()
    db_connect.close()
    return list_of_all_flags


def execute_ssi_cmd_for_flag(flag_name, status, owner='Common'):
    flag_parameters = {}
    flag_parameters['flag_id'] = flag_name
    flag_parameters['flag_value'] = status.replace('0', '')
    flag_parameters['owner'] = owner
    flag_parameters['partition'] = '1'
    flag_parameters['script_id'] = '1'
    ssi_cmd = build_ssi_cmd('Flag Value', flag_parameters)
    ssi_cmd = ssi_cmd.replace('\'', '').replace('\ $', '')
    debug_output('ssi cmd has been generated: ' + str(ssi_cmd))
    x = subprocess.Popen(ssi_cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True, executable='/bin/bash', universal_newlines=True)
    x.wait()
    out, err = x.communicate()
    debug_output('out: ' + str(out))
    debug_output('err: ' + str(err))
    x.kill()


def run_shell_cmd_with_wait(cmd):
    p = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                         shell=True, universal_newlines=True)
    out, err = p.communicate()
    print(out)
    print(err)
    p.wait()
    p.kill()


def get_release_namepart():
    RFCs = []
    Releases = []
    sg_select_cmd = 'select DEPLOYED_DATETIME AS DEP_DATE, REL_VERSION, REL_TYPE from RELEASE_HISTORY ORDER BY DEPLOYED_DATETIME DESC'
    mtech_select_cmd = 'select TIMESTAMP AS DEP_DATE, RELEASE from MIRIS_AUDIT_TABLE  ORDER BY TIMESTAMP DESC'
    # SG part
    sg_db_string = get_db_string('SG')
    mtech_db_string = get_db_string('MTECH')
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    query_answer = db_cursor.execute(sg_select_cmd)
    answer = query_answer.fetchall()
    db_cursor.close()
    db_connect.close()
    for row in answer:
        install_date, release_name, release_type = row
        if not install_date or not release_name:
            continue
        if release_type in ['RTOOL', 'RFC']:
            release_name = release_name.replace(' ', '')
            new_entry = (install_date, release_name)
            RFCs.append(new_entry)
    # MTECH part
    db_connect = cx_Oracle.connect(mtech_db_string)
    db_cursor = db_connect.cursor()
    query_answer = db_cursor.execute(mtech_select_cmd)
    answer = query_answer.fetchall()
    db_cursor.close()
    db_connect.close()
    for row in answer:
        install_date, release_name = row
        if not install_date or not release_name:
            continue
        if re.search('RFC', release_name.upper()):
            release_name = release_name.replace(' ', '')
            new_entry = (install_date, release_name)
            RFCs.append(new_entry)
        elif re.search('LSEG', release_name.upper()):
            release_name = release_name.replace(' ', '')
            new_entry = (install_date, release_name)
            Releases.append(new_entry)
    # Build release_namepart
    latest_install_date = None
    latest_release = None
    for row in Releases:
        install_date, release_name = row
        if not latest_install_date or install_date > latest_install_date:
            latest_install_date = install_date
            latest_release = release_name
    if latest_install_date and latest_release:
        rfcs_on_release = []
        for rfc_row in sorted(RFCs):
            rfc_date, rfc_name = rfc_row
            if rfc_date > latest_install_date:
                rfc_shortname = re.search('RFC[_]{0,}[0-9]{1,}.*', rfc_name).group(0)
                rfc_shortname = rfc_shortname.replace('_', '')
                if rfc_shortname not in rfcs_on_release:
                    rfcs_on_release.append(rfc_shortname)
        r = re.search('[0-9]{1,}\.[0-9]{1,}\.[0-9]{1,}\.[0-9]{1,}\.i[0-9]{1,}[_V0-9]{0,}', latest_release).group(0)
        final_name = '_' + r
        if rfcs_on_release:
            for r in rfcs_on_release:
                final_name = final_name + '_' + r
    else:
        final_name = ''
    return final_name


if __name__ == '__main__':
    if str(sys.argv[1]) == 'SSI':
        if str(sys.argv[2]) == 'Global':
            cmd_desc = 'Global Config'
            parameters = {}
            parameters['Config Group'] = 'Global'
            parameters['Config ID'] = str(sys.argv[3])
            parameters['Value'] = str(sys.argv[4])
            ssi_cmd = build_ssi_cmd(cmd_desc, parameters)
            if ssi_cmd:
                print(ssi_cmd)
                sys.exit(ssi_cmd)
            else:
                exit(1)
        elif str(sys.argv[2]) == 'Flag':
            cmd_desc = 'Flag Value'
            parameters = {}
            parameters['flag_id'] = sys.argv[3]
            parameters['flag_value'] = sys.argv[4]
            parameters['owner'] = sys.argv[5]
            parameters['partition'] = sys.argv[6]
            parameters['script_id'] = sys.argv[7]
            ssi_cmd = build_ssi_cmd(cmd_desc, parameters)
            if ssi_cmd:
                print(ssi_cmd)
                sys.exit(0)
            else:
                exit(1)
        elif str(sys.argv[2]) == 'Sequence':
            sequence_name = str(sys.argv[3])
            cmd_desc = str(sys.argv[2])
            parameters = {}
            parameters['Sequence Name'] = sequence_name
            ssi_cmd = build_ssi_cmd(cmd_desc, parameters)
            print(ssi_cmd)
            sys.exit(0)

    elif str(sys.argv[1]) == 'db_string':
        db_string = get_db_string(str(sys.argv[2]))
        if db_string:
            print(db_string)
            exit(0)
        else:
            exit(1)
    elif str(sys.argv[1]) == 'admin_processes':
        logfilename = os.path.join(logs_directory, (str(sys.argv[1]) + '_' + str(sys.argv[2]) + '.log'))
        with open(logfilename, 'w') as x:
            x.write('')
        logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
        if str(sys.argv[2]) == 'check':
            hosts = str(sys.argv[3]).split(' ')
            process_list = get_admin_process_list()
            all_admin_process_started = check_processes(process_list, hosts)
            if all_admin_process_started:
                print("Success")
                exit(0)
            else:
                print("ERROR")
                exit(1)
        elif str(sys.argv[2]) == 'check_down':
            hosts = str(sys.argv[3]).split(' ')
            process_list = get_admin_process_list()
            all_admin_process_stopped = check_processes_stopped(process_list, hosts)
            if all_admin_process_stopped:
                print("Success")
                exit(0)
            else:
                print("ERROR")
                exit(1)

        exit(0)
    elif str(sys.argv[1]) == 'get_host_for_process':
        process = str(sys.argv[2])
        host = get_host_for_process(process)
        if host:
            print(host)
            exit(0)
        else:
            print('ERROR')
            exit(1)
    elif str(sys.argv[1]) == 'track_flag_status':
        flag_name = str(sys.argv[2])
        flag_status = str(sys.argv[3])
        if len(sys.argv) > 4:
            wt = int(sys.argv[4])
        else:
            wt = 60000
        track_flag_status(flag_name, flag_status, wt)
    elif str(sys.argv[1]) == 'get_release_namepart':
        release_namepart = get_release_namepart()
        print(release_namepart)
    elif str(sys.argv[1]) == 'get_release':
        release_namepart = get_release_namepart()
        print(release_namepart)

