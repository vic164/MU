#! /usr/bin/env python

import os
import sys
import shutil
import eod_upload_rd


if __name__ == '__main__':
    script_directory = os.path.abspath(os.path.dirname(__file__))
    script_home_directory = os.path.dirname(script_directory)
    logs_directory = os.path.join(script_home_directory, 'logs')
    logname = (os.path.basename(__file__) + '.log')
    logfilename = os.path.join(logs_directory, logname)
    with open(logfilename, 'w') as x:
        x.write('')
    if len(sys.argv) < 2:
        print('Nothing to upload. Exit')
        exit()
    stuff_for_upload = str(sys.argv[1]) 
    if not os.path.exists(stuff_for_upload):
        print('Nothing to upload. Exit')
        exit()
    temp_dirpath = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'temp', 'upload_now')
    if os.path.isfile(stuff_for_upload):
        os.makedirs(temp_dirpath)
        shutil.copyfile(stuff_for_upload, temp_dirpath)
        upload_now = temp_dirpath
    elif os.path.isdir(stuff_for_upload):
        upload_now = stuff_for_upload
    else:
        print('Nothing to upload. Exit')
        exit()
    eod_upload_rd.upload_set(upload_now)
    #if os.path.isdir(temp_dirpath):
    #    shutil.rmtree(temp_dirpath, ignore_errors=True)

