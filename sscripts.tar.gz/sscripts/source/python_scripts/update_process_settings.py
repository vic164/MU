#!/usr/bin/env python

import re
import os
import sys
import pwd
import csv
import time
import shutil
import logging
import cx_Oracle
import datetime
import tarfile
import xml.etree.ElementTree as ET
import common


if __name__ == '__main__':
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
    db_connection_string = common.get_db_string('SG')
    common.info_output('Backup of ProcessSettings_BACKUP before upload new settings', logfilename)
    backup_dirpath = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts',
                                  'temp', 'download_tables', 'ProcSettings')
    os.makedirs(backup_dirpath, exist_ok=True)
    common.info_output('Get information from BD...' ,  logfilename)        
    db_connect = cx_Oracle.connect(db_connection_string)
    db_cursor = db_connect.cursor()
    csv_file_dest = "SG4_CONFIGS_before_update.csv"
    csv_file_path = os.path.join(backup_dirpath, csv_file_dest)
    output_file = open(csv_file_path, 'w')
    output = csv.writer(output_file, dialect='excel')
    query = "SELECT * FROM SG4_CONFIGS" 
    try:
        db_cursor.execute(query)
    except cx_Oracle.DatabaseError as e:
        error, = e.args
        if not error.code == 942:
            common.error_output('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), logfilename)
    cols = []
    for col in db_cursor.description:
        cols.append(col[0])
    output.writerow(cols)
    for row_data in db_cursor: 
        output.writerow(row_data)
    output_file.close()
    common.info_output('Information from BD has been saved to {f}'.format(f=csv_file_dest,), logfilename)
    
    common.info_output('Start upload new settings to the system...', logfilename)
    try:
        config_path = str(sys.argv[1])
    except IndexError:
        common.error_output("ERROR! Cannot find config_file_path. Usage: ./" + str(sys.argv[0]) + " <config path>", logfilename)
        exit()
    if not os.path.isfile(config_path):
        common.error_output('Config file cannot be found: ' + str(sys.argv[2]), logfilename)
        exit(1)
    cmd_desc = 'Update Process Config'
    try:
        tree = ET.parse(config_path)
        root = tree.getroot()
        for proc_configurations in root:
            # SSI 'Process' <Process ID> <Config Group> <Config ID> <Value>
            if not proc_configurations.tag == 'Process':
                continue
            parameters = {}
            process_name = proc_configurations.attrib['name']
            parameters['Process ID'] = process_name
            for proc_cfg_grp_child in proc_configurations:
                process_cfg_grp = proc_cfg_grp_child.tag
                parameters['Config Group'] = process_cfg_grp
                for process_cfg_child in proc_cfg_grp_child:
                    process_cfg = process_cfg_child.tag
                    cfg_value = process_cfg_child.text
                    parameters['Config ID'] = process_cfg
                    parameters['Value'] = cfg_value
                    ssi_cmd = common.build_ssi_cmd(cmd_desc, parameters)
                    if ssi_cmd:
                        common.info_output('SSI cmd has been built: ' + ssi_cmd, logfilename)
                        os.system(ssi_cmd)
                    else:
                        common.error_output('Cannot build SSI cmd', logfilename)
    except Exception as e:
        common.error_output(str(e), logfilename)
        common.error_output('Please check config file. And try again', logfilename)
        exit(1)
    common.info_output('Backup of ProcessSettings_BACKUP after upload new setting to the system', logfilename)
    db_cursor = db_connect.cursor()
    csv_file_dest = "SG4_CONFIGS_after_update.csv"
    csv_file_path = os.path.join(backup_dirpath, csv_file_dest)
    output_file = open(csv_file_path, 'w')
    output = csv.writer(output_file, dialect='excel')
    query = "SELECT * FROM SG4_CONFIGS"
    try:
        db_cursor.execute(query)
    except cx_Oracle.DatabaseError as e:
        error, = e.args
        if not error.code == 942:
            common.error_output('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), logfilename)
    cols = []
    for col in db_cursor.description:
        cols.append(col[0])
    output.writerow(cols)
    for row_data in db_cursor: 
        output.writerow(row_data)
    output_file.close()
    db_connect.close()
    common.info_output('Information from BD has been saved to {f}'.format(f=csv_file_dest,), logfilename)
    common.info_output('==============\nExecution is completed', logfilename)
