#! /usr/bin/env python

import os
import re
import pwd
import shutil
import datetime
import logging
import tarfile
import subprocess
import configparser
import common


def get_bcpcfg_data():
    full_global_cfg_info = common.parse_global_cfg()
    backup_cfg_filename = full_global_cfg_info['General']['backups_cfg_name']
    backup_cfg_filepath = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'cfg',
                                       backup_cfg_filename.replace('"', '').replace('\'', ''))
    backup_config_parser = configparser.ConfigParser()
    backup_config_parser.read(backup_cfg_filepath)
    full_backup_cfg_info = {}
    for i in backup_config_parser:
        if i in ['General', 'DEFAULT']: continue
        setting_block = {}
        for j in backup_config_parser[i]:
            setting_block[j] = backup_config_parser[i][j].replace('"', '')
        setting_block['flag'] = backup_config_parser['General'][i.lower()].replace('"', '')
        full_backup_cfg_info[i] = setting_block
    return full_backup_cfg_info


def get_last_dirname(path_from_cfg):
    parrent_dir = os.path.dirname(path_from_cfg)
    max_date = 201901012345
    last_dir = ''
    for i in os.listdir(parrent_dir):
        if not os.path.isdir(os.path.join(parrent_dir, i)):
            continue
        dirname_timestamp = i.replace('_', '')
        if not re.search('[0-9]{12}', dirname_timestamp):
            continue
        if int(dirname_timestamp) > max_date:
            max_date = int(dirname_timestamp)
            last_dir = os.path.join(parrent_dir, i)
    if last_dir:
        answer = last_dir[:-2] + '*'
    else:
        answer = ''
    return answer


def check_settings(entry):
    mandatory_keys = ['backup_dir', 'max_age', 'source']
    notmandatory_keys = ['file_mask', 'run_before_backup']
    for key in mandatory_keys:
        if key not in entry.keys():
            logging.error('Mandatory field ' + str(key) + ' not found in config. Skip')
            return {}
        if key == 'max_age' and int(entry[key]) == 0:
            logging.error('Invalid value for max_age field found in config: ' + str(entry[key]) + '. Skip')
            return {}
        if key == 'source' and re.search('{{TODAY}}', entry[key]):
            new_path = get_last_dirname(entry[key])
            if new_path:
                logging.debug('New path has been found for ' + str(entry[key]) + ': ' + str(new_path))
                entry[key] = new_path
            else:
                logging.debug('New path has not been found for ' + str(entry[key]) + '.')
                entry[key] = os.path.dirname(entry[key])
    for key in notmandatory_keys:
        if key not in entry.keys():
            entry[key] = ''
    return entry


def check_source(source, hosts):
    for host in hosts:
        logging.debug('Check files on ' + str(host))
        check_source_dir = subprocess.Popen("ssh {h} 'ls {dd}'".format(h=host, dd=source),
                                            stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                                            shell=True, universal_newlines=True)
        out, err = check_source_dir.communicate()
        logging.debug('out: ' + str(out))
        logging.debug('err: ' + str(err))
        if out:
            return True
    logging.debug(err)
    return False


def run_other_script(script_path):
    if script_path and not os.path.isfile(script_path.replace('~', os.environ['HOME'])):
        logging.error(str(script_path) + ' not found.')
        return False
    if os.path.splitext(script_path)[1] == '.py':
        cmd = "if [ -f ~/.anaconda3 ]; then source ~/.anaconda3; fi && python {s}".format(s=script_path)
    else:
        cmd = "{s}".format(s=script_path)
    script_run = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                                  shell=True, universal_newlines=True)
    out, err = script_run.communicate()
    rc = script_run.returncode
    if str(rc) == '0':
        return True
    else:
        logging.error(err)
        return False


def prepare_backup_dir(backup_entry_info, envname, d_namepart, r_namepart):
    backup_dir_path = backup_entry_info['backup_dir']
    current_env_backup_path = os.path.join(backup_dir_path, envname)
    current_date_backup_path = os.path.join(current_env_backup_path,
                                            "{d}{r}".format(d=d_namepart, r=r_namepart))
    try:
        os.makedirs(current_date_backup_path, exist_ok=True)
    except PermissionError:
        logging.error('Cannot create folder ' + str(current_date_backup_path) + '. Operation not permitted')
        current_date_backup_path = ''
    return current_date_backup_path


def backup_files(source_dir, backup_folder, hosts, mask):
    for host in hosts:
        files_check = subprocess.Popen("ssh {h} 'ls {s}/{m}'".format(h=host, s=source_dir, m='*' + str(mask) + '*'),
                                       stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                                       shell=True, universal_newlines=True)
        out, err = files_check.communicate()
        if not out:
            continue
        p = subprocess.Popen("rsync -avz {h}:{s}/{m} {bkp_path}".format(h=host, s=source_dir, m='*' + str(mask) + '*',
                                                                    bkp_path=backup_folder),
                             stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                             shell=True, universal_newlines=True)
        out, err = p.communicate()
        logging.debug(out)
        logging.info('Files from host {h} have been copied'.format(h=host,))
    if not os.listdir(backup_folder):
        logging.error('Nothing to backup.')
        return


def archive_files(path):
    os.chdir(path)
    bname = os.path.basename(path)
    datenamepart = re.match('[0-9]{12}', bname).group(0)
    if re.search('DSG', path):
        for bfile in os.listdir(path):
            archive_name = datenamepart + '_' + bfile.replace(':', '_') + '.tar.gz'
            with tarfile.open(archive_name, 'w:gz') as arch:
                arch.add(bfile)
            archive_path = os.path.join(path, archive_name)
            if os.path.isfile(archive_path):
                os.remove(os.path.join(path, bfile))
    else:
        archive_name = datenamepart + '.tar.gz'
        with tarfile.open(archive_name, 'w:gz', format=tarfile.PAX_FORMAT) as arch:
            for bfile in os.listdir(path):
                arch.add(bfile)
        archive_path = os.path.join(path, archive_name)
        if os.path.isfile(archive_path):
            for bfile in os.listdir(path):
                if not bfile == archive_name:
                    fpath = os.path.join(path, bfile)
                    if os.path.isdir(fpath):
                        shutil.rmtree(fpath, ignore_errors=True)
                    else:
                        os.remove(fpath)


def deletion_old_backups(backup_dirpath, max_age, now_time):
    if not os.path.isdir(backup_dirpath):
        return
    for f_entry in os.listdir(backup_dirpath):
        f_entry_path = os.path.join(backup_dirpath, f_entry)
        if not re.search('[0-9]{8}', f_entry):
            continue
        datetime_namepart_fentry = re.search('[0-9]{8}', f_entry).group(0)
        date_f_entry = datetime.datetime.strptime(datetime_namepart_fentry, '%Y%m%d')
        delta = now_time - date_f_entry
        if delta.days > max_age:
            logging.debug('Folder {f} deleted as outdated (max age > {age} days)'.format(f=f_entry_path,
                                                                                         age=max_age))
            try:
                os.remove(f_entry_path)
            except IsADirectoryError:
                shutil.rmtree(f_entry_path)


if __name__ == '__main__':
    now_timestamp = datetime.datetime.now()
    log_timestamp = now_timestamp
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    # Logging setup
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    logging.getLogger('').addHandler(console)
    
    # General variables
    whoami = pwd.getpwuid(os.getuid())[0]
    date_namepart = datetime.datetime.strftime(now_timestamp, '%Y%m%d%H%M%S')
    release_namepart = common.get_release_namepart()
    hosts = common.get_all_hosts()
    
    # Read and processing backups.cfg
    backup_cfg_info = get_bcpcfg_data()
    for backup_entry_key in backup_cfg_info.keys():
        backup_entry = backup_cfg_info[backup_entry_key]
        # Check that backup enabled
        if backup_entry['flag'] == 'N':
            logging.info('Backup ' + str(backup_entry_key) + ' disabled')
            continue
        logging.info('Backup ' + str(backup_entry_key))
        logging.debug(backup_entry)

        # Review settings
        backup_entry['source'] = backup_entry['source'].replace('~', os.environ['HOME'])
        backup_entry['backup_dir'] = backup_entry['backup_dir'].replace('~', os.environ['HOME'])
        backup_entry = check_settings(backup_entry)
        
        # Run before script
        if 'run_before_backup' in backup_entry.keys():
            logging.info('Preparing source with ' + str(backup_entry['run_before_backup']) + ' script')
            run_before_scriptpath = backup_entry['run_before_backup']
            script_result = run_other_script(run_before_scriptpath)
            if script_result:
                logging.info('Script for preparation source (RUN_BEFORE_BACKUP) status: SUCCESS')
            else:
                logging.info('Script for preparation source (RUN_BEFORE_BACKUP) status: ERROR. Skip this backup')
                continue
        else:
            logging.debug('Nothing to do before backing up')

        # Check Source
        logging.info('Check source ')
        backup_source = backup_entry['source']
        is_source_ok = check_source(backup_source, hosts)
        if not is_source_ok:
            logging.error('Source ' + str(backup_source) + ' not found. Skip this backup')
            continue
        logging.info('Check source successfully completed: ' + str(backup_source))
        # Preparing backup folder
        logging.info('Creating backup folder')
        backup_dir_finpath = prepare_backup_dir(backup_entry, whoami, date_namepart, release_namepart)
        if not backup_dir_finpath:
            logging.error('Something not right happens while creating backup dir. Skip this backup')
            continue
        logging.info('Backup folder has been created: ' + str(backup_dir_finpath))

        # Backing up files
        logging.info('Backing up stuff')
        file_mask = backup_entry['file_mask'] if backup_entry['file_mask'] else '*'
        backup_files(backup_source, backup_dir_finpath, hosts, file_mask)
        logging.info('Backup successfully completed')

        # Archiving files
        logging.info('Archiving backup')
        archive_files(backup_dir_finpath)
        logging.info('Archive successfully created')

        # Deletion old backups
        logging.info('Deletion of old backup folders')
        backup_max_age = backup_entry['max_age']
        env_backup_dir = os.path.abspath(os.path.dirname(backup_dir_finpath))
        deletion_old_backups(env_backup_dir, int(backup_max_age), now_timestamp)
        logging.info('All old folders have been deleted')

        # Backup completed.
        logging.info('Backup of ' + str(backup_entry_key) + ' completed.')
        logging.info('Elapsed time: ' + str((datetime.datetime.now()-log_timestamp).seconds) + ' sec.\n==============')
        log_timestamp = datetime.datetime.now()
    logging.info('Full backup time: ' + str((datetime.datetime.now()-now_timestamp).seconds) + ' sec.')
