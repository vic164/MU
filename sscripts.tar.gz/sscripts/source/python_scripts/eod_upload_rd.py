#! /usr/bin/env python

import os
import re
import sys
import time
import shutil
import common
import logging
import tarfile
import subprocess
from datetime import datetime


def upload_set(set_path):
    common.info_output("UPLOAD SET" + set_path)
    set_dirname = os.path.basename(set_path)
    if set_dirname == 'auth':
        flag_set = ['FLAG_AUTH_UPLOAD_DATA', 'FLAG_AUTH_DOWNLOAD_DATA']
        host = common.get_host_for_process('Common:1:1:AuthServer:1')
        rmt_upload_dir = os.path.join(os.environ['HOME'], 'data', 'AuthServer')
        flag_for_start_upload = 'FLAG_AUTH_UPLOAD_DATA'
        flag_for_start_upload_status = '02'
        flag_for_check_end_upload = 'FLAG_AUTH_UPLOAD_DATA'
    else:
        flag_set = ['FLAG_EM_REFERENCE_DATA_READY',
                    'FLAG_EM_UPLOAD_REFERENCE_DATA',
                    'FLAG_EM_DOWNLOAD_REFERENCE_DATA']
        host = common.get_host_for_process('Common:1:1:ExchangeManager:1')
        rmt_upload_dir = os.path.join(os.environ['HOME'], 'data', 'ExchangeRefData', 'upload')
        flag_for_start_upload = 'FLAG_EM_REFERENCE_DATA_READY'
        flag_for_start_upload_status = '03'
        flag_for_check_end_upload = 'FLAG_EM_UPLOAD_REFERENCE_DATA'
    # Check flags
    for flag in flag_set:
        common.debug_output('check_system_ready_for_upload: check ' + str(flag))
        flag_status = common.get_flag_status(flag)
        if flag_status == '04':
            common.error_output('flag ' + flag + ' in ERROR state. Please check')
        elif flag_status == '02':
            common.track_flag_status(flag, '03')
        if flag_status == '03':
            common.execute_ssi_cmd_for_flag(flag, '01')
    cmd = "ssh {h} rm -f {d}/*.xml*".format(h=host, d=rmt_upload_dir)
    common.run_shell_cmd_with_wait(cmd)
    # Copy files
    rd_xmls = set_path + '/*'
    cmd = "scp {l} {h}:{d}".format(h=host, d=rmt_upload_dir, l=rd_xmls)
    common.run_shell_cmd_with_wait(cmd)
    # Upload
    common.execute_ssi_cmd_for_flag(flag_for_start_upload, flag_for_start_upload_status)
    common.track_flag_status(flag_for_check_end_upload, '03')
    time.sleep(1)
    # Saving err files
    err_set_dir = os.path.join(set_path, 'errors')
    os.makedirs(err_set_dir, exist_ok=True)
    err_files = rmt_upload_dir + '/*.err*'
    cmd = "scp {h}:{d} {l}".format(h=host, d=err_files, l=err_set_dir)
    common.run_shell_cmd_with_wait(cmd)
    cmd = "ssh {h} \"rm -f {d}/*.xml*\"".format(h=host, d=rmt_upload_dir)
    common.run_shell_cmd_with_wait(cmd)
    time.sleep(4)


if __name__ == '__main__':
    script_directory = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.basename(os.path.realpath(__file__))
    logs_directory = os.path.join(os.path.dirname(script_directory), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)

    # cfg var: EOD_RD_UPLOAD="Y"
    global_cfg = common.parse_global_cfg()
    eod_rd_upload = global_cfg['SStop_steps']['eod_rd_upload']
    if not eod_rd_upload == "Y":
        common.info_output('EOD RD upload disabled. Exit', logfilename)
        exit()
    if 'prod_rd_svn_link' in global_cfg['SStop_steps'].keys():
        prod_rd_svn_link = global_cfg['SStop_steps']['prod_rd_svn_link']
    else:
        prod_rd_svn_link = ''
    prod_rd_dirname = os.path.basename(prod_rd_svn_link) if prod_rd_svn_link else ''
    start_time = time.time()
    eod_rd_dir = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'RefData', 'ssEodUpload')
    common.info_output('eod_rd_upload: ' + str(eod_rd_upload), logfilename)
    common.info_output('Clear already uploaded refdata')
    for dirs in os.listdir(eod_rd_dir):
        if re.search('_ALREADY_UPLOADED', dirs):
            fpath = os.path.join(eod_rd_dir, dirs)
            shutil.rmtree(fpath)
            common.info_output(str(fpath) + ' has been deleted')
    common.info_output('Start EOD Upload...', logfilename)
    for named_dir in os.listdir(eod_rd_dir):
        common.info_output('Folder with RD for upload: ' + str(named_dir), logfilename)
        refdata_dirpath = os.path.join(eod_rd_dir, named_dir)
        if named_dir == prod_rd_dirname:
            shutil.rmtree(refdata_dirpath)
            continue
        if os.path.isdir(os.path.join(refdata_dirpath, 'set2')):
            set2_xmls = os.path.join(refdata_dirpath, 'set2')
            upload_set(set2_xmls)
        if os.path.isdir(os.path.join(refdata_dirpath, 'set0')):
            set0_xmls = os.path.join(refdata_dirpath, 'set0')
            upload_set(set0_xmls)
        if os.path.isdir(os.path.join(refdata_dirpath, 'set1')):
            set1_xmls = os.path.join(refdata_dirpath, 'set1')
            upload_set(set1_xmls)
        if os.path.isdir(refdata_dirpath):
            upload_set(refdata_dirpath)
            os.rename(refdata_dirpath, os.path.join(eod_rd_dir, named_dir + '_ALREADY_UPLOADED'))
        else:
            common.error_output(str(refdata_dirpath) + ' not a directory. Please, check')
    if prod_rd_svn_link:
        os.chdir(eod_rd_dir)
        cmd = "svn co --trust-server-cert --non-interactive --username QABuild-s --password \"GC:C7)Lve~\" {s}".format(s=prod_rd_svn_link)
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
        out, err = p.communicate()
        print(out)
        print(err)
        prod_set = os.path.join(eod_rd_dir, prod_rd_dirname)
        if not os.path.isdir(prod_set):
            common.info_output('SVN prod xmls not found: ' + str(prod_rd_svn_link), logfilename)
        input()
        upload_set(prod_set)
    common.info_output("--- %s seconds ---" % (time.time() - start_time), logfilename)
