#!/bin/bash

source ~/.bashrc
source ~/.anaconda3
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
cfg_dir="$bin_dir/../cfg/"
logs_dir="$bin_dir/../logs/"
py_common_dir=$bin_dir/../py_common/
py_common_script="$py_common_dir/common.py"
source "$bin_dir/common.sh"

# Common step.
search_path="~/logs/"
ssm_masks="SSM_INST_RES
SSM_STAT
SSM_TWE"
sg_db_string=$($py_common_script db_string SG)
system_hosts=$(get_host_list $sg_db_string)

logfile="$logs_dir/${script_name}.log"
echo '' >$logfile

function reformat_date_namepart ()
    {
    namepart="$1"
    date_namepart=$(echo $namepart | cut -d '.' -f 1)
    time_namepart=$(echo $namepart | cut -d '.' -f 2)
    year_val=$(echo $date_namepart | cut -d '_' -f 3)
    mon_val=$(echo $date_namepart | cut -d '_' -f 1)
    day_val=$(echo $date_namepart | cut -d '_' -f 2)
    h_val=$(echo $time_namepart | cut -d '_' -f 1)
    m_val=$(echo $time_namepart | cut -d '_' -f 2)
    s_val=$(echo $time_namepart | cut -d '_' -f 3)
    for i in $(echo "01 02 03 04 05 06 07 08 09 10 11 12")
    do 
        m=$(date -d "2018${i}01" "+%b")
        if [[ "$mon_val" == "$m" ]]
        then
            mon_val=$i
            break
        fi
    done
    result="${year_val}${mon_val}${day_val}${h_val}${m_val}${s_val}"
    echo $result
    return $result
}


# Main
while true
do
    echo $(date "+%Y%m%d-%H%M%S")>> $logfile
    for host in $system_hosts
    do
        echo "Search files on ${host}" >> $logfile
        for ssm_name_part in $(echo "$ssm_masks")
        do
            echo "Search files with ${ssm_name_part}" >> $logfile
            found_files=$(ssh $host "find ${search_path} -type f -name \"${ssm_name_part}*\"")
            latest_datevalue="20101010101010"
            for f in $found_files
            do
                if [[ "$(echo $f | grep tar)" ]]
                then
                    continue
                fi
                echo "File ${f}" >> $logfile
                date_namepart=$(echo $f |  sed 's/.*log\.//g')
                value_for_comparing=$(reformat_date_namepart $date_namepart)
                if [ $value_for_comparing -gt $latest_datevalue ]
                then
                    elder_file=$(ssh $host "find ${search_path} -type f -name \"${ssm_name_part}.log.${value_for_comparing}\"")
                    if [[ "${elder_file}" ]]
                    then
                        echo "Latest file. Archiving and Deletion previous latest file: $elder_file" >> $logfile
                        cmd="cd ~/logs/ && tar -czvf ${elder_file}.tar.gz $(basename ${elder_file})"
                        ssh ${host} "${cmd}"
                        cmd="cd ~/logs/ && rm -f $(basename ${elder_file})"
                        ssh ${host} "${cmd}"
                    fi
                    latest_datevalue=$value_for_comparing
                else
                    echo "Not latest file. Archiving and Deletion file ${f}" >> $logfile
                    cmd="cd ~/logs/ && tar -czvf ${f}.tar.gz $(basename ${f})"
                    ssh ${host} "${cmd}"
                    cmd="cd ~/logs/ && rm -f $(basename ${f})"
                    ssh ${host} "${cmd}"
                    
                fi
            done
        done
    done
    echo "Sleep 5 min" >> $logfile
    sleep 300
done



