#!/bin/bash

source ~/.bashrc
source ~/.anaconda3
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
cfg_dir="$bin_dir/../cfg/"
py_common_dir="$bin_dir/../py_common/"
py_common_script="$py_common_dir/common.py"
logs_dir="$bin_dir/../logs/"
logfile="$logs_dir/$script_name.log"
echo "" >$logfile
tool_dir="$bin_dir/../tools/"
temp_dir="$bin_dir/../temp/"
source "$bin_dir/common.sh"
source "$cfg_dir/global.cfg"
cd $bin_dir

# Common step.
sg_db_string=$($py_common_script db_string SG)
logging 'INFO' $logfile "SStart" "COMMON STEP. Connection string for SG scheme has been found: $sg_db_string"
ats_db_string=$($py_common_script db_string ATS)
logging 'INFO' $logfile "SStart" "COMMON STEP. Connection string for ATS scheme has been found: $ats_db_string"
system_hosts=$(get_host_list $sg_db_string)
logging 'INFO' $logfile "SStart" "COMMON STEP. System hosts: $system_hosts"
if [[ "$1" == "--step" ]]
then
    step_number="$2"
    logging 'INFO' $logfile "SStart" "Start step = $step_number"
else
    logging 'INFO' $logfile "SStart" "Check, that system has been stopped before start"
    check_result=$(python $py_common_script admin_processes check "$system_hosts")
    echo "$check_result"
    if [[ "$check_result" == "ERROR" ]];
    then
        logging 'INFO' $logfile "SStart" "All SG processes have been successfully stopped"
        logging 'INFO' $logfile "SStart" "Proceed..."
    else
        logging 'ERROR' $logfile "SStart" "Please, stop the system before starting"
        exit 1
    fi

fi
    if [[ "$TIMER_FLAG" ]];
    then
        default_timer=$TIMER_FLAG
    else
        default_timer=600
    fi

if ! [[ "$step_number" ]]
then
    logging 'INFO' $logfile "SStart" "CLEANING SYSTEM BEFORE START"
    $CLEAN_SYSTEM_CMD
fi

# Step 1. Start SG processes
if [[ "$step_number" ]] && [ $step_number -gt 1 ];
then
    logging 'INFO' $logfile "SStart" "Step 1 (Start SG processes) has been skipped"
else
    logging 'INFO' $logfile "SStart" "STEP 1. Start SG processes... "
    if ! [[ "$START_SYSTEM_CMD" ]];
    then
        START_SYSTEM_CMD="mitops start"
    fi
    logging 'INFO' $logfile "SStart" "Command: $START_SYSTEM_CMD"
    $START_SYSTEM_CMD | tee -a $logfile
    wait
fi


# Check SG processes
logging 'INFO' $logfile "SStart" "Check, that SG processes have been started"

check_result=$(python $py_common_script admin_processes check "$system_hosts")
if [[ "$check_result" == "ERROR" ]];
then
    logging 'ERROR' $logfile "SStart" "Not all SG processes have been started. Details in the $logs_dir/admin_processes_check.log"
    logging 'INFO' $logfile "SStart" "Please, check that all SG processes are correctly started and start script again with argument --step"
    exit 1
else
    logging 'INFO' $logfile "SStart" "All SG processes have been successfully started"
fi

logging 'DEBUG' $logfile "SStart" "step 1 completed"
#read

sequence_name="SStart_RD_upload_only"
ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
eval $ssi_cmd
check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"

sleep 60
exit 0
