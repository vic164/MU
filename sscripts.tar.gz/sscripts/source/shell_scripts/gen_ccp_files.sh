#!/bin/bash

source ~/LSEG_env
script_name="$(basename $(readlink -f $0))"
script_folder="$(dirname $(readlink -f $0))"
log_folder="${script_folder}/../logs/"
logfilepath="${log_folder}/${script_name}.log"


scripts_path="${SYSTEM_HOME}/utilities/tcr_ccp_scripts/"
run_script1_name="ExportTCR2CSV"
run_script2_name="RefineUploadTCR_CCPs"
script2_arg="TEST"

old_ccp_files=$(find ${scripts_path} -type f -name '*TEST*.log')
for i in $(echo "$old_ccp_files")
do
    rm -f $i
done
cd ${scripts_path} 
./${run_script1_name} ./
wait
./${run_script2_name} ./ ${script2_arg}
wait
result_files=$(find ./ -type f -name "*${script2_arg}.log")
if [[ "${result_files}" ]]
then
    echo "CCP files successfully generated"
    cd -
    exit 0
else
    echo "Something not right with generating CCP files. Please check"
    cd -
    exit 1
fi
