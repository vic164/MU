#!/usr/bin/env bash
source ~/.bashrc
source ~/.anaconda3

function logging ()
    {
    level=$1
    log_file=$2
    func=$3
    text=$4
    date_point=$(date "+%Y-%m-%d %H:%M:%S,%d")
    echo "$level    [$date_point]  $func:  $text" | tee -a $log_file
    }


function get_host_list ()
    {
    sg_db_string=$1
    machines_txt_file="${HOME}/machines.txt"
    hosts=$(cat $machines_txt_file)
    if ! [[ "$hosts" ]]
    then
        hosts=$(sqlplus -s "$sg_db_string" <<EOQUERY
set heading off;
SELECT HOST FROM SG4_HOSTS;
QUIT;
EOQUERY
)
    fi
    echo $hosts
    }


function get_flag_status ()
    # Function for getting flag_status from SG DB
    # Arguments:
    # $1 = database connection string for SG scheme
    # $2 = FLAG_NAME
    {
    sg_db_string=$1
    FLAG_NAME=$2
    FLAG_VALUE=$(sqlplus -s "$sg_db_string" <<EOQUERY
set heading off; 
SELECT FLAG_VALUE FROM SG4_FLAG_VALUES WHERE FLAG_NAME ='${FLAG_NAME}'; 
QUIT; 
EOQUERY
)
    echo $FLAG_VALUE | cut -c 1,2
    }


function get_list_of_all_flags ()
    # function for getting all flags that is in SG scheme
    # Arguments:
    # $1 = database connection string for SG scheme
    {
    local sg_db_string=$1
    local sql_answer=$(sqlplus -s "$sg_db_string" <<EOQUERY
set heading off;
SELECT FLAG_ID FROM SG4_FLAGS;
QUIT;
EOQUERY
)
    flag_list=$(echo $sql_answer | cut -d ' ' -f 1)
    while read flag_name;
    do
        if [[ "$flag_name" != "" ]] && [[ "$flag_name" != "$(echo $sql_answer | cut -d ' ' -f 1)" ]];
        then
            if [[ "$(echo $flag_name | grep "rows\ selected")" ]];
            then
                break
            else
                flag_list="$flag_list,$flag_name"
            fi
        fi
    done< <(echo "$sql_answer")
    echo "$flag_list"
    }


function get_flag_status_description ()
    # function for get description of flag value in database (for log)
    # Arguments: 
    # $1 = flag_value. Possible values: '01', '02', '03', '04'
    {
    value=$1
    if [[ "$value" == "01" ]]; then echo "NOT_STARTED"
    elif [[ "$value" == "02" ]]; then echo "STARTED"
    elif [[ "$value" == "03" ]]; then echo "DONE"
    elif [[ "$value" == "04" ]]; then echo "ERROR"
    fi
    }


function check_exit_code ()
    # function for check, that step has been successfully completed. 
    # If exit-code = 0 -> Success 
    # Arguments:
    # $1 = exit code
    # $2 = action - description of step, that must be checked (for log)
    # $3 - logfile path
    {
    local exit_code="$1"
    local action="$2"
    local logfile="$3"
    if [[ "$exit_code" != "0" ]]
    then
        logging 'ERROR' $logfile 'check_exit_code' "$action has been performed with error. Exit"
        exit 1
    else
        logging 'INFO' $logfile 'check_exit_code' "Success"
    fi
    }


function get_host_for_process ()
    # function for getting host, where process is.
    # Arguments:
    # $1 = database connection string for SG scheme
    # $2 = process name
    {
    sg_db_string="$1"
    process_name="$2"
    process_name_search="'$process_name'"
    process_inst_id="'1'"
    machine=$(sqlplus -s $sg_db_string <<EOQUERY
set heading off;
set feedback off;
SELECT MACHINE FROM SG4_INSTANCES WHERE PROC_DEF = $process_name_search and PROC_INST_ID = $process_inst_id;
QUIT;
EOQUERY
)
    machine="'$( echo $machine | sed "s/^[ \t]*//g" | sed "s/[ \t]*$//g")'"
    process_host=$(sqlplus -s $sg_db_string <<EOQUERY2
set heading off;
set feedback off;
SELECT HOST FROM SG4_MACHINES WHERE NAME = $machine;
QUIT;
EOQUERY2
)
    echo $process_host
    }


function track_flag_status ()
    {
    sg_db_string="$1"
    flag_name="$2"
    flag_state="$3"
    timer="$4"
    echo $sg_db_string
    echo $flag_name
    echo $flag_state
    echo $timer
    while [ $timer -gt 0 ];
    do
        sleep 1
        current_flag_status=$(get_flag_status $sg_db_string $flag_name)
        if [[ "$current_flag_status" == "$flag_state" ]]
        then
            echo "Success"
            return 0
        elif [[ "$current_flag_status" == "04" ]]
        then
            echo "Flag $flag_name in ERROR state"
            return 1
        else
            let "timer=$timer-1"
        fi
    done
    echo "ERROR"
    return 1
    }


function svn_update_times_configs ()
    {
    venue="$1"
    cfg_dir="$(dirname $(readlink -f $0))/../cfg/"
    directory_with_configs="$cfg_dir/TradingCyclesSettings"
    svn_url="https://subversion.lseg.stockex.local/svn/qateam/Trading_Systems/${venue}/TradingCyclesSettings"
    if [ -d $directory_with_configs ]
    then
        rm -rf $directory_with_configs
    fi
    cd $cfg_dir
    cmd="svn co $svn_url --trust-server-cert --non-interactive --username QABuild-s --password \"GC:C7)Lve~\" $directory_with_configs"
    eval $cmd
    sleep 3
    cd -
    }

#get_host_for_process LSEQA01SG/LSEQA01SG@mitoracle PriceUploader
