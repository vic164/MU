#!/bin/bash

source ~/.bashrc
source ~/.anaconda3

# GENERAL PATHS
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
# LOGGING
source "$bin_dir/common.sh"
logs_dir="$bin_dir/../logs/"
logfile="$logs_dir/$script_name.log"
echo '' > $logfile
# GET TIMES FROM EST PROCEDURE TEXT
est_proc_file="${HOME}/QA_env_scripts/env_maintenance_scripts/temp/EST_PROCEDURE.txt"
day_end_time=$(cat $est_proc_file | grep OP_DAY_END_TIME | grep -oEe '[0-9]{2}\:[0-9]{2}\:[0-9]{2}')
day_end_time_hm=$(date --date "$day_end_time" "+%H:%M")
datetime_dayend=$(date --date "$day_end_time" "+%H:%M:%S")
recon_time=$(date -d "${day_end_time} today + 7min" "+%H:%M")
scheduler_time_h=$(date --date "+1hour" "+%H")
scheduler_time_m=$(echo $day_end_time_hm | cut -d ':' -f 2)
scheduler_time="${scheduler_time_h}:${scheduler_time_m}"
echo $scheduler_time

logging 'INFO' $logfile "UPDATE_RECON_TIMES" "DAY_END_TIME = ${day_end_time} and EOD_FILE_GEN_TIME = ${recon_time}"
# COMMIT TO THE DB
sg_db_conn_string=$1
logging 'INFO' $logfile "UPDATE_RECON_TIMES" "Connection string for SG schema has been found: $sg_db_conn_string"
forsql="UPDATE SG4_CONFIGS SET VALUE = '${day_end_time_hm}' WHERE PARAMETER = 'LAST_RECONCILIATION_FILE_GENERATION_TIME_FOR_NORMAL_TRADING_DAY';
UPDATE SG4_CONFIGS SET VALUE = '${day_end_time_hm}' WHERE PARAMETER = 'LAST_RECONCILIATION_FILE_GENERATION_TIME_FOR_EARLY_CLOSE_DAY';
UPDATE SG4_CONFIGS SET VALUE = '${recon_time}' WHERE PARAMETER = 'EOD_RECONCILIATION_FILE_GENERATION_TIME_FOR_NORMAL_TRADING_DAY';
UPDATE SG4_CONFIGS SET VALUE = '${recon_time}' WHERE PARAMETER = 'EOD_RECONCILIATION_FILE_GENERATION_TIME_FOR_EARLY_CLOSE_DAY';
UPDATE SG4_CONFIGS SET VALUE = '${scheduler_time}' WHERE PARAMETER = 'RECONCILIATION_FILE_SCHEDULE_START_TIME';"

logging 'INFO' $logfile "UPDATE_RECON_TIMES" "Queries: 
${forsql}"

sqlplus ${sg_db_conn_string}<<EOQ
SPOOL $logfile;
${forsql}
commit;
SPOOL OFF;
QUIT;
EOQ

logging 'INFO' $logfile "UPDATE_RECON_TIMES" "Update completed"
