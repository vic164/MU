#!/usr/bin/env bash

source ~/.bashrc
source ~/.anaconda3
env_name=$(whoami)
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
cfg_dir="$bin_dir/../cfg/"
py_common_dir="$bin_dir/../py_common/"
py_common_script="$py_common_dir/common.py"
logs_dir="$bin_dir/../logs/"
logfile="$logs_dir/$script_name.log"
echo "" >$logfile
tool_dir="$bin_dir/../tools/"
temp_dir="$bin_dir/../temp/"
source "$bin_dir/common.sh"
source "$cfg_dir/global.cfg"
cd $bin_dir

# Common step.
sg_db_string=$($py_common_script db_string SG)
logging 'INFO' $logfile "SStop" "COMMON STEP. Connection string for SG scheme has been found: $sg_db_string"
ats_db_string=$($py_common_script db_string ATS)
logging 'INFO' $logfile "SStop" "COMMON STEP. Connection string for ATS scheme has been found: $ats_db_string"
system_hosts=$(get_host_list $sg_db_string)
logging 'INFO' $logfile "SStop" "COMMON STEP. System hosts: $system_hosts"
if [[ "$1" == "--step" ]]
then
    step_number="$2"
    logging 'INFO' $logfile "SStop" "Start step = $step_number"
fi
if [[ "$TIMER_FLAG" ]];
then
    timer=$TIMER_FLAG
else
    timer=600
fi

# Step 0. Check that the system started.
logging 'INFO' $logfile "SStop" "Step 0. Check that the system started."
check_result=$(python $py_common_script admin_processes check_down "$system_hosts")
if [[ "$check_result" == "Success" ]];
then
    logging 'ERROR' $logfile "SStop" "All SG processes have been stopped"
    exit 666
fi
check_result=$(python $py_common_script admin_processes check "$system_hosts")
if [[ "$check_result" == "ERROR" ]];
then
    logging 'WARNING' $logfile "SStop" "Not all SG processes are started now. Please, check"
fi
# Step 1. Checking and performing end of day
logging 'INFO' $logfile "SStop" "STEP 1. Check, that trading day was ended." 
flag_status=$(get_flag_status $sg_db_string 'FLAG_END_OF_DAY')
if [[ "$flag_status" == "03" ]];
then
    logging 'INFO' $logfile "SStop" "STEP 1. End of day has been performed"
else
    logging 'INFO' $logfile "SStop" "STEP 1. The system $env_name is up and running now. Markets are opened. "
    logging 'INFO' $logfile "SStop" "STEP 1. Are you sure? "
    read -p 'Are you sure? [y/n]' answer
    if [[ "$answer" == "n" ]]
    then
        exit 0
    fi 
    fsb_host=$(get_host_for_process $sg_db_string 'FSB')
    logging 'INFO' $logfile "SStop" "STEP 1. End of day has not been performed. Close markets and trading day..."
    script_name="fsb_action.py"
    echo "python $py_common_dir/$script_name $fsb_host close_markets"
    python $py_common_dir/$script_name $fsb_host close_markets
    wait
    sleep 10
    logging 'INFO' $logfile "SStop" "STEP 1. All markets must be closed now"
    logging 'INFO' $logfile "SStop" "STEP 1. Performing end of day... "
    python $py_common_dir/$script_name $fsb_host close_day
    wait
    if [[ $(whoami) == 'tnpqa03' ]]
    then
        # Hard set FLAG_PS_EOD 4 to Done state
        ssi_cmd=`python $py_common_script SSI FLAG_PS_EOD 3 Pricing 4 1`
        echo $ssi_cmd
        eval $ssi_cmd
        `SSI 1  FLAG_PS_EOD  3  4  1`
    fi
    # waiting for moving flag FLAG_END_OF_DAY to Done state
    timer_eod=$timer
    track_flag_status $sg_db_string 'FLAG_END_OF_DAY' '03' $timer_eod
    if [ "$?" != 0 ]
    then
        logging 'ERROR' $logfile "SStop" "STEP 1. FLAG_END_OF_DAY not moved to DONE state"
        exit 1
    fi
    logging 'INFO' $logfile "SStop" "STEP 1. End of day successfully performed"
fi

# Shutdown ExecutorDemon
logging 'INFO' $logfile "SStop" "Shutdown executor demon"
eval ${HOME}/QA_env_scripts/ExecutorDemon/shutdown_executor_demon.sh

# Restart mit_exporter
logging 'INFO' $logfile "SStop" "Restart mit exporter"
mit_exporter_home="${HOME}/services/mit_exporter"
mit_exp_run_script="./run.sh"
cd  $mit_exporter_home && $mit_exp_run_script && cd -


# EOD Upload RefData
if [[ "$EOD_RD_UPLOAD" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "EOD Upload RefData"
    script_name="$py_common_dir/eod_upload_rd.py"
    cmd="python $script_name"
    eval $cmd
fi

# Sync of RD with GTP
if [[ "${SYNC_RD_WITH_GTP}" == "Y" ]]
then
    timer_eod=$timer
    gtprd_filepath="~/data/ExchangeRefData/download/${RDFILE_PREFIX}_*.csv"
    exman_host=$($py_common_script get_host_for_process 'Common:1:1:ExchangeManager:1')
    logging 'INFO' $logfile "SStop" "Step Sync RD with GTP: Clean up download directory"
    rm_cmd="rm -f $gtprd_filepath"
    ssh ${exman_host} "${rm_cmd}"
    rm -f ~/QA_env_scripts/env_maintenance_scripts/temp/refdex/${FINAL_FILENAME}
    logging 'INFO' $logfile "SStop" "Step Sync RD with GTP: Move FLAG_EM_CREATE_GTP_REFDATA_FILE to Started state"
    ssi_cmd=$($py_common_script SSI Flag FLAG_EM_CREATE_GTP_REFDATA_FILE 2 Common 1 1)
    eval $ssi_cmd
    logging 'INFO' $logfile "SStop" "Step Sync RD with GTP:  Waiting for moving FLAG_EM_CREATE_GTP_REFDATA_FILE to Done state"
    track_flag_status $sg_db_string 'FLAG_EM_CREATE_GTP_REFDATA_FILE' '03' $timer_eod
    if [ "$?" != 0 ]
    then
        logging 'ERROR' $logfile "SStop" "STEP Sync RD with GTP:. FLAG_EM_CREATE_GTP_REFDATA_FILE not moved to DONE state"
        exit 1
    fi
    logging 'INFO' $logfile "SStop" "Step Sync RD with GTP:  Sending generated file to the UpdateServer"
    scp ${exman_host}:${gtprd_filepath} ~/QA_env_scripts/env_maintenance_scripts/temp/refdex/${FINAL_FILENAME}
    logging 'INFO' $logfile "SStop" "Step Sync RD with GTP: Run GTP_RefData_Sync jenkins job"
    curl_params="token=mySecretToken&cause=FromSStop&ExEnv=${env_name}"
    curl "${JENKINS_URL}/job/envs/job/GTP_RefData_Sync/buildWithParameters?${curl_params}"
fi

# FSB_LIFE_SUPPORTER
# FSB_LS_pid=$(ps xf | grep FSB_life_supporter.sh | grep -v grep | cut -d ' ' -f 2)
# kill $FSB_LS_pid
pkill -9 -f FSB_life_supporter.sh 
# Stop SSM_ARCHIVATOR
if [[ "$SSM_ARCHIVATOR" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "Killing SSM Archivator"
    pkill -9 -f SSM_arch.sh
fi

# Check all flags configuration
logging 'INFO' $logfile "SStop" "Check EOD flag configuration..."
script_name="$py_common_dir/check_flags_configuration.py"
cmd="python $script_name EOD"
eval $cmd
check_exit_code "$?" "Check EOD flags configuration" "$logfile"

# ML stop and backup
if [[ "$ML" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "ML stop and collecting ML files..."
    ML_dir="$tool_dir/MITCH_Listener"
    #script_name="start_merge_all.sh" # merge ML files
    #$ML_dir/$script_name
    #wait
    script_name="$ML_dir/stop_all_ml.sh"
    cmd="$script_name"
    eval $cmd
    wait
fi
# Stop PCAP and deletion old
if [[ "$PCAP" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "Stop pcaps"
    PCAP_dir="$tool_dir/pcap"
    script_name="$PCAP_dir/stop_all_pcap.py"
    cmd="python $script_name $datetime_label"
    logging 'INFO' $logfile "SStop" "cmd for stop pcap: ${cmd}"
    eval $cmd
    wait
fi

# GEN_CCP_REVERSAL
if [[ "${GEN_CCP_REVERSAL}" == "Y" ]]
then
    rm -f ${HOME}/data/RFG/*/*_REVERSAL.csv
    ssi_cmd=$($py_common_script SSI Flag FLAG_RFG_NEXTDAY_FILE_TRIGGER 2 Common 1 1)
    eval $ssi_cmd
    track_flag_status $sg_db_string 'FLAG_RFG_NEXTDAY_FILE_GENERATION' '03' $timer_eod
fi


# Backups
logging 'INFO' $logfile "SStop" "Backups collecting..."
script_name="$py_common_dir/do_backups.py"
cmd="python $script_name"
eval $cmd
wait

# Stop UDPProxy - ITCH && FAST
FAST_dir="$tool_dir/UDPProxy_FAST"
script_name="stop_all_fast.sh"
$FAST_dir/$script_name
wait
ITCH_dir="$tool_dir/UDPProxy_ITCH"
script_name="stop_all_itch.sh"
$ITCH_dir/$script_name
wait

# Clean stuff
if [[ "$ML" == "Y" ]]
then
    script_name="$ML_dir/clean_mls.sh"
    cmd="$script_name"
    eval $cmd
    wait
fi

# Step 2. Stop all application process
logging 'INFO' $logfile "SStop" "STEP 2. Stop all application process"
sequence_name=$STOP_APPLICATION_PROCESSES_SEQUENCE_NAME
ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
eval $ssi_cmd
check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"

sleep 30
# How to check that sequence completed?
script_name="check_application_processes.sh"
# this script will get list of all application processes and check, that all of them stopped"


# Step 3. Generate SOD files for next day
if [[ "$GENERATING_SOD_FILES" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "STEP 3. Generate SOD files for next day"
    sequence_name=$GENERATE_SOD_FILES_SEQUENCE_NAME
    ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
    eval $ssi_cmd
    check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"
    # waiting for FLAG_SODF_READY moved to Done state
    timer_sodf=$timer
    track_flag_status $sg_db_string 'FLAG_SODF_READY' '03' $timer_sodf
    if [ "$?" != 0 ]
    then
        logging 'ERROR' $logfile "SStop" "STEP 3. FLAG_SODF_READY not moved to DONE state"
        exit 1
    fi
else
    logging 'INFO' $logfile "SStop" "STEP 3. Generating SOD files disabled in global config file. Skipped"
fi


# Step 4. SOD preparation: Application checkpoint performing
logging 'INFO' $logfile "SStop" "STEP 4. SOD preparation: Application checkpoint performing"
sequence_name=$APP_CHKPT_EOD_SEQUENCE_NAME
ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
eval $ssi_cmd
check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"

#logging 'INFO' $logfile "SStop" "STEP 4. Waiting for FLAG_PTTPS_SOD moved to DONE state"
#timer_pttps=$timer
#track_flag_status $sg_db_string 'FLAG_PTTPS_SOD' '03' $timer_pttps
#if [ "$?" != 0 ]
#then
#    logging 'ERROR' $logfile "SStop" "STEP 4. FLAG_PTTPS_SOD not moved to DONE state"
#    exit 1
#fi
logging 'INFO' $logfile "SStop" "STEP 4. Waiting for FLAG_SPN moved to DONE state"
timer_spn=$timer
track_flag_status $sg_db_string 'FLAG_SPN' '03' $timer_spn
if [ "$?" != 0 ]
then
    logging 'ERROR' $logfile "SStop" "STEP 4. FLAG_SPN not moved to DONE state"
    exit 1
fi

if [[ "$FILEBEAT" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "Killing FILEBEAT"
    pkill -9 -f filebeat
fi

# Step 5. Stop all application process
logging 'INFO' $logfile "SStop" "STEP 5. Stop all application process"
sequence_name=$STOP_APPLICATION_PROCESSES_SEQUENCE_NAME
ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
eval $ssi_cmd
check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"

sleep 30

#Stop GTP MLs
if [[ "$GTP_STEP" == "Y" ]]
then
    logging 'INFO' $logfile "SStop" "GTP_STEP"
    cmd="ssh ${GTP_MLs_REMOTE_CONNECTION} \"${GTP_MLs_STOP}\""
    eval $cmd
fi

# BSS Synchronization
if [[ "$BSS_SYNCHRONIZATION" ]] && [[ "$(echo $USER | grep 'tqex')" ]]
then
    logging 'INFO' $logfile "SStop" "BSS Synchronization step"
    if [[ "$USER" == "tqex2-s" ]]; then continue; fi
    cmd="cd ~/QA_env_scripts/env_maintenance_scripts/tools/bss/ && tar -czvf data_bkp.tar.gz data && cd -"
    eval $cmd
    cmd="cp -r /app/x01/tqex2-s/QA_env_scripts/env_maintenance_scripts/tools/bss/data ~/QA_env_scripts/env_maintenance_scripts/tools/bss/"
    eval $cmd
fi

# Step 6. shutdown system
logging 'INFO' $logfile "SStop" "STEP 6. System ready for shutdown. Press enter if you want to proceed"

$SHUTDOWN_SYSTEM_CMD &
wait
