#!/bin/bash

source ~/.bashrc
source ~/.anaconda3
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
cfg_dir="$bin_dir/../cfg/"
logs_dir="$bin_dir/../logs/"
py_common_dir=$bin_dir/../py_common/
py_common_script="$py_common_dir/common.py"
source "$bin_dir/common.sh"
source "$cfg_dir/global.cfg"

# Constants
process_name="FSB"
process_full_name="Common:1:1:FSB:1"
process_binary_dir="~/current/bin/"
process_binary_file="FSB"
binary_start_cmd="./${process_binary_file} exchange 700 ${process_full_name}"
additional_script_dir="~/current/scripts/"
additional_script_start_cmd="./FSB_START.sh"

# General variables
if [[ "$2" ]];
then
    logfile=$2
else
    logfile="$logs_dir/${script_name}.log"
fi
echo '' >$logfile

if [[ "$1" ]];
then
    sg_db_string="$1"
else
    sg_db_string=$(python $py_common_script db_string SG)
    echo '[INFO][FSB_LIFE_SUPPORTER] Connection string for SG scheme has been found: $sg_db_string' >> $logfile
fi

if ! [[ "$sg_db_string" ]]
then
    echo "[ERROR][FSB_LIFE_SUPPORTER] db connection string not found. Please, specify this variable as attribute and try again" >> $logfile
    exit 1
fi

#Get host for FSB
host=$(get_host_for_process $sg_db_string $process_name)
echo "[INFO][FSB_LIFE_SUPPORTER] Host with FSB has been found: $host" >> $logfile

host_connect="$(whoami)@$host"

# Main
while true
do
    check_process=$(ssh ${host_connect} "ps xf | grep ${process_full_name} | grep -v 'grep'")
    if ! [[ "$check_process" ]]
    then
        echo "[INFO][FSB_LIFE_SUPPORTER] FSB is down. Start FSB process..." >>$logfile
        #ssh ${host_connect} "bash -c 'cd ${process_binary_dir} && ( ( ${binary_start_cmd} > /dev/null 2>&1 < /dev/null ) & )'"
        ssh ${host_connect} "SSI 20 ${process_full_name} 0"
        for i in $(seq 1 10);
        do
            check_process=$(ssh ${host_connect} "ps xf | grep ${process_full_name} | grep -v 'grep'")
            if [[ "$check_process" ]]; then continue; fi
            sleep 1
        done
        if ! [[ "$check_process" ]]
        then
            echo "[ERROR][FSB_LIFE_SUPPORTER] FSB is down and cannot be started. Please check" >> $logfile
            sleep 2
            continue
        fi
        sleep 10
        echo "[INFO][FSB_LIFE_SUPPORTER] Start FSB bridge... " >> $logfile
        cmd="bash -c 'cd ${additional_script_dir} && ( ( ${additional_script_start_cmd} > /dev/null 2>&1 < /dev/null ) & )'"
        eval $cmd
        sleep 1
        echo "[INFO][FSB_LIFE_SUPPORTER] FSB started again" >> $logfile
    else
        sleep 3
    fi
done
