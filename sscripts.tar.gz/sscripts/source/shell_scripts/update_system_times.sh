#!/usr/bin/env bash

source ~/.bashrc
source ~/.anaconda3
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
cfg_dir="$bin_dir/../cfg/"
py_common_dir="$bin_dir/../py_common/"
py_common_script="$py_common_dir/common.py"
generator_procedure="$py_common_dir/generate_sql_procedure.py"
logs_dir="$bin_dir/../logs/"
source "$bin_dir/common.sh"
if [[ "$2" ]]
then
    logfile=$2
else
    logfile="$logs_dir/$script_name.log"
fi
echo '' > $logfile

if [[ "$1" ]];
then
    ats_db_conn_string=$1
else
    ats_db_conn_string=$($py_common_script db_string ATS)
    logging 'INFO' $logfile "SStart" "COMMON STEP. Connection string for ATS schema has been found: $ats_db_conn_string"
fi
full_out_from_python=$(python $generator_procedure "$logfile")
EST_PROCEDURE_path=$(echo "$full_out_from_python" | tail -n 1)
forsql=$(cat $EST_PROCEDURE_path)

sqlplus ${ats_db_conn_string}<<EOQ
SPOOL $logfile;
BEGIN
${forsql}
END EXACTPRO_SESSION_TIMES;
.
run;
SPOOL OFF;
QUIT;
EOQ
