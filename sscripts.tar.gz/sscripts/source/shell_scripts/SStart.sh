#!/bin/bash

source ~/.bashrc
source ~/.anaconda3
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
cfg_dir="$bin_dir/../cfg/"
py_common_dir="$bin_dir/../py_common/"
py_common_script="$py_common_dir/common.py"
logs_dir="$bin_dir/../logs/"
logfile="$logs_dir/$script_name.log"
echo "" >$logfile
echo "" >$logs_dir/check_flags_configuration.py.log 
tool_dir="$bin_dir/../tools/"
temp_dir="$bin_dir/../temp/"
source "$bin_dir/common.sh"
source "$cfg_dir/global.cfg"
cd $bin_dir

# Common step.
sg_db_string=$($py_common_script db_string SG)
logging 'INFO' $logfile "SStart" "COMMON STEP. Connection string for SG scheme has been found: $sg_db_string"
ats_db_string=$($py_common_script db_string ATS)
logging 'INFO' $logfile "SStart" "COMMON STEP. Connection string for ATS scheme has been found: $ats_db_string"
system_hosts=$(get_host_list $sg_db_string)
logging 'INFO' $logfile "SStart" "COMMON STEP. System hosts: $system_hosts"
if [[ "$1" == "--step" ]]
then
    step_number="$2"
    logging 'INFO' $logfile "SStart" "Start step = $step_number"
else
    logging 'INFO' $logfile "SStart" "Check, that system has been stopped before start"
    check_result=$(python $py_common_script admin_processes check_down "$system_hosts")
    echo "$check_result"
    if [[ "$check_result" == "ERROR" ]];
    then
        logging 'ERROR' $logfile "SStart" "Please, stop the system before starting"
        exit 1
    else
        logging 'INFO' $logfile "SStart" "All SG processes have been successfully stopped"
        logging 'INFO' $logfile "SStart" "Proceed..."
    fi

fi
    if [[ "$TIMER_FLAG" ]];
    then
        default_timer=$TIMER_FLAG
    else
        default_timer=600
    fi

# Collecting AL files before starting
logging 'INFO' $logfile "SStart" "Collecting AL files before start"
mkdir -p ~/QA_env_scripts/backups/AL_temp
cd ~/QA_env_scripts/backups/
for x in $(cat ~/machines.txt)
do
    mkdir AL_temp/$x
    scp $x:~/data/AsyncLogger/* ./AL_temp/$x
done
tar -czvf AL_everyday_backup.tar.gz ./AL_temp
wait
rm -rf ~/QA_env_scripts/backups/AL_temp
cd -

if ! [[ "$step_number" ]]
then
    logging 'INFO' $logfile "SStart" "CLEANING SYSTEM BEFORE START"
    $CLEAN_SYSTEM_CMD
fi

# Get new configs for EST
if [[ "$UPDATE_CONFIGS_WITH_SVN" == "N" ]]
then
    logging 'INFO' $logfile "SStart" "COMMON STEP. Getting new configs for EST from svn disabled in the global config"
else
    logging 'INFO' $logfile "SStart" "COMMON STEP. Get new configs for EST"
    directory_with_configs="$cfg_dir/TradingCyclesSettings"
    svn_update_times_configs "${VENUE}"
    if ! [ -d $directory_with_configs ]
    then
        logging 'ERROR' $logfile "SStart" "No EST configs. Please check "
        logging 'ERROR' $logfile "SStart" "svn co https://subversion.lseg.stockex.local/svn/qateam/Trading_Systems/$VENUE/TradingCyclesSettings cmd"
    fi
    timer=$TIMER_FLAG
    while [ $timer -gt 0 ]
    do
        if [ -d $directory_with_configs ]
        then
            if [[ "$(ls $directory_with_configs)" ]]
            then
                logging 'INFO' $logfile "SStart" "EST configs have been successfully uploaded from SVN"
                break
            fi
        fi
        logging 'WARNING' $logfile "SStart" "COMMON STEP. Getting new configs from SVN has been done with error. Try again..."
        svn_update_times_configs "${VENUE}"
        sleep 10
        let "timer=$timer-10"
    done
    if ! [ -d $directory_with_configs ]
    then
        logging 'WARNING' $logfile "SStart" "COMMON STEP. Getting new configs from SVN has been done with error"
    fi
fi

# FILEBEAT
if [[ "$FILEBEAT" == "Y" ]]
then
    for host in $(echo "$system_hosts")
    do
        logging 'INFO' $logfile "SStart" "Start Filebeat on ${host}"
        ssh ${host} "cd $FILEBEAT_PATH && $FILEBEAT_STARTUP &"  >> /dev/null 2>&1 &
    done
fi

# RECOFILES GENERATION TIMES
if ! [[ "$step_number" ]];
then
     if [[ "$UPDATE_RECOTIMES" == "Y" ]]
    then
        logging 'INFO' $logfile "SStart" "STEP 6. Update times for RecoFilesGeneration"
        generator_procedure="$py_common_dir/generate_sql_procedure.py"
        full_out_from_python=$(python $generator_procedure)
        script_name="update_reconparams.sh"
        if [ -f $script_name ];
        then
            $bin_dir/$script_name $sg_db_string
        else
            logging 'ERROR' $logfile "SStart" "Script $script_name not found. Please check"
        fi
    fi
fi

# Step 1. Start SG processes
if [[ "$step_number" ]] && [ $step_number -gt 1 ];
then
    logging 'INFO' $logfile "SStart" "Step 1 (Start SG processes) has been skipped"
else
    logging 'INFO' $logfile "SStart" "STEP 1. Start SG processes... "
    if ! [[ "$START_SYSTEM_CMD" ]];
    then
        START_SYSTEM_CMD="mitops start"
    fi
    logging 'INFO' $logfile "SStart" "Command: $START_SYSTEM_CMD"
    $START_SYSTEM_CMD | tee -a $logfile
fi


# Check SG processes
logging 'INFO' $logfile "SStart" "Check, that SG processes have been started"

check_result=$(python $py_common_script admin_processes check "$system_hosts")
if [[ "$check_result" == "ERROR" ]];
then
    logging 'ERROR' $logfile "SStart" "Not all SG processes have been started. Details in the $logs_dir/admin_processes_check.log"
    logging 'INFO' $logfile "SStart" "Please, check that all SG processes are correctly started and start script again with argument --step"
    exit 1
else
    logging 'INFO' $logfile "SStart" "All SG processes have been successfully started"
fi
logging 'DEBUG' $logfile "SStart" "step 1 completed"


# Step 2. Update Global configurations
if [[ "$step_number" ]] && [ $step_number -gt 2 ];
then
    logging 'INFO' $logfile "SStart" "Step 2 (Update Global configurations) has been skipped"
else
    logging 'INFO' $logfile "SStart" "STEP 2. Update Global configurations... "
    script_name="update_global_config_vars.sh"
    $bin_dir/$script_name "$logfile"
    check_exit_code "$?" "Update_Global_Configurations" "$logfile"
fi

sleep 5
# Check NEXT_TRADING_DAY
script_name="update_global_config_vars.sh"
$bin_dir/$script_name "$logfile" --check $sg_db_string
check_exit_code "$?" "Update_Global_Configurations" "$logfile"

logging 'DEBUG' $logfile "SStart" "step 2 completed"
#################################


# Step 3. Check flags configurations
if [[ "$step_number" ]] && [ $step_number -gt 3 ];
then
    logging 'INFO' $logfile "SStart" "Step 3 (Check flags configurations) has been skipped"
else
    logging 'INFO' $logfile "SStart" "STEP 3. Check flags configurations"
    script_name="$py_common_dir/check_flags_configuration.py"
    cmd="python $script_name SOD"
    eval $cmd
    if [[ "$?" != "0" ]];
    then
        read -p 'There is invalid flag configuration. Would you like to clear AL files and TRD scheme? [y/n]' answer
        if ! [[ "$answer" == "n" ]]
        then
            cd $bin_dir
            ./RAF
            ./CTCR
            cd -
            sequence_name=$SET_SOD_FLAGS_CONFIGURATION_SEQUENCE_NAME
            ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
            eval $ssi_cmd
            check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"
            sleep 2
        fi
    else
        logging 'INFO' $logfile "SStart" "STEP 3. Cheking flag configuration successfully done"
    fi
fi

logging 'DEBUG' $logfile "SStart" "step 3 completed"


# Check flag configurations between steps
if ! [[ "$step_number" ]] || [ $step_number -lt 8 ];
then
    logging 'INFO' $logfile "SStart" "Check that system ready to start"
    script_name="$py_common_dir/check_flags_configuration.py"
    cmd="python $script_name SOD"
    eval $cmd
    check_exit_code "$?" "Check that system ready to start" "$logfile"

fi


# Step 4. Update process settings
if [[ "$step_number" ]] && [ $step_number -gt 4 ];
then
    logging 'INFO' $logfile "SStart" "Step 4 has been skipped"
else
    if [[ "$UPDATE_PROCESS_SETTINGS" == "Y" ]]
    then
        logging 'INFO' $logfile "SStart" "STEP 4. Update process settings"
        script_name="$py_common_dir/update_process_settings.py"
        config_name="$cfg_dir/$UPDATE_PROCESS_SETTINGS_CONFIG"
        if [ -f $config_name ];
        then
            cmd="python $script_name ${config_name}"
            eval $cmd
        else
            logging 'WARNING' $logfile "SStart" "Config for update process settings not found. Skipped"
        fi
    else
        logging 'INFO' $logfile "SStart" "STEP 4. Update process settings disabled in global.cfg"
    fi
fi

logging 'DEBUG' $logfile "SStart" "step 4 completed"


# Step 5. Update closing prices
if [[ "$PRICE_UPLOADER_STEP" == "Y" ]];
then
    if [[ "$step_number" ]] && [ $step_number -gt 5 ];
    then
        logging 'INFO' $logfile "SStart" "Step 5 has been skipped"
    else
        logging 'INFO' $logfile "SStart" "STEP 5. Update closing prices"
        script_name="$py_common_dir/update_closing_prices.py"
        if [ -f $script_name ];
        then
            cmd="python $script_name"
            eval $cmd
            if [[ "$?" != "0" ]]
            then
                logging 'ERROR' $logfile 'Update_closing_prices' "Update_closing_prices has been performed with error. Exit"
            else
               logging 'INFO' $logfile 'check_exit_code' "Success"
            fi
        else
            logging 'ERROR' $logfile "SStart" "Script $script_name not found. Please check and try again (step 6)"
            exit 1
        fi
    fi
else
    logging 'INFO' $logfile "SStart" "Updating closing prices out of scope. Step 5 skipped. "
fi

logging 'DEBUG' $logfile "SStart" "step 5 completed"


# Step 6. Update times for events of trading day
if [[ "$step_number" ]] && [ $step_number -gt 6  ];
then
    logging 'INFO' $logfile "SStart" "Step 6 has been skipped" 
else
    if [[ "$UPDATE_EST" == "N" ]]
    then
        logging 'INFO' $logfile "SStart" "STEP 6. Updating EST disabled in the global config"
    else
        logging 'INFO' $logfile "SStart" "STEP 6. Update times for events of trading day"
        script_name="update_system_times.sh"
        if [ -f $script_name ];
        then
            $bin_dir/$script_name $ats_db_string
            check_exit_code "$?" "Update_system_times" "$logfile"
        else
            logging 'ERROR' $logfile "SStart" "Script $script_name not found. Please check and try again (step 6)"
            exit 1
        fi
    fi
fi
logging 'DEBUG' $logfile "SStart" "step 6 completed"


# sheldonA Task #31603: update CONECTION_START_TIME for all Pricings in TQ
script_name="$py_common_dir/set_conn_start_time.py"
if [[ "$UPDATE_PS_CONNECTION_TIME" == "N" ]]
then
    logging 'INFO' $logfile "SStart" "UPDATE_PS_CONNECTION_TIME set to N.
    Skip step with updating PricingServer connection start time"
else
    if [[ "$VENUE" == "TNP" ]];
    then
        python $script_name $cfg_dir/ExactproSystemTimes.cfg 2>&1 | tee $logs_dir/set_conn_start_time.py.log
        if [[ "$?" != "0" ]];
        then
            log_msg="TQ ONLY STEP. Update of CONNECTION_START_TIME for all Pricing Servers completed with ERROR."
            logging 'ERROR' $logfile "SStart" "$log_msg"
        else
            log_msg="TQ ONLY STEP. Update of CONNECTION_START_TIME for all Pricing Servers successfully completed."
            logging 'INFO' $logfile "SStart" "$log_msg"
        fi
    fi
fi

# Step 7. Start Application checkpoint sequence
if [[ "$step_number" ]] && [ $step_number -gt 7 ];
then
    logging 'INFO' $logfile "SStart" "Step 7 has been skipped"
else
    if [[ "$CHECKPOINTER_SOD_STEP" == "Y" ]]
    then
        logging 'INFO' $logfile "SStart" "STEP 7. Start Application checkpoint sequence"
        sequence_name=$APP_CHKPT_SOD_SEQUENCE_NAME
        ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
        logging 'INFO' $logfile "SStart" "STEP 7. Start sequence: $sequence_name. Command: $ssi_cmd"
        eval $ssi_cmd
        check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"
        # waiting for moving flag FLAG_SYSTEM_CHKPT to Done state
        timer=$default_timer
        track_flag_status $sg_db_string 'FLAG_SYSTEM_CHKPT' '03' $timer
        if [ "$?" != 0 ]
        then
            logging 'ERROR' $logfile "SStart" "STEP 7. FLAG_SYSTEM_CHKPT not moved to DONE state"
            exit 1
        fi
    else
        logging 'INFO' $logfile "SStart" "STEP 7. Checkpointer step is  disabled in the global.cfg. Skipped"
    fi
fi

logging 'DEBUG' $logfile "SStart" "step 7 completed"


# Step 8. Reset some flags after Application Checkpoint performing
if [[ "$step_number" ]] && [ $step_number -gt 8 ];
then
    logging 'INFO' $logfile "SStart" "Step 8 has been skipped"
else
    logging 'INFO' $logfile "SStart" "Reset some flags after Application Checkpoint performing"
    script_name="$py_common_dir/check_flags_configuration.py"
    cmd="python $script_name RESET"
    eval $cmd
    sleep 5
fi
logging 'DEBUG' $logfile "SStart" "step 8 completed"

# Check flags configuration before start processes
script_name="$py_common_dir/check_flags_configuration.py"
cmd="python $script_name CHECK_RESET"
eval $cmd
check_exit_code "$?" "Check reset flags before start processes" "$logfile"

# Step 9. Start Application Processes
if [[ "$step_number" ]] && [ $step_number -gt 9 ];
then
    logging 'INFO' $logfile "SStart" "Step 9 has been skipped"
else
    logging 'INFO' $logfile "SStart" "Step 9. Start Application Processes"
    sequence_name=$START_APPLICATION_PROCESSES_SEQUENCE_NAME
    ssi_cmd=`python $py_common_script SSI Sequence $sequence_name`
    eval $ssi_cmd
    check_exit_code "$?" "Start_sequence_$sequence_name" "$logfile"
fi
timer=$default_timer
track_flag_status $sg_db_string 'STARTUP_SEQ' '03' $timer
if [ "$?" != 0 ]
then
    logging 'ERROR' $logfile "SStart" "STEP 9. STARTUP_SEQ not moved to DONE state"
    exit 1
else
    logging 'DEBUG' $logfile "SStart" "step 9 completed"
fi
# FSB
if [[ "$FSB" == "Y" ]]
then
    script_name="$py_common_dir/FSB_START.py"
    cmd="python $script_name"
    eval $cmd
fi

# Step 10. Start Multicast
if [[ "$step_number" ]] && [ $step_number -gt 10 ];
then
    logging 'INFO' $logfile "SStart" "Step 10 has been skipped"
else
    if [[ "$MULTICAST" == "Y" ]]
    then
        udp_dir="$tool_dir/UDPProxy_ITCH/"
        script_name="start_all_itch.sh"
        logging 'INFO' $logfile "SStart" "Start Multicast... ${udp_dir}/${script_name}"
        cd ${udp_dir}/ && ./${script_name} && cd -
        check_exit_code "$?" "Start Multicast" "$logfile"
    else
        logging 'INFO' $logfile "SStart" "Multicast disabled in the global.cfg. Skipped"
    fi
fi

# Step 11. Start pcap
if [[ "$step_number" ]] && [ $step_number -gt 11 ];
then
    logging 'INFO' $logfile "SStart" "Step 11 has been skipped"
else
    if [[ "$PCAP" == "Y" ]]
    then
        pcap_dir="$tool_dir/pcap/"
        script_name="start_all_pcap.sh"
        $pcap_dir/$script_name
        check_exit_code "$?" "Start PCAPs" "$logfile"
    else
        logging 'INFO' $logfile "SStart" "PCAPs disabled in the global.cfg. Skipped"
    fi
fi

# Step 13. Start SPO
if [[ "$step_number" ]] && [ $step_number -gt 13 ];
then
    logging 'INFO' $logfile "SStart" "Step 13 has been skipped"
else
    if [[ "$SPO" == "Y" ]]
    then
        spo_dir=$(dirname $SPO_SCRIPT_LINK)
        script_name=$(basename $SPO_SCRIPT_LINK)
        $spo_dir/$script_name
        check_exit_code "$?" "Start SPO" "$logfile"
    else
        logging 'INFO' $logfile "SStart" "SPO disabled in the global.cfg. Skipped"
    fi
fi

# Step 14. Start ML
if [[ "$step_number" ]] && [ $step_number -gt 14 ];
then
    logging 'INFO' $logfile "SStart" "Step 14 has been skipped"
else
    if [[ "$ML" == "Y" ]]
    then
        logging 'INFO' $logfile "SStart" "Step 14. Start MITCH_Listener"
        ML_dir="$tool_dir/MITCH_Listener"
        script_name="start_all_ml.sh"
        $ML_dir/$script_name
        check_exit_code "$?" "Start ML" "$logfile"
    else
        logging 'INFO' $logfile "SStart" "Start MITCH_Listener disabled in the global.cfg. Skipped"
    fi
fi

# FSB_LIFE_SUPPORTER
if [[ "$FSB_LIFE_SUPPORTER" == "Y" ]]
then
    script_name="FSB_life_supporter.sh"
    cd $bin_dir
    eval $script_name >> /dev/null 2>&1 &
    check_exit_code "$?" "FSB_LIFE_SUPPORTER start" "$logfile"
else
    logging 'INFO' $logfile "SStart" "FSB_LIFE_SUPPORTER disabled"
fi

# SSM_Archivator
if [[ "$SSM_ARCHIVATOR" == "Y" ]]
then
    cd $bin_dir 
    eval ./SSM_arch.sh >> /dev/null 2>&1 &
fi

# EXECUTOR_DEMON_STARTUP
if [[ "$EXECUTOR_DEMON_STARTUP" == "Y" ]]
then
    cd ${HOME}/QA_env_scripts/ExecutorDemon/
    eval ./start_executor_demon.sh >> /dev/null 2>&1 &
fi

# Restart mit_exporter
mit_exporter_home="${HOME}/services/mit_exporter"
mit_exp_run_script="./run.sh"
cd $mit_exporter_home && $mit_exp_run_script && cd -

# Start completed
procedure_file="$temp_dir/EST_PROCEDURE.txt"
time=$(cat $procedure_file | grep 'OP_DAY_START_TIME' | grep -oEe '[0-9]{2}:[0-9]{2}:[0-9]{2}')
logging 'INFO' $logfile "SStart" "The system successfully started. Day start at $time"
echo ''
exit 0
