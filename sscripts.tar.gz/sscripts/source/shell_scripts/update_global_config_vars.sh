#!/bin/bash

source ~/.bashrc
source ~/.anaconda3
script_name="$(basename $(readlink -f $0))"
bin_dir="$(dirname $(readlink -f $0))"
py_common_dir=$bin_dir/../py_common/
py_common_script="$py_common_dir/common.py"
cfg_dir=$bin_dir/../cfg/
logs_dir=$bin_dir/../logs/
if [[ "$1" ]]
then
    logfile="$1"
else
    logfile=$logs_dir/$script_name'.log'
fi

source $cfg_dir/global.cfg
source $cfg_dir/ExactproSystemTimes.cfg
source $bin_dir/common.sh

if [[ "$DATE" ]]
then
    new_date=$DATE
    ntd_date=$(echo $DATE | sed 's/\///g')
else
    new_date=$(date +%Y/%m/%d)
    ntd_date=$(date +%Y%m%d)
fi
logging 'INFO' $logfile $script_name "SYSTEM DATE: $new_date"

if [[ "$2" == '--check' ]];
then
    sg_db_string="$3"
    logging 'INFO' $logfile $script_name "Checking NEXT_TRADING_DAY in the db scheme"
    logging 'INFO' $logfile $script_name "SG_DB_STRING: $sg_db_string"
    #select value from SG4_CONFIGS where parameter = 'NEXT_TRADING_DAY';
    db_ntd_value=$(sqlplus -s $sg_db_string <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE PARAMETER = 'NEXT_TRADING_DAY';
QUIT;
EOQUERY
)
    ntd_value=$(echo $db_ntd_value | sed '/^$/d')
    if [[ "$ntd_value" == "$ntd_date" ]]
    then
        logging 'INFO' $logfile $script_name "NEXT_TRADING_DAY in the SG4_CONFIGS table equal $ntd_date"
        exit 0
    else
        logging 'ERROR' $logfile $script_name "NEXT_TRADING_DAY. Expected value: $ntd_date. Actual value: $ntd_value"
        exit 1
    fi
fi



# SYSTEM_DATE
logging 'INFO' $logfile $script_name "Updating SYSTEM_DATE to $new_date..." 
ssi_cmd=$($py_common_script SSI Global SYSTEM_DATE $new_date)
eval $ssi_cmd
check_exit_code $? "Update SYSTEM_DATE. $ssi_cmd" "$logfile"


# NEXT_TRADING_DAY
logging 'INFO' $logfile $script_name "Updating NEXT_TRADING_DAY to $ntd_date..."
ssi_cmd=$($py_common_script SSI Global NEXT_TRADING_DAY $ntd_date)
eval $ssi_cmd
check_exit_code $? "Update NEXT_TRADING_DAY. $ssi_cmd" "$logfile"


# DSG_TRADING_DATE
logging 'INFO' $logfile $script_name "Updating DSG_TRADING_DATE to $ntd_date..."
ssi_cmd=$($py_common_script SSI Global DSG_TRADING_DATE $ntd_date)
eval $ssi_cmd
check_exit_code $? "Update DSG_TRADING_DATE. $ssi_cmd" "$logfile"



logging 'INFO' $logfile $script_name "Update Global Configurations successfully completed"
exit 0
