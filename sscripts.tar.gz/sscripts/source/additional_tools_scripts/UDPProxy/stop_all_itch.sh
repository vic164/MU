#!/bin/bash
script_folder="$(dirname $(readlink -f $0))"
cd ${script_folder}

for ign in $(echo "1 2 3 4 5 6 7")
do
    ${script_folder}/stop_itch.sh ${ign}
done
