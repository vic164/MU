#!/bin/bash
script_folder="$(dirname $(readlink -f $0))"
cd ${script_folder}
h=$(hostname)
for ign in $(echo "1 2 3 4 5 6 7")
do
    ssh ${h} "${script_folder}/start_itch.sh ${ign}" &
    sleep 2
done


