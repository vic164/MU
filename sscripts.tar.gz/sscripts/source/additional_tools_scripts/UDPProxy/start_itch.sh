#!/bin/bash

script_folder="$(dirname $(readlink -f $0))"
cd $script_folder
gw_n=$1
PIDFILE="${script_folder}/pid${gw_n}"
java -Xmx64m -jar multicastProxy_ITCH${gw_n}.jar -c config${gw_n}.xml -l log.xml & echo $! > $PIDFILE
sleep 1
echo -e "\n"

