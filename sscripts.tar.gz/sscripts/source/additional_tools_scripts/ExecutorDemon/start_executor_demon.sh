#!/bin/bash

demon_home_dir="$(dirname $(readlink -f $0))"
jarname="restexecutor-0000-1.0-SNAPSHOT.jar"
cd $demon_home_dir && java -jar $jarname  & #>> /dev/null 2>&1 & 
