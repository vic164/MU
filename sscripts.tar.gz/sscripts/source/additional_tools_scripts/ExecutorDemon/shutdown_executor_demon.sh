#!/bin/bash

jarname="restexecutor-0000-1.0-SNAPSHOT.jar"
demon_pid=$(ps x | grep ${jarname} | grep -v grep | cut -d ' ' -f 1)
if [[ "${demon_pid}" ]]
then
    kill -9 ${demon_pid}
fi
