#!/bin/bash

script_name="$(basename $(readlink -f $0))"
demon_scripts_dir="$(dirname $(readlink -f $0))"
py_common_script="${HOME}/QA_env_scripts/env_maintenance_scripts/py_common/common.py"
ats_db_string=$(python ${py_common_script} db_string ATS)
#echo $ats_db_string

# Arguments:
trading_cycle="$(echo $1 | sed 's/__/%/g')"
session_name="$(echo $2 | sed 's/__/%/g')"
event="$3" # start or stop
time_change="$4" 

 # UPDATE ATS_SESSION_TIMES SET START_TIME = TO_CHAR('11:20:09'), END_TIME = TO_CHAR('11:25:09') WHERE SESSION_ID = 'Opening Auction Call' AND TRADING_CYCLE_ID = 'SETS-L1';
if [[ "$(echo ${event} | tr a-z A-Z | grep START)" ]]
then
    session_event="START_TIME"
elif [[ "$(echo ${event} | tr a-z A-Z | grep END)" ]]
then
    session_event="END_TIME"
else
    echo "Unknown event ${event}"
    exit 1
fi
query_text="SELECT ${session_event} FROM ATS_SESSION_TIMES WHERE TRADING_CYCLE_ID like '${trading_cycle}' AND SESSION_ID like '${session_name}'"
answer=$(sqlplus -s "$ats_db_string" <<EOQUERY
set heading off;
${query_text};
EOQUERY
)

#echo ${answer}

#     #{modifyDateTime("h=20:m=20:s=22")}
datetime_point=$(date --date $answer)
new_datetime_point=$(date --date "${datetime_point} ${time_change}")
hh=$(date --date "$new_datetime_point" +%H)
mm=$(date --date "$new_datetime_point" +%M)
ss=$(date --date "$new_datetime_point" +%S)
result=" h=${hh}:m=${mm}:s=${ss} "

#echo "result"
echo "$result"
value_bkp="$5"
if [[ "$value_bkp" ]]
then
    echo "$(date --date "$new_datetime_point" +%H:%M:%S)" > $demon_scripts_dir/${value_bkp}.tmp
fi
exit 0
