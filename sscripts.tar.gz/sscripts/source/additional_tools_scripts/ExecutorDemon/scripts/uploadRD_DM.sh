#!/bin/bash

script_name="$(basename $(readlink -f $0))"
demon_scripts_dir="$(dirname $(readlink -f $0))"
#demon_home_dir="$(dirname $demon_scripts_dir)"
#refdata_dir="$(dirname $demon_home_dir)/RefData/"
refdata_dir="${HOME}/QA_env_scripts/RefData/ExecutorDemon"
temp_dir="${HOME}/QA_env_scripts/env_maintenance_scripts/temp/"
upload_now_dir="${temp_dir}/upload_now"
py_common_dir="${HOME}/QA_env_scripts/env_maintenance_scripts/py_common/"
uploader_script="single_upload_set.py"
if [ -d $upload_now_dir ]; then rm -rf $upload_now_dir; fi
mkdir $upload_now_dir

testsuite_name="$1"
upload_number="$2"
tag_name="$3"
file_with_value="$demon_scripts_dir/${tag_name}.tmp"
if [ -a $file_with_value ]
then
    new_value=$(cat $demon_scripts_dir/CPXEndTime.tmp)
else
    new_value=""
fi

testsuite_dir="${refdata_dir}/$testsuite_name"
if ! [ -d $testsuite_dir ]; then echo "Directory with RefData not found. Exit."; exit 1; fi

for xml_file in $(find $testsuite_dir -type f -name '*.xml')
do
    xml_filename=$(basename $xml_file)
    if [[ "$xml_filename" == "Scenario.xml" ]]; then continue; fi
    if [[ "$(echo $xml_filename | grep $upload_number)" ]]
    then
        new_filename=$(echo $xml_filename | sed "s@${upload_number}@@g")
        new_filepath=${upload_now_dir}/${new_filename}
        if [[ "$tag_name" ]] && [[ "$new_value" ]]
        then
            new_xml_child="<${tag_name}>${new_value}</${tag_name}>"
            sed -i "s@<${tag_name}.*@${new_xml_child}@g" $xml_file
        fi
        cp $xml_file $new_filepath
    fi
done
if ! [[ "$(ls $upload_now_dir)" ]]; then echo "Nothing to upload. Exit."; exit 1; fi
if [ -a $file_with_value ]; then rm -f $file_with_value; fi

#cd ${uploader_dir} && python ${uploader_script} --rd_path ${upload_now_dir} --to_start_env_before N --to_move_to_inter N --to_compare_rd_with_download N --to_download_fresh_rd N --to_unzip_fresh_merged_rd N --to_upload_rd Y --to_shutdown_after N 
cd ${py_common_dir} && python ${uploader_script} ${upload_now_dir} 
wait
exit 0
