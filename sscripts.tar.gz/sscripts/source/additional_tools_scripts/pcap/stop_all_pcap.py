#! /usr/bin/env python

import os
import re
import sys
import pwd
import shutil
import tarfile
import datetime
import logging
import subprocess
py_common_dir = os.path.join(os.environ['HOME'], 'QA_env_scripts', 'env_maintenance_scripts', 'py_common')
sys.path.insert(0, py_common_dir)
import common


def deletion_old_pcaps(host, logfilename):
    dirpath = os.path.dirname(os.path.realpath(__file__))
    now_time = datetime.datetime.now()
    max_age = 2
    p = subprocess.Popen('ssh {h} "ls -A {s}"'.format(
                          h=host, s=dirpath,),
                          stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                          shell=True, universal_newlines=True
                          )
    out, err = p.communicate()
    for f_entry in out.split('\n'):
        if not re.search('[0-9]{8}', f_entry):
            continue
        datetime_namepart_fentry = re.search('[0-9]{8}', f_entry).group(0)
        date_f_entry = datetime.datetime.strptime(datetime_namepart_fentry, '%Y%m%d')
        delta = now_time - date_f_entry
        if delta.days > max_age:
            print('-gt max age')
            common.info_output('Folder {f} deleted as outdated (max age > {age} days)'. format(
                f=os.path.join(dirpath, f_entry),
                age=max_age
            ), logfilename)
            p = subprocess.Popen('ssh {h} "rm -rf {s}/{f}"'.format(
                          h=host, s=dirpath, f=f_entry),
                          stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                          shell=True, universal_newlines=True
                          )
            out, err = p.communicate()


def stop_pcaps(hosts, script_directory):
    for host in hosts:
        p = subprocess.Popen('ssh {h} "cd {s} && ./stop_capture.sh"'.format(
                             h=host, s=script_directory),
            stderr=subprocess.PIPE, stdout=subprocess.PIPE,
            shell=True, universal_newlines=True
            )
        out, err = p.communicate()
        deletion_old_pcaps(host, logfilename)


if __name__ == '__main__':
    script_directory = os.path.dirname(os.path.realpath(__file__))
    os.chdir(script_directory)
    script_name = os.path.basename(os.path.realpath(__file__))
    logs_directory = os.path.join(os.path.dirname(py_common_dir), 'logs')
    logfilename = os.path.join(logs_directory, (script_name + '.log'))
    with open(logfilename, 'w') as x:
        x.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfilename)
    common.info_output('Get hosts for searching pcap files', logfilename)
    hosts = common.get_all_hosts()
    common.info_output(str(hosts), logfilename)
    stop_pcaps(hosts, script_directory)
    common.info_output('==============\nExecution is completed', logfilename)
