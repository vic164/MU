#!/bin/sh


source ~/.bashrc
script_home_dir="$(dirname $(readlink -f $0))"
envname=$(whoami)
pcap_cfg_filename="pcap_${envname}.cfg"
pcap_cfg_filepath=${script_home_dir}/${pcap_cfg_filename}
cd ${script_home_dir}
echo ${envname}
echo ${pcap_cfg_filename}
echo ${pcap_cfg_filepath}
wai=$(whoami)
if [[ $(ps -ef | grep ${wai} | grep tcpdump | grep -v grep | wc -l) -ne 0 ]]
then
    stop_script="stop_capture.sh"
    ${stop_script}
fi

DA=$(date +%Y%m%d_%H%M%S)
if [[ "${1}" != "" ]];
then
    DA=$1
fi
ENV=$(ls ${HOME}/*_env | head -1)
DIR=${script_home_dir}/${DA}

if [[ -f ${pcap_cfg_filepath} ]]
then
    CFG_FILE=${pcap_cfg_filepath}
else
    echo "ERROR: Config file  ${pcap_cfg_filename} wasn't found in $script_home_dir."
    exit 2
fi

if ! [[ -d ${DIR}  ]]
then
    mkdir ${DIR}
fi

if ! [[ -d ${DIR}/calc ]]
then
    mkdir ${DIR}/calc
fi

for line in $(cat ${CFG_FILE})
do
    if [[ "$(echo ${line} | cut -f 1 -d ',' | grep ccp)" ]]
    then
        if ! [[ -d ${DIR}/ccp/ ]]
        then
            mkdir -p ${DIR}/ccp/
        fi
    else
        if ! [[ -d ${DIR}/$(echo ${line} | cut -f 1 -d ",") ]]
        then
            mkdir ${DIR}/$(echo ${line} | cut -f 1 -d ",")
        fi
    fi
done

for i in $(cat ${CFG_FILE})
do
    PR=$(echo ${i} | cut -d ',' -f 1)
    IP=$(echo ${i} | cut -d ',' -f 2)
    PORT=$(echo ${i} | cut -d ',' -f 3)
    if ! [[ "$(echo $PR | grep ccp)" ]]; 
    then
        let "PORT=${PORT}+${S_REG_PORT_NO}" #$(cat ${ENV} | grep "S_REG_PORT_NO" | cut -f 2 -d "=")
    fi
    traffic_filter=""
    if [[ "${PR}" == "itch" || "${PR}" == "fast" ]];
    then
        # for udp proto: just capture anything from src port and src host
        traffic_filter="dst host ${IP} and dst port ${PORT}"
    elif [[ "$(echo $PR | grep ccp)" ]];
    then
        # in case of client-type gateway, HOST address in config should be set to an address of server, not the gateway process host
        traffic_filter="(dst host ${IP} and dst port ${PORT}) or (src host ${IP} and src port ${PORT})"
    else
        # for tcp proto
        # get all public ips for host
        ips=$(ip -f inet -tshort -oneline addr | grep 'scope global' | \
        sed -r 's/.*inet (([0-9]{1,3}\.){3}[0-9]{1,3})\/.*/\1/g')
        # hardcoded creation of filter for outgoing traffic from PORT and all ips of the host
        ip_filter=$(echo "${ips}" | sed -r 's/^([0-9]{1})/src host \1/')
        ip_filter=$(echo ${ip_filter} | sed -r 's/([0-9]{1}) s/\1 or s/g')
        # capture any traffic (mostly incoming) to our PORT and also
        # capture any outgoing traffic from our PORT and from any of our ips of the host
        traffic_filter="dst port ${PORT} or (src port ${PORT} and (${ip_filter}))"
    fi
    if [[ "$(echo $PR | grep ccp)" ]];
    then
        tcpdump -s 0 -w ${DIR}/ccp/${PR}_${DA}_${IP}_${PORT}.pcap -i any ${traffic_filter} -Z ${USER} &
    else
        tcpdump -s 0 -w ${DIR}/${PR}/${PR}_${DA}_${IP}_${PORT}.pcap -i any ${traffic_filter} -Z ${USER} &
    fi
done

sleep 1
echo -e "\n"

