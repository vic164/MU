#!/bin/bash

source ~/.bashrc
wai=$(whoami)
DATEBEF=$(date +%Y%m%d -d "-1 day")
script_home_dir="$(dirname $(readlink -f $0))"
cd $script_home_dir
BOXIP=$(echo $SSH_CONNECTION | cut -d ' ' -f 3)
ip_for_db="'$BOXIP'"
BOX=$(sqlplus -s $SG_DB_STRING <<EOQUERY
set heading off;
set FEEDBACK OFF;
select host from sg4_hosts where ip = $ip_for_db;
QUIT;
EOQUERY
)
for pid in $(ps -ef | grep $wai | awk '/tcpdump/ {print $2}'); do kill -9 $pid; done
#for pid in $(ps -ef | awk '/tcpdump/ {print $2}'); do sudo kill -9 $pid; done

