#!/bin/bash

source ~/QA_env_scripts/env_maintenance_scripts/bin/common.sh
script_folder="$(dirname $(readlink -f $0))"
echo $script_folder
cd $script_folder
envname=$(whoami)

### sg_connection_string ###
if [[ "$SG_DB_STRING" ]];
then
    sg_connection_string=$SG_DB_STRING
else
    py_common_dir=${script_folder}/../py_common
    py_common_script=${py_common_}/common.py
    sg_connection_string=$($py_common_script db_string SG)
fi

echo $sg_connection_string
#read

### hosts ###
hosts=$(get_host_list $sg_connection_string)

### directory structure ###
for host in $(echo "$hosts")
do
    ssh $host "~/QA_env_scripts/env_maintenance_scripts/tools/pcap/stop_capture.sh" &
    sleep 1
done
sleep 7
DA=$(date +%Y%m%d_%H%M%S)
for host in $(echo "$hosts")
do
    ssh $host "~/QA_env_scripts/env_maintenance_scripts/tools/pcap/start_capture.sh $DA" &
    sleep 1
done

