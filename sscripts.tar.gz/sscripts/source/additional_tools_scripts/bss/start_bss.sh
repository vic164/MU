#!/bin/bash

current_dir="$(dirname $(readlink -f $0))"

host=$(hostname)
env_name_part=$(whoami | sed 's/-s//g')
bridge_bin_name="bridge_stream_server_${env_name_part}"
${current_dir}/stop_bss.sh
sleep 5

ssh $host "cd ${current_dir} && ./${bridge_bin_name} -s" &

