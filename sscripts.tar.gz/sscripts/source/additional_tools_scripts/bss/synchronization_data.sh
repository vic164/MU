#!/bin/bash


current_dir="$(dirname $(readlink -f $0))"
w=$(whoami)
if ! [[ "$w" == "tqex2-s" ]]
then
    rm -rf $current_dir/data
    sleep 5
    cp -r /app/x01/tqex2-s/QA_env_scripts/env_maintenance_scripts/tools/bss/data/ ${current_dir}/
fi

