#!/bin/bash

current_dir="$(dirname $(readlink -f $0))"
a=$(whoami)
echo $a > $current_dir/stop_bss.log

env_name_part=$(whoami | sed 's/-s//g')
bridge_bin_name="bridge_stream_server_${env_name_part}"
p=$(pidof ${bridge_bin_name})
echo ${p} >> $current_dir/stop_bss.log
kill ${p}

sleep 5

