#!/bin/bash
script_folder="$(dirname $(readlink -f $0))"
cd ${script_folder}
host=$(hostname)
for ign in $(echo "1 2 3 4 5 6 7")
do
    ${script_folder}/startmerge_single_ml.sh ${ign} | sed -r "s@^@[ml${ign}_merge.out]: @g" >>  mergeallmls.out &
    sleep 2
done

