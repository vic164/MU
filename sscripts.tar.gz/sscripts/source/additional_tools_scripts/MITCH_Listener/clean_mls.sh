#!/usr/bin/env bash

script_folder="$(dirname $(readlink -f $0))"
script_name="$(basename $(readlink -f $0))"
#gw_n=$(echo "$script_name" | sed "s@startmerge_${USER}_@@g" | sed 's/.sh//g')
gw_n="0$1"
cd $script_folder
rm -f ${script_folder}/logs_*/*
rm -f ${script_folder}/Merged/*
