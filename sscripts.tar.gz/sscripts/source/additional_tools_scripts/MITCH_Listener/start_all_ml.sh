#!/bin/bash
script_folder="$(dirname $(readlink -f $0))"
cd ${script_folder}
host=$(hostname)
for ign in $(echo "1 2 3 4 5 6 7")
do
    echo "ssh ${host} \"${script_folder}/start_single_ml.sh ${ign} >> ${script_folder}/ml${ign}.out\" &"
    ssh ${host} "${script_folder}/start_single_ml.sh ${ign} >> ${script_folder}/ml${ign}.out" &
    sleep 2
done

