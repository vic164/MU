#!/usr/bin/env bash

script_folder="$(dirname $(readlink -f $0))"
script_name="$(basename $(readlink -f $0))"
gw_n="$1"
cd $script_folder
PIDFILE="${script_folder}/pid${gw_n}"
kill  $(cat $PIDFILE)
wait
rm -f ${PIDFILE}

