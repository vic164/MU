#!/usr/bin/env bash

script_folder="$(dirname $(readlink -f $0))"
script_name="$(basename $(readlink -f $0))"
cd $script_folder
gw_n=$1
PIDFILE="${script_folder}/pid${gw_n}"

cfg_path="${script_folder}/${USER}_0${gw_n}_config.cfg"
./mitch_listener_${USER}_0${gw_n} -c ${cfg_path} -s & echo $! > $PIDFILE

