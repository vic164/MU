#!/usr/bin/env bash

script_folder="$(dirname $(readlink -f $0))"
script_name="$(basename $(readlink -f $0))"
#gw_n=$(echo "$script_name" | sed "s@startmerge_${USER}_@@g" | sed 's/.sh//g')
gw_n="0$1"
cd $script_folder

cfg_example_path="${script_folder}/${USER}_${gw_n}_config.cfg"
maincfg_name=$(basename $cfg_example_path | sed 's/\.cfg//g' | sed 's/config//g')
newcfg_name="${maincfg_name}_buconfig.cfg"
new_cfg="${script_folder}/${newcfg_name}"
cp $cfg_example_path $new_cfg
gw_name_part=$(echo $maincfg_name)
sed -i "s@sequencer\ =\ date@sequencer\ =\ simple@g" $new_cfg

outfile=$(find ${script_folder}/logs_${USER}_${gw_n}/ -type f -name 'out_*')
repfile=$(find ${script_folder}/logs_${USER}_${gw_n}/ -type f -name 'rep_*')
outfilename=$(basename $outfile | sed 's/_00000000//g')
repfilename=$(basename $repfile | sed 's/_00000000//g')
date_name_part=$(echo ${outfilename} | grep -oEe '[0-9]{12}')

sed -i "s@sequencer\ =\ date@sequencer\ =\ simple@g" $new_cfg
sed -i "s@out_.*\$@${outfilename}@g" $new_cfg
sed -i "s@rep_.*\$@${repfilename}@g" $new_cfg


./mitch_listener_${USER}_${gw_n} -c ${new_cfg} -r

wait

finfiles=$(find ${script_folder}/logs_${USER}_${gw_n}/ -type f -name 'fin_*')
for finfile in $(echo "$finfiles")
do
    finfilename=$(basename $finfile)
    new_filename="${finfilename}_${gw_name_part}${date_name_part}"
    new_filepath="${script_folder}/Merged/${new_filename}"
    cp $finfile $new_filepath
done

#rm -f ${script_folder}/logs_${USER}_${gw_n}/*00000000
