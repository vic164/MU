#!/bin/bash

source ~/.anaconda3
script_folder="$(dirname $(readlink -f $0))"
cfg_folder="${script_folder}/MITCH_Listener/"
#users_cfg_file="${cfg_folder}/users.csv"
envname=$(whoami)

csv_config_file="${cfg_folder}/${envname}_config.csv"
echo "name;mlproto;mdg;mcastip;mcastport;mcastif;replayip;replayport;replayuser;replaypwd;recoveryip;recoveryport;recoveryuser;recoverypwd" > $csv_config_file

interfaces=$(/sbin/ifconfig -s  | cut -d ' ' -f 1 | grep -v Iface)
echo $interfaces

python_common_script_path="${script_folder}/../py_common/common.py"
SG_DB_STRING=$(python $python_common_script_path db_string SG)
ATS_DB_STRING=$(python $python_common_script_path db_string ATS)
hosts=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT HOST FROM SG4_HOSTS;
QUIT;
EOQUERY
)

echo $hosts
mlproto="trm2"

number=0
config="1 2 3 4 5 6 7 8"
for number in $config
do
    owner="'MarketDataOut:${number}:1'"
    primary_gateway_name="'MarketDataOut:${number}:1:ITCHGateway:1'"
    gw_number="'MarketDataOut:${number}'"
    echo "$owner"
    name_gw="${envname}_0${number}"
    cmd="SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${primary_gateway_name}  AND PARAMETER = 'APPL_ID'  AND INH_DEF = 'ITCHGateway';"
    mdg_value=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    mdg_value="$(echo ${mdg_value})"
    mdg=$(printf "%d" \'${mdg_value})
    echo "$cmd"
    echo "mdg_value= $mdg_value"
    cmd="SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = 'PRIMARY_MCAST_IP' AND INH_DEF = 'ITCHGateway';"
    primary_mcast_ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    
    echo "$cmd"
    echo "primary_mcast_ip= $primary_mcast_ip"
    cmd="SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = 'PRIMARY_MCAST_PORT_OFFSET' AND INH_DEF = 'ITCHGateway';"
    primary_port=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    echo "$cmd"
    echo "primary_port= $primary_port"
    cmd="SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${gw_number} AND PARAMETER = 'REPLAY_CHANNEL_PORT_OFFSETS' AND INH_DEF = 'ITCHGateway';"
    replay_port=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    echo "$cmd"
    echo "replay_port= $replay_port"
    cmd="SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${gw_number} AND PARAMETER = 'SNAPSHOT_CHANNEL_PORT_OFFSETS' AND INH_DEF = 'ITCHGateway';"
    recovery_port=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    echo "$cmd" 
    echo "recovery_port= $recovery_port"

    cmd="SELECT IP FROM SG4_HOSTS WHERE HOST like (SELECT HOST FROM SG4_MACHINES WHERE NAME like (SELECT MACHINE FROM SG4_INSTANCES WHERE PROC_DEF = 'ITCHGateway' and PART_INST_ID = '${number}' AND proc_inst_id = '1'));"
    replay_recovery_channel_ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    echo "$cmd" 
    echo "replay_recovery_channel_ip= $replay_recovery_channel_ip"

    pip=$(echo $pip);

    # primary_port
    primary_port=$(echo $primary_port);
    let "primary_port=$primary_port+$S_REG_PORT_NO"

    # replay_port
    replay_port=$(echo $replay_port);
    let "replay_port=$replay_port+$S_REG_PORT_NO"

    # recovery_port
    recovery_port=$(echo $recovery_port);
    let "recovery_port=$recovery_port+$S_REG_PORT_NO"

    ########
    # username, login, pass
    broker_regexp="'MLML%${number}'"
    cmd="SELECT USER_NAME FROM ATS_USERS WHERE USER_NAME like ${broker_regexp};"
    username=$(sqlplus -s "$ATS_DB_STRING" <<EOQUERY
set heading off;
${cmd}
QUIT;
EOQUERY
)
    echo $cmd
    pass=$(sqlplus -s "$ATS_DB_STRING" <<EOQUERY
set heading off;
SELECT ATTRIBUTE_VALUE FROM AUTH_PAM_POLICY_ATTR WHERE POLICY_NAME = 'Default' AND ATTRIBUTE_NAME = 'DefaultPassword';
QUIT
EOQUERY
)
    good_host=$(echo $SSH_CONNECTION | cut -d ' ' -f 3)
    echo "good host: ${good_host}"
    if [[ "$good_host" ]]
    then
        mcastinterface=${good_host}
    fi
    login="$username"
    primary_mcast_ip="$(echo ${primary_mcast_ip})"
    primary_port="$(echo ${primary_port})"
    replay_port="$(echo ${replay_port})"
    recovery_port="$(echo ${recovery_port})"
    username="$(echo ${username})"
    pass="$(echo ${pass})"
    mcastinterface="$(echo ${mcastinterface})"
    replay_recovery_channel_ip="$(echo ${replay_recovery_channel_ip})"
    echo "${name_gw};${mlproto};${mdg};${primary_mcast_ip};${primary_port};${mcastinterface};${replay_recovery_channel_ip};${replay_port};${username};${pass};${replay_recovery_channel_ip};${recovery_port};${username};${pass}" >> $csv_config_file
    echo "${name_gw};${mlproto};${mdg};${primary_mcast_ip};${primary_port};${mcastinterface};${replay_recovery_channel_ip};${replay_port};${username};${pass};${replay_recovery_channel_ip};${recovery_port};${username};${pass}"
done
rm -f ${script_folder}/ML_prepare.log
