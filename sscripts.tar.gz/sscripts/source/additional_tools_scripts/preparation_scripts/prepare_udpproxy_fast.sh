#!/bin/bash

script_folder="$(dirname $(readlink -f $0))"
UDP_folder="${script_folder}/UDPProxy_FAST"


if [[ "$1" ]] 
then
    let "start_port_fast=$1-1"
else
    echo "Usage: ./prepare_udpproxy_fast.sh <first fast port>"; exit 101
fi
number=0
config="1 2 3 4 5 6 7"
start_all="${UDP_folder}/start_all_fast.sh"
stop_all="${UDP_folder}/stop_all_fast.sh"
machine=$(echo $SSH_CONNECTION | cut -d ' ' -f 3)
echo '#!/bin/bash' >$start_all; echo '#!/bin/bash' >$stop_all;
chmod u+x $start_all; chmod u+x $stop_all;
for number in $config
do
    let "port=${start_port_fast}+$number"
    echo "port: $port"
    cp ${UDP_folder}/config.xml ${UDP_folder}/config${number}.xml
    owner="'MarketDataOut:${number}:1'"

    pip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = 'PRIMARY_MCAST_IP' AND INH_DEF = 'FASTGateway';
QUIT;
EOQUERY
)
    pport=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = 'PRIMARY_MCAST_PORT_OFFSET' AND INH_DEF = 'FASTGateway';
QUIT;
EOQUERY
)
    machine=$(echo $machine); pip=$(echo $pip); pport=$(echo $pport);  let "pport=$pport+$S_REG_PORT_NO"
echo "machine_ip: $machine; primary ip: $pip; primary port: $pport"
    conf_file="${UDP_folder}/config${number}.xml"
    sed -i "s@PRIMARY_MCAST_PORT_OFFSET@${pport}@g" $conf_file
    sed -i "s@PRIMARY_MCAST_IP@${pip}@g" $conf_file
    sed -i "s@<port>8080<@<port>${port}<@g" $conf_file
    sed -i "s@<interface>IP<@<interface>${machine}<@g" $conf_file
    ########
    cp ${UDP_folder}/multicastProxy_FAST.jar ${UDP_folder}/multicastProxy_FAST${number}.jar
    ########
    cp ${UDP_folder}/start_fast.sh  ${UDP_folder}/start_fast${number}.sh
    sed -i "s@multicastProxy_FAST.jar@multicastProxy_FAST${number}.jar@g" ${UDP_folder}/start_fast${number}.sh
    sed -i "s@config.xml@config${number}.xml@g"  ${UDP_folder}/start_fast${number}.sh
    ########
    cp ${UDP_folder}/stop_fast.sh ${UDP_folder}/stop_fast${number}.sh
    sed -i "s@multicastProxy_FAST@multicastProxy_FAST${number}@g" ${UDP_folder}/stop_fast${number}.sh
    echo "${UDP_folder}/start_fast${number}.sh" >>$start_all
    echo "${UDP_folder}/stop_fast${number}.sh" >>$stop_all
done


