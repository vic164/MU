#!/bin/bash

script_folder="$(dirname $(readlink -f $0))"
echo $script_folder
envname=$(whoami)
cd $script_folder

file="${script_folder}/pcap.cfg"
result="${script_folder}/pcap/pcap_${envname}.cfg"
result_filename="pcap_${envname}.cfg"
mkdir -p ${script_folder}/pcap/

### sg_connection_string ###
if [[ "$SG_DB_STRING" ]];
then
    sg_connection_string=$SG_DB_STRING
else
    py_common_dir=${script_folder}/../py_common
    py_common_script=${py_common_}/common.py
    sg_connection_string=$($py_common_script db_string SG)
fi

echo $sg_connection_string
#read

### hosts ###
hosts=$(sqlplus -s "$sg_connection_string" <<EOQUERY
set heading off;
SELECT HOST FROM SG4_HOSTS;
QUIT;
EOQUERY
)
echo "$hosts"
#read

### directory structure ###

for host in $(echo "$hosts")
do
    ssh $host "mkdir -p QA_env_scripts/env_maintenance_scripts/tools/pcap"
    ssh $host "echo '' >QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
    scp ${script_folder}/pcap/start_capture.sh $host:~/QA_env_scripts/env_maintenance_scripts/tools/pcap/
    scp ${script_folder}/pcap/stop_capture.sh $host:~/QA_env_scripts/env_maintenance_scripts/tools/pcap/
done    

for string in $(cat $file)
do
    gw=$(echo $string | cut -d ',' -f 1)
    ip_num=$(echo $string | cut -d ',' -f 2 | grep -oEe '[0-9]{1,}')
    ip_def="'$(echo $string | cut -d ',' -f 2 | sed "s@_${ip_num}@@g")'"
    port_def="'$(echo $string | cut -d ',' -f 3 | sed "s@_${ip_num}@@g")'"
    case $gw in
        itch ) owner="'MarketDataOut:${ip_num}:1'"; inhdef="'ITCHGateway'";;
        itchrp|itchsn ) owner="'MarketDataOut:${ip_num}'"; inhdef="'ITCHGateway'";;
        fix ) owner="'FixGroup:${ip_num}:1'"; inhdef="'FixGateway'";;
        dc ) owner="'FixGroup:${ip_num}:1'"; inhdef="'DropCopyGateway'";;
        pt ) owner="'PostTrade:${ip_num}:1'"; inhdef="'PostTradeGateway'";;
        nat|natrc ) owner="'Native:1:1:NativeGateway:${ip_num}'"; inhdef="'NativeGateway'";;
        fast ) owner="'MarketDataOut:${ip_num}:1'"; inhdef="'FASTGateway'";;
        fastrp|fastsn ) owner="'MarketDataOut:${ip_num}'"; inhdef="'FASTGateway'";;
        dsgmd ) owner="'DSG:${ip_num}:1:DSGMDGateway:1'"; inhdef="'DSGMDGateway'";;
        dsgom ) owner="'DSG:${ip_num}:1:DSGOMGateway:1'"; inhdef="'DSGOMGateway'";;
        dsgpt ) owner="'DSG:${ip_num}:1:DSGPTGateway:1'"; inhdef="'DSGPTGateway'";;
    esac

    if [[ "$(echo $gw | grep 'nat')" ]];
    then
        ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT IP FROM SG4_HOSTS WHERE HOST like (SELECT HOST FROM SG4_MACHINES WHERE NAME like (SELECT MACHINE FROM SG4_INSTANCES WHERE PROC_DEF = ${inhdef} AND PART_INST_ID = '1' AND proc_inst_id = ${ip_num}));
QUIT;
EOQUERY
)
    elif [[ "$gw" == "itch" || "$gw" == "fast" ]]
    then
        ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = ${ip_def} AND INH_DEF = ${inhdef};
QUIT;
EOQUERY
)
    else
        ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT IP FROM SG4_HOSTS WHERE HOST like (SELECT HOST FROM SG4_MACHINES WHERE NAME like (SELECT MACHINE FROM SG4_INSTANCES WHERE PROC_DEF = ${inhdef} AND PART_INST_ID = ${ip_num} AND proc_inst_id = '1'));
QUIT;
EOQUERY
)
    fi
    port=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = ${port_def} AND INH_DEF = ${inhdef};
QUIT;
EOQUERY
)
    if [[ "$(echo $gw | grep ccp)" ]];
    then
        for i in $(echo "1 2");
        do
            if [[ "$gw" == "ccp_eccp" ]]
            then
                ccp_inst_name="EURO"
            else
                ccp_inst_name=$(echo $gw | tr a-z A-Z | sed 's/^CCP_//g' | sed 's/X-CLEAR/XCLEAR/g')
            fi
            echo $ccp_inst_name
            ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT IP FROM SG4_HOSTS WHERE HOST like (SELECT HOST FROM SG4_MACHINES WHERE NAME like (SELECT MACHINE FROM SG4_INSTANCES WHERE DISPLAY_NAME like 'PostTrade%-${ccp_inst_name}:1'));
QUIT;
EOQUERY
)
            echo "IP of CCP: ${ip}"
            pt=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT DISPLAY_NAME FROM SG4_INSTANCES WHERE DISPLAY_NAME like 'PostTrade%-${ccp_inst_name}:1';
QUIT;
EOQUERY
)
            pt_n=$(echo $pt | grep -oEe 'PostTrade:[0-9]')
            echo "PT_number: $pt_n"
            external_service=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = '${pt_n}' AND PARAMETER = 'EXTERNAL_SERVICE';
QUIT;
EOQUERY
)
            echo "External service: ${external_service}"
            port=$(echo ${external_service} | grep -oEe ':[0-9]{1,}' | sed 's/://g')
            echo "Port found: ${port}"
        done
    fi

    if [[ "$(echo $port | grep "no rows selected")" ]]; then echo "ERROR. For $string port has not been found"; continue;fi
    if [[ "$(echo $ip | grep "no rows selected")" ]]; then echo "ERROR. For $string ip has not been found"; continue; fi
    if [[ "$(echo $port | grep "ORA")" ]]; then echo "ERROR. For $string port has not been found"; continue;fi
    if [[ "$(echo $ip | grep "ORA")" ]]; then echo "ERROR. For $string port has not been found"; continue;fi

    host=$(echo $ip | sed 's/\ //g' | sed 's/,//g')
    echo $host
    #read
    if [[ "$gw" == "itch" ]] || [[ "$gw" == "fast" ]];
    then
        if [[ "$(echo $port | grep '|')" ]];
        then
            port1=$(echo $port | cut -d '|' -f 1);
            port2=$(echo $port | cut -d '|' -f 2);
            config_string=$gw,$ip,$port1
            echo $config_string >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename
            config_string=$gw,$ip,$port2
            echo $config_string >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename
        else
            config_string=$gw,$ip,$port
            echo $config_string >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename
        fi
    else
        if [[ "$(echo $port | grep '|')" ]]; 
        then 
            port1=$(echo $port | cut -d '|' -f 1); 
            port2=$(echo $port | cut -d '|' -f 2); 
            config_string="$gw,$ip,$port1"
            #config_string="${gw}_${ip}_${port1}"
            config_string=$(echo $config_string | sed 's/\ //g')
            cmd="echo $config_string  >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
            #ssh $host "$cmd"
            echo $config_string
            ssh $host "echo $config_string >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
            config_string="$gw,$ip,$port2"
            #config_string="${gw}_${ip}_${port2}"
            config_string=$(echo $config_string | sed 's/\ //g')
            cmd="echo $config_string  >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
            #ssh $host "$cmd" 
            echo $config_string
            ssh $host "echo $config_string >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
        else
            config_string="$gw,$ip,$port"
            #config_string="${gw}_${ip}_${port}"
            config_string=$(echo $config_string | sed 's/\ //g')
            cmd="echo $config_string  >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
            #ssh $host "$cmd" 
            echo $config_string
            ssh $host "echo $config_string >> ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename" 
        fi
    fi
done
for host in $(echo "$hosts")
do
    finalresult=$(ssh $host "cat ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename | uniq | sed 's/\ //g'") # | sed 's/_/,/g'")
    ssh $host "echo \"$finalresult\" > ~/QA_env_scripts/env_maintenance_scripts/tools/pcap/$result_filename"
done


exit 0
