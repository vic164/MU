#!/bin/bash

script_folder="$(dirname $(readlink -f $0))"
UDP_folder="${script_folder}/UDPProxy_ITCH"


if [[ "$1" ]] 
then
    let "start_port_itch=$1-1"
else
    echo "Usage: ./prepare_udpproxy_itch.sh <first mitch port>"; exit 101
fi
number=0
config="1 2 3 4 5 6 7"
start_all="${UDP_folder}/start_all_itch.sh"
stop_all="${UDP_folder}/stop_all_itch.sh"
machine=$(echo $SSH_CONNECTION | cut -d ' ' -f 3)
echo '#!/bin/bash' >$start_all; echo '#!/bin/bash' >$stop_all;
chmod u+x $start_all; chmod u+x $stop_all;
for number in $config
do
    let "port=${start_port_itch}+$number"
    echo "port: $port"
    cp ${UDP_folder}/config.xml ${UDP_folder}/config${number}.xml
    owner="'MarketDataOut:${number}:1'"

    pip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = 'PRIMARY_MCAST_IP' AND INH_DEF = 'ITCHGateway';
QUIT;
EOQUERY
)
    pport=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = 'PRIMARY_MCAST_PORT_OFFSET' AND INH_DEF = 'ITCHGateway';
QUIT;
EOQUERY
)
    machine=$(echo $machine); pip=$(echo $pip); pport=$(echo $pport);  let "pport=$pport+$S_REG_PORT_NO"
echo "machine_ip: $machine; primary ip: $pip; primary port: $pport"
    conf_file="${UDP_folder}/config${number}.xml"
    sed -i "s@PRIMARY_MCAST_PORT_OFFSET@${pport}@g" $conf_file
    sed -i "s@PRIMARY_MCAST_IP@${pip}@g" $conf_file
    sed -i "s@<port>8080<@<port>${port}<@g" $conf_file
    sed -i "s@<interface>IP<@<interface>${machine}<@g" $conf_file
    ########
    cp ${UDP_folder}/multicastProxy_ITCH.jar ${UDP_folder}/multicastProxy_ITCH${number}.jar
    ########
    cp ${UDP_folder}/start_itch.sh  ${UDP_folder}/start_itch${number}.sh
    sed -i "s@multicastProxy_ITCH.jar@multicastProxy_ITCH${number}.jar@g" ${UDP_folder}/start_itch${number}.sh
    sed -i "s@config.xml@config${number}.xml@g"  ${UDP_folder}/start_itch${number}.sh
    sed -i "s@pid@pid${number}@g"  ${UDP_folder}/start_itch${number}.sh
    ########
    cp ${UDP_folder}/stop_itch.sh ${UDP_folder}/stop_itch${number}.sh
    sed -i "s@multicastProxy_ITCH@multicastProxy_ITCH${number}@g" ${UDP_folder}/stop_itch${number}.sh
    sed -i "s@pid@pid${number}@g" ${UDP_folder}/stop_itch${number}.sh
    echo "${UDP_folder}/start_itch${number}.sh" >>$start_all
    echo "${UDP_folder}/stop_itch${number}.sh" >>$stop_all
done


