#!/bin/bash

script_folder="$(dirname $(readlink -f $0))"

file="${script_folder}/pcap.cfg"
envname=$(whoami)
result="${script_folder}/pcap/pcap_${envname}.cfg"
echo '' >$result
for string in $(cat $file)
do
    gw=$(echo $string | cut -d ',' -f 1)
    ip_num=$(echo $string | cut -d ',' -f 2 | grep -oEe '[0-9]{1,}')
    ip_def="'$(echo $string | cut -d ',' -f 2 | sed "s@_${ip_num}@@g")'"
    port_def="'$(echo $string | cut -d ',' -f 3 | sed "s@_${ip_num}@@g")'"
    case $gw in
        itch ) owner="'MarketDataOut:${ip_num}:1'"; inhdef="'ITCHGateway'";;
        itchrp|itchsn ) owner="'MarketDataOut:${ip_num}'"; inhdef="'ITCHGateway'";;
        fix ) owner="'FixGroup:${ip_num}:1'"; inhdef="'FixGateway'";;
        dc ) owner="'FixGroup:${ip_num}:1'"; inhdef="'DropCopyGateway'";;
        pt ) owner="'PostTrade:${ip_num}:1'"; inhdef="'PostTradeGateway'";;
        nat|natrc ) owner="'Native:1:1:NativeGateway:${ip_num}'"; inhdef="'NativeGateway'";;
        fast ) owner="'MarketDataOut:${ip_num}:1'"; inhdef="'FASTGateway'";;
        fastrp|fastsn ) owner="'MarketDataOut:${ip_num}'"; inhdef="'FASTGateway'";;
        dsgmd ) owner="'DSG:${ip_num}:1:DSGMDGateway:1'"; inhdef="'DSGMDGateway'";;
        dsgom ) owner="'DSG:${ip_num}:1:DSGOMGateway:1'"; inhdef="'DSGOMGateway'";;
        dsgpt ) owner="'DSG:${ip_num}:1:DSGPTGateway:1'"; inhdef="'DSGPTGateway'";;
    esac

    if [[ "$(echo $gw | grep 'nat')" ]];
    then
        ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT IP FROM SG4_HOSTS WHERE HOST like (SELECT HOST FROM SG4_MACHINES WHERE NAME like (SELECT MACHINE FROM SG4_INSTANCES WHERE PROC_DEF = ${inhdef} AND PART_INST_ID = '1' AND proc_inst_id = ${ip_num}));
QUIT;
EOQUERY
)
    elif [[ "$gw" == "itch" || "$gw" == "fast" ]]
    then
        ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = ${ip_def} AND INH_DEF = ${inhdef};
QUIT;
EOQUERY
)
    else
        ip=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT IP FROM SG4_HOSTS WHERE HOST like (SELECT HOST FROM SG4_MACHINES WHERE NAME like (SELECT MACHINE FROM SG4_INSTANCES WHERE PROC_DEF = ${inhdef} AND PART_INST_ID = ${ip_num} AND proc_inst_id = '1'));
QUIT;
EOQUERY
)
    fi
    port=$(sqlplus -s "$SG_DB_STRING" <<EOQUERY
set heading off;
SELECT VALUE FROM SG4_CONFIGS WHERE OWNER = ${owner} AND PARAMETER = ${port_def} AND INH_DEF = ${inhdef};
QUIT;
EOQUERY
)
    if [[ "$(echo $port | grep "no rows selected")" ]]; then echo "ERROR. For $string port has not been found"; continue;fi
    if [[ "$(echo $ip | grep "no rows selected")" ]]; then echo "ERROR. For $string ip has not been found"; continue; fi
    if [[ "$(echo $port | grep "ORA")" ]]; then echo "ERROR. For $string port has not been found"; continue;fi
    if [[ "$(echo $ip | grep "ORA")" ]]; then echo "ERROR. For $string port has not been found"; continue;fi

    if [[ "$(echo $port | grep '|')" ]]; then port1=$(echo $port | cut -d '|' -f 1); port2=$(echo $port | cut -d '|' -f 2); echo $gw,$ip,$port1 >>$result;  echo $gw,$ip,$port2 >>$result; 
    else echo $gw,$ip,$port >>$result; fi
done
finalresult=$(cat $result | uniq | sed 's/\ //g')
echo "$finalresult" >$result

