#!/bin/bash

script_folder="$(dirname $(readlink -f $0))"
ML_folder="${script_folder}/MITCH_Listener"
envname=$(whoami)
csv_cfg_path="${ML_folder}/${envname}_config.csv"
sed -i 's/\ /_/g' $csv_cfg_path

mkdir "${ML_folder}/Merged"

cfg_example_file="${ML_folder}/example.cfg"

script_folder_link=$(echo $ML_folder | sed 's/\//\\\//g' | sed 's/\ /\\\ /g')
row_count=0
for cfg_row in $(cat $csv_cfg_path)
do
    if [ $row_count == 0 ]
    then
        let "row_count+=1"
        continue
    fi
    name_gw=$(echo $cfg_row | cut -d ';' -f 1)
    mlproto=$(echo $cfg_row | cut -d ';' -f 2)
    mdg=$(echo $cfg_row | cut -d ';' -f 3)
    primary_mcast_ip=$(echo $cfg_row | cut -d ';' -f 4)
    primary_port=$(echo $cfg_row | cut -d ';' -f 5)
    mcastinterface=$(echo $cfg_row | cut -d ';' -f 6)

    replay_ip=$(echo $cfg_row | cut -d ';' -f 7)
    replay_port=$(echo $cfg_row | cut -d ';' -f 8)
    replay_usr=$(echo $cfg_row | cut -d ';' -f 9)
    replay_psw=$(echo $cfg_row | cut -d ';' -f 10)

    recovery_ip=$(echo $cfg_row | cut -d ';' -f 11)
    recovery_port=$(echo $cfg_row | cut -d ';' -f 12)
    recovery_usr=$(echo $cfg_row | cut -d ';' -f 13)
    recovery_psw=$(echo $cfg_row | cut -d ';' -f 14)

    # new logs folder
    new_logs_name="logs_${name_gw}"
    mkdir "${ML_folder}/${new_logs_name}"

    # new mitch_listener item
    new_mljar_name="mitch_listener_${name_gw}"
    cp ${ML_folder}/mitch_listener ${ML_folder}/${new_mljar_name}

    # new_gw_config
    new_gw_config_name="${name_gw}_config.cfg"
    new_gw_config="${ML_folder}/${new_gw_config_name}"
    cp $cfg_example_file $new_gw_config
    sed -i "s@logs@${new_logs_name}@g" $new_gw_config
    sed -i "s@MAIN_IP@${mcastinterface}@g" $new_gw_config
    sed -i "s@PRIMARY_MCAST_IP@${primary_mcast_ip}@g" $new_gw_config
    sed -i "s@PRIMARY_MCAST_PORT_OFFSET@${primary_port}@g" $new_gw_config
    sed -i "s@REPLAY_CHANNEL_PORT_OFFSETS@${replay_port}@g" $new_gw_config
    sed -i "s@REPLAY_CHANNEL_IP@${replay_ip}@g" $new_gw_config
    sed -i "s@SNAPSHOT_CHANNEL_IP@${recovery_ip}@g" $new_gw_config
    sed -i "s@SNAPSHOT_CHANNEL_PORT_OFFSETS@${recovery_port}@g" $new_gw_config
    sed -i "s@DEFAULT_USERNAME@${replay_usr}@g" $new_gw_config
    sed -i "s@DEFAULT_LOGIN@${replay_usr}@g" $new_gw_config
    sed -i "s@DEFAULT_PASS@${replay_psw}@g" $new_gw_config
    sed -i "s@APPL_ID@${mdg}@g" $new_gw_config
    sed -i "s@proto\ =\ trm2@proto\ =\ ${mlproto}@g" $new_gw_config
    sed -i "s@SCRIPT_HOME_PATH@${script_folder_link}@g" $new_gw_config
done
chmod -R u+x ${ML_folder};
