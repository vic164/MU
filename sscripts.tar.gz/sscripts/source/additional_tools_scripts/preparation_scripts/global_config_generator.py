#!/usr/bin/env python

import cx_Oracle
import os
import re
import xml.etree.ElementTree as ET
import yaml
import logging

logging.basicConfig(level=logging.WARNING, format=' %(asctime)s - %(levelname)s - %(message)s')

BASE_PORT = int(os.getenv('S_REG_PORT_NO'))
HOME = os.getenv('HOME')
PROXY_PATH = os.path.join(HOME, 'QA_env_scripts/env_maintenance_scripts/tools/UDPProxy_ITCH')
DB_CONN_STRING = os.getenv('SG_DB_STRING')
ENV_NAME = os.getenv('USER').upper()

DSG_PARAMETERS = ['ONLINE_PORT', 'OFFLINE_PORT']
NATIVE_PARAMETERS = ['NATIVE_RT_PORT', 'NATIVE_RECOVERY_PORT']
MITCH_PARAMETERS = ['REPLAY_CHANNEL_PORT_OFFSETS', 'SNAPSHOT_CHANNEL_PORT_OFFSETS']
FIX_PARAMETERS = ['SERVICE_PORTS']
FSB_PARAMETERS = ['PORT']
logging.debug('Starting')


def get_gw_hosts(db_cursor, part_def, proc_def):
    # get machines
    query = """
    select
    PART_DEF, PART_INST_ID, PART_INST_SUB_ID, PROC_DEF, PROC_INST_ID, MACHINE
    from
    SG4_INSTANCES
    where
    PART_DEF = '{partdef}'
    and PROC_DEF = '{procdef}'
    order by PROC_INST_ID
    """.format(partdef=part_def, procdef=proc_def)
    machines = db_cursor.execute(query).fetchall()

    # get hosts
    gw_hosts = {}
    for row in machines:
        gw_name = '_'.join([str(x) for x in row[:-1]])
        machine = row[-1:][0]
        query = """
        select
        HOST
        from
        SG4_MACHINES
        where
        NAME = '{m}'
        """.format(m=machine)
        host = db_cursor.execute(query).fetchone()[0]
        query = """
        select
        IP
        from
        SG4_HOSTS
        where
        HOST = '{h}'
        """.format(h=host)
        gw_hosts[gw_name] = db_cursor.execute(query).fetchone()[0]
    return gw_hosts


parameters_query_template = """
    select
    VALUE
    from
    SG4_CONFIGS
    where
    OWNER = '{gw}'
    and INH_DEF = '{proc_name}'
    and PARAMETER = '{par}'
"""


def get_instance_parameters(db_cursor, part_def, proc_def, parameters):
    gw_hosts = get_gw_hosts(db_cursor, part_def, proc_def)
    config = {}
    for gw_name in gw_hosts.keys():
        for parameter in parameters:
            query = parameters_query_template.format(gw=gw_name.replace('_', ':'), proc_name=proc_def, par=parameter)
            logging.debug(query)
            port = int(db_cursor.execute(query).fetchone()[0]) + BASE_PORT
            config[gw_name] = gw_hosts[gw_name]
            config[gw_name+'_'+parameter] = str(port)
    return config


def get_md_gw_cfg(db_cursor, part_def, proc_def, parameters):
    gw_hosts = get_gw_hosts(db_cursor, part_def, proc_def)
    config = {}
    for gw_name in gw_hosts.keys():
        owner = ':'.join(gw_name.split('_')[:2])
        for parameter in parameters:
            query = parameters_query_template.format(gw=owner, proc_name=proc_def, par=parameter)
            logging.debug(query)
            port = int(db_cursor.execute(query).fetchone()[0]) + BASE_PORT
            config[gw_name] = gw_hosts[gw_name]
            config[gw_name+'_'+parameter] = str(port)
    return config


def get_fix_gw_cfg(db_cursor, part_def, proc_def, parameters):
    gw_hosts = get_gw_hosts(db_cursor, part_def, proc_def)
    config = {}
    for gw_name in gw_hosts.keys():
        owner = ':'.join(gw_name.split('_')[:3])
        for parameter in parameters:
            query = parameters_query_template.format(gw=owner, proc_name=proc_def, par=parameter)
            logging.debug(query)
            ports = db_cursor.execute(query).fetchone()[0].split('|')
            for port in ports:
                logging.debug(port)
                parameter = 'CHANNEL{0}'.format(int(ports.index(port)) + 1)
                port = int(port) + BASE_PORT
                config[gw_name] = gw_hosts[gw_name]
                config[gw_name+'_'+parameter] = str(port)
    return config


def get_fsb_gw_cfg(db_cursor, part_def, proc_def, parameters):
    gw_hosts = get_gw_hosts(db_cursor, part_def, proc_def)
    config = {}
    for gw_name in gw_hosts.keys():
        for parameter in parameters:
            port = int(os.getenv('S_REG_PORT_NO')) - 12
            config[gw_name] = gw_hosts[gw_name]
            config[gw_name+'_'+parameter] = str(port)
    return config


def get_md_rt_cfg():
    config_files = []
    with os.scandir(PROXY_PATH) as root:
        for entry in root:
            if entry.is_file() and re.match(r'config[0-9]{1,}\.xml', entry.name):
                config_files.append(entry.path)
        logging.debug(config_files)
    config = {}
    for config_file in config_files:
        tree = ET.parse(config_file)
        root = tree.getroot()
        serviceID = 'ITCHGateway_{0}'.format(os.path.basename(config_file))
        ip = root.find("./proxy/tcpServer/interface")
        port = root.find("./proxy/tcpServer/port")
        if ip is None or port is None:
            ip = root.find("./proxy/tcpServerCfg/interface")
            port = root.find("./proxy/tcpServerCfg/port")
            serviceID = 'FASTGateway_{0}'.format(os.path.basename(config_file))
        logging.debug(port, ip)
        config[serviceID] = ip.text
        config[serviceID+'_PORT'] = port.text
    return config


if __name__ == '__main__':
    config = {}
    db_conn = cx_Oracle.connect(DB_CONN_STRING)
    db_cursor = db_conn.cursor()
    try:
        config.update(get_md_rt_cfg())
    except Exception as err:
        logging.warning(err)
    config.update(get_fsb_gw_cfg(db_cursor, 'Common', 'FSB', FSB_PARAMETERS))
    config.update(get_fix_gw_cfg(db_cursor, 'FixGroup', 'FixGateway', FIX_PARAMETERS))
    config.update(get_fix_gw_cfg(db_cursor, 'FixGroup', 'DropCopyGateway', FIX_PARAMETERS))
    config.update(get_fix_gw_cfg(db_cursor, 'PostTrade', 'PostTradeGateway', FIX_PARAMETERS))
    config.update(get_md_gw_cfg(db_cursor, 'MarketDataOut', 'ITCHGateway', MITCH_PARAMETERS))
    config.update(get_instance_parameters(db_cursor, 'Native', 'NativeGateway', NATIVE_PARAMETERS))
    config.update(get_instance_parameters(db_cursor, 'DSG', 'DSGMDGateway', DSG_PARAMETERS))
    config.update(get_instance_parameters(db_cursor, 'DSG', 'DSGOMGateway', DSG_PARAMETERS))
    config.update(get_instance_parameters(db_cursor, 'DSG', 'DSGPTGateway', DSG_PARAMETERS))
    db_cursor.close()

    print(yaml.dump({ENV_NAME: config}, default_flow_style=False))

