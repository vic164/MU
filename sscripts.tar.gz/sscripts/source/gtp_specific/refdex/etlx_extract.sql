set echo off;
set feedback off;
set heading off;
set newpage none;
set linesize 1000;
set termout off;
set trimspool on;
set verify off;

spool ETLX-EQ1.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case  TICK_STRUCTURE_ID
when 'TS_EQT' then 'TS_EQT'
when 'TS_CER' then 'TS_CER'
when 'TS_BON' then 'TS_BON'
when 'TS_A' then 'TS_A'
when 'TS_B' then 'TS_B'
when 'TS_C' then 'TS_C'
when 'TS_D' then 'TS_D'
when 'TS_E' then 'TS_E'
when 'TS_F' then 'TS_F'
else TICK_STRUCTURE_ID_TP
end
||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;;00;'||SETTLEMENT_DATE||';'||
       ENDDATE||';'||previous_close||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';;;;;;;;'||POOL_FACTOR||';;;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
end
||';'||
case PRODUCT_NAME 
when 'DGS' then 'DIG' 
when 'FGS' then 'FSS' 
when 'DCF' then 'DSCF' 
when 'FCF' then 'FSCF' 
when 'DBB' then 'DBBN' 
when 'FBB' then 'FBBN' 
when 'DCE' then 'DLNP' 
when 'FCE' then 'FLNP' 
when 'EEQ' then 'IEQ'
end||';'||SECURITY_DESCRIPTION||';'||SYMBOL||';'||E.abt||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
	   TICK_STRUCTURE_ID,
           TRADING_CURRENCY,
           CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   POOL_FACTOR,
	   SYMBOL,
	   SECURITY_DESCRIPTION,
           MDS_MULTICAST_CHANNEL_ID,
	   ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
 	   MARKET_DATA_CHANNEL_ID,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_EQUITY where PRODUCT_NAME = 'EEQ'
) A left join (
	select case  G.TICK_STRUCTURE_ID
when 'TS_EQT' then 'TS_EQT'
when 'TS_CER' then 'TS_CER'
when 'TS_BON' then 'TS_BON'
when 'TS_A' then 'TS_A'
when 'TS_B' then 'TS_B'
when 'TS_C' then 'TS_C'
when 'TS_D' then 'TS_D'
when 'TS_E' then 'TS_E'
when 'TS_F' then 'TS_F'
		else 'TS_EQT'
		end TICK_STRUCTURE_ID_TP, 
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
                --H.NEXT_ENTRY_ID
	from ATSD_TPA_NORMAL G
	--left join
	--ATSD_TEN_SESSION_PARAMETER H
	--on G.session_parameter =  H.table_id
        --where NEXT_ENTRY_ID=2 or NEXT_ENTRY_ID is NULL 
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
	select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
	select instrument_id, sum(bookvalue) as abt from
	(
        	select instrument_id, 1 as bookvalue from atsd_ord_normal
	        union all
        	select instrument_id, 2 as bookvalue from atsd_ord_bulletin
	        union all
        	select instrument_id, 4 as bookvalue from atsd_ord_off_book
	        union all
        	select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
	) F
	group by instrument_id
) E on a.instrument_id = e.instrument_id
;

spool off;

spool ETLX-EQ2.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case TICK_STRUCTURE_ID
when 'TS_EQT' then 'TS_EQT'
when 'TS_CER' then 'TS_CER'
when 'TS_BON' then 'TS_BON'
when 'TS_A' then 'TS_A'
when 'TS_B' then 'TS_B'
when 'TS_C' then 'TS_C'
when 'TS_D' then 'TS_D'
when 'TS_E' then 'TS_E'
when 'TS_F' then 'TS_F'
else TICK_STRUCTURE_ID_TP
end
||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;9;00;'||SETTLEMENT_DATE||';'||
       ENDDATE||';'||previous_close||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';'||UNDERLYING||';;;;;;;;;;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
end
||';'||
case PRODUCT_NAME
when 'DGS' then 'DIG'
when 'FGS' then 'FSS'
when 'DCF' then 'DSCF'
when 'FCF' then 'FSCF'
when 'DBB' then 'DBBN'
when 'FBB' then 'FBBN'
when 'DCE' then 'DLNP'
when 'FCE' then 'FLNP'
when 'EEQ' then 'IEQ'
end||';'||SECURITY_DESCRIPTION||';'||SYMBOL||';'||E.abt||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from (
    select PRODUCT_NAME,
           CUSIP_ISIN,
           LOTSIZE,
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TICK_STRUCTURE_ID,
	   TRADING_CURRENCY,
           CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
           replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   --POOL_FACTOR,
           SYMBOL,
	   SECURITY_DESCRIPTION,
           MDS_MULTICAST_CHANNEL_ID,
	   ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
	   MARKET_DATA_CHANNEL_ID,
	   UNDERLYING,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_DERIVATIVE where PRODUCT_NAME = 'DCE' or PRODUCT_NAME = 'FCE'
) A left join (
        select case  G.TICK_STRUCTURE_ID
when 'TS_EQT' then 'TS_EQT'
when 'TS_CER' then 'TS_CER'
when 'TS_BON' then 'TS_BON'
when 'TS_A' then 'TS_A'
when 'TS_B' then 'TS_B'
when 'TS_C' then 'TS_C'
when 'TS_D' then 'TS_D'
when 'TS_E' then 'TS_E'
when 'TS_F' then 'TS_F'
		else 'TS_CER'
                end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
                --H.NEXT_ENTRY_ID
        from ATSD_TPA_NORMAL G
        --left join
        --ATSD_TEN_SESSION_PARAMETER H
        --on G.session_parameter =  H.table_id
        --where NEXT_ENTRY_ID=2 or NEXT_ENTRY_ID is NULL
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
        select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
        select instrument_id, sum(bookvalue) as abt from
        (
                select instrument_id, 1 as bookvalue from atsd_ord_normal
                union all
                select instrument_id, 2 as bookvalue from atsd_ord_bulletin
                union all
                select instrument_id, 4 as bookvalue from atsd_ord_off_book
                union all
                select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
        ) F
        group by instrument_id
) E on a.instrument_id = e.instrument_id
;

spool off;

spool ETLX-FI.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case  TICK_STRUCTURE_ID
when 'TS_EQT' then 'TS_EQT'
when 'TS_CER' then 'TS_CER'
when 'TS_BON' then 'TS_BON'
when 'TS_A' then 'TS_A'
when 'TS_B' then 'TS_B'
when 'TS_C' then 'TS_C'
when 'TS_D' then 'TS_D'
when 'TS_E' then 'TS_E'
when 'TS_F' then 'TS_F'
else TICK_STRUCTURE_ID_TP
end
||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;;00;'||SETTLEMENT_DATE||';'||
       ENDDATE||';'||previous_close||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';;;;;;;;'||POOL_FACTOR||';'||COUPON||';;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
end
||';'||
case PRODUCT_NAME 
when 'DGS' then 'DIG' 
when 'FGS' then 'FSS' 
when 'DCF' then 'DSCF' 
when 'FCF' then 'FSCF' 
when 'DBB' then 'DBBN' 
when 'FBB' then 'FBBN' 
when 'DCE' then 'DLNP' 
when 'FCE' then 'FLNP' 
when 'EEQ' then 'IEQ' 
end||';'||SECURITY_DESCRIPTION||';;'||E.abt||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TICK_STRUCTURE_ID,
	   TRADING_CURRENCY,
           CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   POOL_FACTOR,
	   COUPON,
	   SYMBOL,
	   SECURITY_DESCRIPTION,
           MDS_MULTICAST_CHANNEL_ID,
	   ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
	   MARKET_DATA_CHANNEL_ID,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_BOND where PRODUCT_NAME in ('DGS','FGS','DBB','FBB','DCF','FCF')
) A left join (
        select case  G.TICK_STRUCTURE_ID
when 'TS_EQT' then 'TS_EQT'
when 'TS_CER' then 'TS_CER'
when 'TS_BON' then 'TS_BON'
when 'TS_A' then 'TS_A'
when 'TS_B' then 'TS_B'
when 'TS_C' then 'TS_C'
when 'TS_D' then 'TS_D'
when 'TS_E' then 'TS_E'
when 'TS_F' then 'TS_F'
		else 'TS_BON'
                end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
                --H.NEXT_ENTRY_ID
        from ATSD_TPA_NORMAL G
        --left join
        --ATSD_TEN_SESSION_PARAMETER H
        --on G.session_parameter =  H.table_id
        --where NEXT_ENTRY_ID=2 or NEXT_ENTRY_ID is NULL
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
        select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
        select instrument_id, sum(bookvalue) as abt from
        (
                select instrument_id, 1 as bookvalue from atsd_ord_normal
                union all
                select instrument_id, 2 as bookvalue from atsd_ord_bulletin
                union all
                select instrument_id, 4 as bookvalue from atsd_ord_off_book
                union all
                select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
        ) F
        group by instrument_id
) E on a.instrument_id = e.instrument_id
;

spool off;

exit;

