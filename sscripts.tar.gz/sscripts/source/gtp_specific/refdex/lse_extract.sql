set echo off;
set feedback off;
set heading off;
set newpage none;
set linesize 1000;
set termout off;
set trimspool on;
set verify off;
spool LSE.csv;

select A.INSTRUMENT_ID||';'||PRODUCT_NAME||';'||CUSIP_ISIN||';'||INSTRUMENT_STATUS||';'||LSEG_CLEARING_TYPE||';'||EXCHANGE_MARKET_SIZE||';'||LOTSIZE||';'||C.FRONT_END_DISPLAY_NAME||';'||LSEG_SEDOL||';'||TRADING_CURRENCY||';'||SYMBOL||';'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;;'||
case TICK_STRUCTURE_ID
when 'TM_1' then 'TM_1'
when 'TM_2' then 'TM_2'
when 'TM_3' then 'TM_3'
when 'TM_4' then 'TM_4'
when 'TM_5' then 'TM_5'
when 'TM_6' then 'TM_6'
when 'TM_7' then 'TM_7'
when 'TM_8' then 'TM_8'
when 'TM_9' then 'TM_9'
when 'TM_10' then 'TM_10'
when 'TM_11' then 'TM_11'
when 'TM_12' then 'TM_12'
when 'TM_13' then 'TM_13'
when 'TM_14' then 'TM_14'
when 'TM_15' then 'TM_15'
when 'TM_16' then 'TM_16'
when 'TM_17' then 'TM_17'
when 'TM_18' then 'TM_18'
when 'TM_19' then 'TM_19'
when 'TM_20' then 'TM_20'
when 'TM_21' then 'TM_21'
when 'TM_22' then 'TM_22'
when 'TM_23' then 'TM_23'
when 'TM_24' then 'TM_24'
when 'TM_25' then 'TM_25'
when 'TM_26' then 'TM_26'
when 'TM_27' then 'TM_27'
when 'TM_28' then 'TM_28'
when 'TM_29' then 'TM_29'
when 'TM_30' then 'TM_30'
when 'TM_31' then 'TM_31'
when 'TM_32' then 'TM_32'
when 'TM_33' then 'TM_33'
when 'TM_34' then 'TM_34'
when 'TM_35' then 'TM_35'
when 'TM_36' then 'TM_36'
when 'TM_37' then 'TM_37'
when 'TM_38' then 'TM_38'
when 'TM_39' then 'TM_39'
when 'TM_40' then 'TM_40'
when 'TM_41' then 'TM_41'
when 'TM_42' then 'TM_42'
when 'TM_43' then 'TM_43'
when 'TM_44' then 'TM_44'
when 'TM_45' then 'TM_45'
when 'TM_46' then 'TM_46'
when 'TM_47' then 'TM_47'
when 'TM_48' then 'TM_48'
when 'TM_49' then 'TM_49'
when 'TM_50' then 'TM_50'
when 'TM_51' then 'TM_51'
when 'TM_52' then 'TM_52'
when 'TM_53' then 'TM_53'
when 'TM_54' then 'TM_54'
when 'TM_55' then 'TM_55'
when 'TM_56' then 'TM_56'
when 'TM_57' then 'TM_57'
when 'TM_58' then 'TM_58'
when 'TM_59' then 'TM_59'
when 'TM_60' then 'TM_60'
when 'TM_61' then 'TM_61'
when 'TM_62' then 'TM_62'
when 'TM_63' then 'TM_63'
when 'TM_64' then 'TM_64'
when 'TM_65' then 'TM_65'
when 'TM_66' then 'TM_66'
when 'TM_67' then 'TM_67'
when 'TM_68' then 'TM_68'
when 'TM_69' then 'TM_69'
when 'TM_70' then 'TM_70'
when 'TM_71' then 'TM_71'
when 'TM_72' then 'TM_72'
when 'TM_73' then 'TM_73'
when 'TM_74' then 'TM_74'
when 'TM_75' then 'TM_75'
when 'TM_76' then 'TM_76'
when 'TM_77' then 'TM_77'
when 'TM_78' then 'TM_78'
when 'TM_79' then 'TM_79'
when 'TM_80' then 'TM_80'
when 'TM_81' then 'TM_81'
when 'TM_82' then 'TM_82'
when 'TM_83' then 'TM_83'
when 'TM_84' then 'TM_84'
when 'TM_85' then 'TM_85'
when 'TM_86' then 'TM_86'
when 'TM_87' then 'TM_87'
when 'TM_88' then 'TM_88'
when 'TM_89' then 'TM_89'
when 'TM_90' then 'TM_90'
when 'TM_91' then 'TM_91'
when 'TM_92' then 'TM_92'
when 'TM_93' then 'TM_93'
when 'TM_94' then 'TM_94'
when 'TM_95' then 'TM_95'
when 'TM_96' then 'TM_96'
when 'TM_97' then 'TM_97'
when 'TM_98' then 'TM_98'
when 'TM_99' then 'TM_99'
else B.TICK_STRUCTURE_ID_TP
end||';;'||
(FLOOR((LSEG_MIN_DISCLOSED_SIZE_EMS / 100) * EXCHANGE_MARKET_SIZE))||--B.LSEG_MIN_DISCLOSED_SIZE_EMS||
/*';'||B.DYNAMIC_CB_PERCENTAGE||';'||B.STATIC_CB_PERCENTAGE||*/';;;'||previous_close||';;'||to_char(sysdate,'yyyymmdd')||';'||
    case PRODUCT_NAME --segment
when 'AIM' then 'AIM'
when 'AIMI' then 'AIMT'
when 'AMSM' then 'AF25'
when 'ASQ1' then 'AMQ1'
when 'ASQ2' then 'AMQ2'
when 'ASX1' then 'AIMP'
when 'ASX2' then 'AIMS'
when 'ASXN' then 'AIMN'
when 'CNVE' then 'CNVL'
when 'CRNR' then 'EICR'
when 'CRTR' then 'UICR'
when 'CWNR' then 'EICW'
when 'CWNU' then 'EICU'
when 'CWTR' then 'UICW'
when 'CWTU' then 'UICU'
when 'EQS' then 'ATQS'
when 'ETC2' then 'ECLM'
when 'ETCS' then 'ECL'
when 'ETCU' then 'EMLL'
when 'ETF2' then 'EFEN'
when 'ETFS' then 'EOTC'
when 'ETFU' then 'EFCA'
when 'GILT' then 'GLTL'
when 'IBSG' then 'SGX1'
when 'INCP' then 'INC1'
when 'INSD' then 'CAPP'
when 'IOBE' then 'INHE'
when 'IOBU' then 'INLN'
when 'ITR' then 'EUTR'
when 'LVSD' then 'CVWT'
when 'MISC' then 'ADRN'
when 'MISL' then 'ADPL'
when 'ODTT' then 'ODTT'
when 'PSNR' then 'EIDP'
when 'PSTR' then 'UIDP'
when 'SET0' then 'FE00'
when 'SET1' then 'FE10'
when 'SET2' then 'IL10'
when 'SET3' then 'OL10'
when 'SFM1' then 'SFML'
when 'SFM2' then 'SFQQ'
when 'SFM3' then 'SFNC'
when 'SFM4' then 'SFXN'
when 'SSMM' then 'SSC1'
when 'SSMU' then 'AIMF'
when 'SSQ3' then 'SQQ3'
when 'SSX3' then 'SQCL'
when 'SSX4' then 'ASTD'
when 'STBS' then 'SBDL'
when 'STMM' then '250F'
when 'TEST' then 'DOTS'
when 'UKCP' then 'UKC1'
when 'UKGT' then 'UKG1'
when 'WQUO' then 'WEOD'
when 'EUET' then 'UET1'
when 'IECR' then 'IETF'
when 'SSQ3' then 'SQS3'
when 'HGS1' then 'HG10'
when 'HGS2' then 'HGQ1'
when 'HGS3' then 'HGNQ'
when 'RCNT' then 'CRDQ'
when 'EXCQ' then 'INRQ'
when 'EXPQ' then 'PDCQ'
when 'REOD' then 'CRDE'
when 'EXED' then 'INRE'
when 'EXPE' then 'PDCE'
end||';'||MDS_MULTICAST_CHANNEL_ID||';;'||ACTIVE_LOAD_ID||';'||SYMBOL||';'||SECURITY_DESCRIPTION||';'||MARKET_DATA_CHANNEL_ID||';'||E.abt||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from (
        select
                INSTRUMENT_ID,
                PRODUCT_NAME,
                CUSIP_ISIN,
                INSTRUMENT_STATUS,
                LSEG_CLEARING_TYPE,
                EXCHANGE_MARKET_SIZE,
                LOTSIZE,
                SECURITY_TYPE,
                LSEG_SEDOL,
                TRADING_CURRENCY,
                SYMBOL,
                LSEG_MAX_SPREAD_PERCENTAGE,
                substr(CUSIP_ISIN, 1, 2) as COUNTRY,
                TICK_STRUCTURE_ID,
                SECURITY_DESCRIPTION,
                MDS_MULTICAST_CHANNEL_ID,
                ACTIVE_LOAD_ID,
                TRADING_PARAMETER,
                MARKET_DATA_CHANNEL_ID,
                ALTERNATE_SECURITY_TYPE,
                LSEG_PRICE_NOTATION
 from ATSD_INS_EQUITY
) A left join (
        select case G.TICK_STRUCTURE_ID
when 'TM_1' then 'TM_1'
when 'TM_2' then 'TM_2'
when 'TM_3' then 'TM_3'
when 'TM_4' then 'TM_4'
when 'TM_5' then 'TM_5'
when 'TM_6' then 'TM_6'
when 'TM_7' then 'TM_7'
when 'TM_8' then 'TM_8'
when 'TM_9' then 'TM_9'
when 'TM_10' then 'TM_10'
when 'TM_11' then 'TM_11'
when 'TM_12' then 'TM_12'
when 'TM_13' then 'TM_13'
when 'TM_14' then 'TM_14'
when 'TM_15' then 'TM_15'
when 'TM_16' then 'TM_16'
when 'TM_17' then 'TM_17'
when 'TM_18' then 'TM_18'
when 'TM_19' then 'TM_19'
when 'TM_20' then 'TM_20'
when 'TM_21' then 'TM_21'
when 'TM_22' then 'TM_22'
when 'TM_23' then 'TM_23'
when 'TM_24' then 'TM_24'
when 'TM_25' then 'TM_25'
when 'TM_26' then 'TM_26'
when 'TM_27' then 'TM_27'
when 'TM_28' then 'TM_28'
when 'TM_29' then 'TM_29'
when 'TM_30' then 'TM_30'
when 'TM_31' then 'TM_31'
when 'TM_32' then 'TM_32'
when 'TM_33' then 'TM_33'
when 'TM_34' then 'TM_34'
when 'TM_35' then 'TM_35'
when 'TM_36' then 'TM_36'
when 'TM_37' then 'TM_37'
when 'TM_38' then 'TM_38'
when 'TM_39' then 'TM_39'
when 'TM_40' then 'TM_40'
when 'TM_41' then 'TM_41'
when 'TM_42' then 'TM_42'
when 'TM_43' then 'TM_43'
when 'TM_44' then 'TM_44'
when 'TM_45' then 'TM_45'
when 'TM_46' then 'TM_46'
when 'TM_47' then 'TM_47'
when 'TM_48' then 'TM_48'
when 'TM_49' then 'TM_49'
when 'TM_50' then 'TM_50'
when 'TM_51' then 'TM_51'
when 'TM_52' then 'TM_52'
when 'TM_53' then 'TM_53'
when 'TM_54' then 'TM_54'
when 'TM_55' then 'TM_55'
when 'TM_56' then 'TM_56'
when 'TM_57' then 'TM_57'
when 'TM_58' then 'TM_58'
when 'TM_59' then 'TM_59'
when 'TM_60' then 'TM_60'
when 'TM_61' then 'TM_61'
when 'TM_62' then 'TM_62'
when 'TM_63' then 'TM_63'
when 'TM_64' then 'TM_64'
when 'TM_65' then 'TM_65'
when 'TM_66' then 'TM_66'
when 'TM_67' then 'TM_67'
when 'TM_68' then 'TM_68'
when 'TM_69' then 'TM_69'
when 'TM_70' then 'TM_70'
when 'TM_71' then 'TM_71'
when 'TM_72' then 'TM_72'
when 'TM_73' then 'TM_73'
when 'TM_74' then 'TM_74'
when 'TM_75' then 'TM_75'
when 'TM_76' then 'TM_76'
when 'TM_77' then 'TM_77'
when 'TM_78' then 'TM_78'
when 'TM_79' then 'TM_79'
when 'TM_80' then 'TM_80'
when 'TM_81' then 'TM_81'
when 'TM_82' then 'TM_82'
when 'TM_83' then 'TM_83'
when 'TM_84' then 'TM_84'
when 'TM_85' then 'TM_85'
when 'TM_86' then 'TM_86'
when 'TM_87' then 'TM_87'
when 'TM_88' then 'TM_88'
when 'TM_89' then 'TM_89'
when 'TM_90' then 'TM_90'
when 'TM_91' then 'TM_91'
when 'TM_92' then 'TM_92'
when 'TM_93' then 'TM_93'
when 'TM_94' then 'TM_94'
when 'TM_95' then 'TM_95'
when 'TM_96' then 'TM_96'
when 'TM_97' then 'TM_97'
when 'TM_98' then 'TM_98'
when 'TM_99' then 'TM_99'
		else 'TM_1'
		end TICK_STRUCTURE_ID_TP,
                G.LSEG_MIN_DISCLOSED_SIZE_EMS,
                G.OBJECT_ID 
                --H.STATIC_CB_PERCENTAGE,
                --H.DYNAMIC_CB_PERCENTAGE
                --H.NEXT_ENTRY_ID
        from ATSD_TPA_NORMAL G
       --left join
        --ATSD_TEN_SESSION_PARAMETER H
        --on G.session_parameter =  H.table_id
        --where NEXT_ENTRY_ID=2 or NEXT_ENTRY_ID is NULL
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
        select
              FRONT_END_DISPLAY_NAME,
              CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
) C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
        select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
        select instrument_id, sum(bookvalue) as abt from
        (
                select instrument_id, 1 as bookvalue from atsd_ord_normal
                union all
                select instrument_id, 2 as bookvalue from atsd_ord_bulletin
                union all
                select instrument_id, 4 as bookvalue from atsd_ord_off_book
                union all
                select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
        ) F
        group by instrument_id
) E on a.instrument_id = e.instrument_id
;

spool off;
exit;


