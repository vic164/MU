set echo off;
set feedback off;
set heading off;
set newpage none;
set linesize 1000;
set termout off;
set trimspool on;
set verify off;

spool TQ.csv;

create or replace view TQ_DB1
AS

select
    substr(A.INSTRUMENT_ID,0,length(A.INSTRUMENT_ID) - 2)||';'|| -- INSTRUMENT_ID||';'||>
    PRODUCT_NAME||';'|| -- SEGMENT_CODE
    CUSIP_ISIN||';'||
    INSTRUMENT_STATUS||';'||
    LSEG_CLEARING_TYPE||';'||
    LOTSIZE||';'||
    case C.DISPLAY_NAME -- SECURITY_TYPE
when 'TQ_RT' then 'RT'
when 'TQ_TF' then 'TF'
when 'TQ_DR' then 'DR'
when 'TQ_CU' then 'CU'
when 'TQ_EQ' then 'EQ'
when 'TQ_CO' then 'CO'
end||';'||
    TRADING_CURRENCY||';'||
    COUNTRY_OF_REGISTER||';'||
    case TICK_STRUCTURE_ID
when 'Dark' then 'Dark'
when 'ETF_GBP' then 'ETF_GBP'
when 'ETF_GBX' then 'ETF_GBX'
when 'ETF_USD' then 'ETF_USD'
when 'EUROZONE' then 'EUROZONE'
when 'Equity' then 'Equity'
when 'FESE1' then 'FESE1'
when 'FESE2' then 'FESE2'
when 'FESE2B' then 'FESE2B'
when 'FESE3' then 'FESE3'
when 'FESE4' then 'FESE4'
when 'MTAA_1' then 'MTAA_1'
when 'MTAA_ETF' then 'MTAA_ETF'
when 'PX' then 'PX'
when 'TEST' then 'TEST'
when 'T_0.0001' then 'T_0.0001'
when 'T_0.0005' then 'T_0.0005'
when 'T_0.001' then 'T_0.001'
when 'T_0.0025' then 'T_0.0025'
when 'T_0.005' then 'T_0.005'
when 'T_0.01' then 'T_0.01'
when 'T_0.025' then 'T_0.025'
when 'T_0.05' then 'T_0.05'
when 'T_0.1' then 'T_0.1'
when 'T_0.25' then 'T_0.25'
when 'T_1' then 'T_1'
when 'T_5' then 'T_5'
when 'XBUD_1' then 'XBUD_1'
when 'XCSE_1' then 'XCSE_1'
when 'XETR_ETF' then 'XETR_ETF'
when 'XETR_ETF2' then 'XETR_ETF2'
when 'XHEL_1' then 'XHEL_1'
when 'XLON_1' then 'XLON_1'
when 'XLON_2' then 'XLON_2'
when 'XMCE_1' then 'XMCE_1'
when 'XOSL_1' then 'XOSL_1'
when 'XOSL_ETF' then 'XOSL_ETF'
when 'XSTO_1' then 'XSTO_1'
when 'XSTO_ETF' then 'XSTO_ETF'
when 'XSWX_1' then 'XSWX_1'
when 'XSWX_ETF' then 'XSWX_ETF'
when 'XWAR_1' then 'XWAR_1'
when 'US_1' then 'US_1'
else B.TICK_STRUCTURE_ID_TP
end||';'||
    MINIMUM_DISCLOSED_SIZE||';'|| --LSEG_MINIMUM_DISCLOSED_VALUE
    'TEST'||';'|| -- SECTOR
    MDS_MULTICAST_CHANNEL_ID||';'||
    ''||';'|| -- ACTION
    ACTIVE_LOAD_ID||';'||
    SECURITY_DESCRIPTION||';'||
    MARKET_DATA_CHANNEL_ID||';'||
    D.FRONT_END_DISPLAY_NAME||';'|| -- TARGET_BOOK_TYPE
    F.abt||';'||
    ALTERNATE_SECURITY_TYPE||';'||
    LSEG_PRICE_NOTATION
    from (
    select
        INSTRUMENT_ID,
        PRODUCT_NAME,
        CUSIP_ISIN,
        INSTRUMENT_STATUS,
        LSEG_CLEARING_TYPE,
        LOTSIZE,
        SECURITY_TYPE,
        TRADING_CURRENCY,
        substr(PRODUCT_NAME, 1, 2) as COUNTRY_OF_REGISTER,
	TICK_STRUCTURE_ID,
        MDS_MULTICAST_CHANNEL_ID,
        ACTIVE_LOAD_ID,
        SECURITY_DESCRIPTION,
        MARKET_DATA_CHANNEL_ID,
        TRADING_PARAMETER,
        LSEG_TARGET_BOOK,
        ALTERNATE_SECURITY_TYPE,
        LSEG_PRICE_NOTATION
        from ATSD_INS_EQUITY
) A left join (
        select case G.TICK_STRUCTURE_ID
when 'Dark' then 'Dark'
when 'ETF_GBP' then 'ETF_GBP'
when 'ETF_GBX' then 'ETF_GBX'
when 'ETF_USD' then 'ETF_USD'
when 'EUROZONE' then 'EUROZONE'
when 'Equity' then 'Equity'
when 'FESE1' then 'FESE1'
when 'FESE2' then 'FESE2'
when 'FESE2B' then 'FESE2B'
when 'FESE3' then 'FESE3'
when 'FESE4' then 'FESE4'
when 'MTAA_1' then 'MTAA_1'
when 'MTAA_ETF' then 'MTAA_ETF'
when 'PX' then 'PX'
when 'TEST' then 'TEST'
when 'T_0.0001' then 'T_0.0001'
when 'T_0.0005' then 'T_0.0005'
when 'T_0.001' then 'T_0.001'
when 'T_0.0025' then 'T_0.0025'
when 'T_0.005' then 'T_0.005'
when 'T_0.01' then 'T_0.01'
when 'T_0.025' then 'T_0.025'
when 'T_0.05' then 'T_0.05'
when 'T_0.1' then 'T_0.1'
when 'T_0.25' then 'T_0.25'
when 'T_1' then 'T_1'
when 'T_5' then 'T_5'
when 'XBUD_1' then 'XBUD_1'
when 'XCSE_1' then 'XCSE_1'
when 'XETR_ETF' then 'XETR_ETF'
when 'XETR_ETF2' then 'XETR_ETF2'
when 'XHEL_1' then 'XHEL_1'
when 'XLON_1' then 'XLON_1'
when 'XLON_2' then 'XLON_2'
when 'XMCE_1' then 'XMCE_1'
when 'XOSL_1' then 'XOSL_1'
when 'XOSL_ETF' then 'XOSL_ETF'
when 'XSTO_1' then 'XSTO_1'
when 'XSTO_ETF' then 'XSTO_ETF'
when 'XSWX_1' then 'XSWX_1'
when 'XSWX_ETF' then 'XSWX_ETF'
when 'XWAR_1' then 'XWAR_1'
when 'US_1' then 'US_1'
        else 'T_1'
	end TICK_STRUCTURE_ID_TP,
        OBJECT_ID, MINIMUM_DISCLOSED_SIZE from ((select 0 AS MINIMUM_DISCLOSED_SIZE, TICK_STRUCTURE_ID, OBJECT_ID from ATSD_TPA_DARK) union ALL (select MINIMUM_DISCLOSED_SIZE, TICK_STRUCTURE_ID, OBJECT_ID from ATSD_TPA_NORMAL)) G
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
	select
              DISPLAY_NAME,
              CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
) C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
        select
              DISPLAY_NAME,
              FRONT_END_DISPLAY_NAME,
              CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'LSEG_TARGET_BOOK' and (FRONT_END_DISPLAY_NAME = 'M' or FRONT_END_DISPLAY_NAME = 'A' or FRONT_END_DISPLAY_NAME = 'B'  or FRONT_END_DISPLAY_NAME = 'I' or FRONT_END_DISPLAY_NAME = 'EI' or FRONT_END_DISPLAY_NAME = 'EA' or FRONT_END_DISPLAY_NAME = 'EM')
) D on A.LSEG_TARGET_BOOK = D.CONSTANT_VALUE left join (
        select  instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) E on a.instrument_id = e.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
        select instrument_id, sum(bookvalue) as abt from
        (
                select instrument_id, 1 as bookvalue from atsd_ord_normal
                union all
                select instrument_id, 2 as bookvalue from atsd_ord_bulletin
                union all
                select instrument_id, 4 as bookvalue from atsd_ord_off_book
                union all
                select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
        ) F
        group by instrument_id
) F on a.instrument_id = f.instrument_id
;

--delete from TQ_DB1 where FRONT_END_DISPLAY_NAME = 'I';
select FRONT_END_DISPLAY_NAME from TQ_DB1

spool off;
exit;
