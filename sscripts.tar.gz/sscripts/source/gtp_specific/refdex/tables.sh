#!/bin/bash

DB_STRING=/@tnp_qa_pdc_08_tnpqa08ats

sqlplus -S -L $DB_STRING >> ./table.txt << endSQL
SET SPACE 0;
SET PAGESIZE 0;
SET linesize 230;
SET ECHO OFF;
SET FEEDBACK OFF;
SET HEADING OFF;
select * from all_tables;
exit;
endSQL
