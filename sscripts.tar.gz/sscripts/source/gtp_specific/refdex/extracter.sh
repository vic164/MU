#!/bin/bash

sqlplus /@tnp_qa_pdc_02_tnpqa02ats @tq_extract.sql

#cat ./TQ_RC.csv | while read sst_line
#        do
#		correcter_symbol=$(echo $sst_line | grep -oEe '[A-Za-z0-9_-;:](1,)')
#                sym=$(echo $correcter_symbol | cut -d ';' -f 1) # | grep -oEe '[A-Za-z0-9_-:](1,)')
#                str=$(echo $correcter_symbol) # | grep -oEe '[A-Za-z0-9_-:](1,)')
#                sed -i "s/.*${sym}.*/${str}/" ./TQ.csv
#        done < <(cat ./TQ_RC.csv)

cat ./TQ_RC.csv | while read sst_line
        do
		book=$(echo $sst_line | cut -d ';' -f 18)
                sym=$(echo $sst_line | cut -d ';' -f 1) # | grep -oEe '[A-Za-z0-9_-:](1,)')
                str=$(echo $sst_line | grep -oEe '[A-Za-z0-9_-;.,()&%+/ '\'' ]{1,}')
                #echo "str: $str"
		sed -i "s@.*${sym};.*;$book;.*@${str}@" ./TQ.csv
		#echo 'sym='$sym
		#echo 'book='$book
		#echo 'str='$str
		sed -i "s@_;@;@" ./TQ.csv
        done < <(cat ./TQ_RC.csv)

#scp TQ.csv gtp-s@10.61.192.50:~/mdmsdata/

#scp TQ.csv gtp2-s@10.61.192.50:~/mdmsdata/

