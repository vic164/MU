set echo off;
set feedback off;
set heading off;
set newpage none;
set linesize 1000;
set termout off;
set trimspool on;
set verify off;

spool BIT-MTA.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
else B.TICK_STRUCTURE_ID_TP
end||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;;00;'||SETTLEMENT_DATE||';'||ENDDATE||';'||previous_close||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';;;;;;;;0'||POOL_FACTOR||';;;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
when 6 then 'D'
when 7 then 'D'
when 8 then 'E'
when 9 then 'E'
when 10 then 'F'
when 11 then 'F'
end
||';'||
case PRODUCT_NAME 
when 'ATF' then 'ATFA' 
when 'DMO' then 'ICC' 
when 'EMO' then 'EVC' 
when 'ETC' then 'ETCA' 
when 'ETF' then 'ETFA' 
when 'MM1' then 'MTI' 
when 'UTF' then 'UTFA' 
when 'SD' then 'ILC' 
when 'SDQ' then 'ILCQ' 
when 'MA1' then 'AI1' 
when 'MA2' then 'AI2' 
when 'MA3' then 'AIUR' 
when 'MB1' then 'I1S' 
when 'MB2' then 'I2S' 
when 'MB3' then 'I3U' 
when 'OP1' then 'TOA' 
when 'UMO' then 'UDC' 
when 'MV1' then 'IM1' 
when 'MV2' then 'IM2' 
when 'MV3' then 'IM3U' 
when 'TMM1' then 'TMTI' 
when 'OP2' then 'TOAM' 
when 'TAH' then 'TAH' 
when 'MFD' then 'MFD' 
end||';'||SYMBOL||';'||SECURITY_DESCRIPTION||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||E.abt||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TRADING_CURRENCY,
           --CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   TICK_STRUCTURE_ID,
	   replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   SYMBOL,
	   POOL_FACTOR,
           MDS_MULTICAST_CHANNEL_ID,
           ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
	   SECURITY_DESCRIPTION,
	   MARKET_DATA_CHANNEL_ID,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_EQUITY where (market_id='MTA' or market_id='TAH' or market_id='OPA') 
) A left join (
	select case G.TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
		else 'TS_01'
		end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
                --H.NEXT_ENTRY_ID
	from ATSD_TPA_NORMAL G
	--left join
	--ATSD_TEN_SESSION_PARAMETER H
	--on G.session_parameter =  H.table_id
        --where NEXT_ENTRY_ID=2 or NEXT_ENTRY_ID is NULL 
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
	select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
	select instrument_id, sum(bookvalue) as abt from
	(
        	select instrument_id, 1 as bookvalue from atsd_ord_normal
	        union all
        	select instrument_id, 2 as bookvalue from atsd_ord_bulletin
	        union all
        	select instrument_id, 4 as bookvalue from atsd_ord_off_book
	        union all
        	select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
	) F
	group by instrument_id
) E on a.instrument_id = e.instrument_id
;

spool off;

spool BIT-ETF.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
else TICK_STRUCTURE_ID_TP
end||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;;00;'||SETTLEMENT_DATE||';'||ENDDATE||';'||CLOSINGPRICE||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';;;;;;;;0'||POOL_FACTOR||';;;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
when 6 then 'D'
when 7 then 'D'
when 8 then 'E'
when 9 then 'E'
when 10 then 'F'
when 11 then 'F'
end
||';'||
case PRODUCT_NAME 
when 'ATF' then 'ATFA' 
when 'DMO' then 'ICC' 
when 'EMO' then 'EVC' 
when 'ETC' then 'ETCA' 
when 'ETF' then 'ETFA' 
when 'MM1' then 'MTI' 
when 'UTF' then 'UTFA' 
when 'SD' then 'ILC' 
when 'SDQ' then 'ILCQ' 
when 'MA1' then 'AI1' 
when 'MA2' then 'AI2' 
when 'MA3' then 'AIUR' 
when 'MB1' then 'I1S' 
when 'MB2' then 'I2S' 
when 'MB3' then 'I3U' 
when 'OP1' then 'TOA' 
when 'UMO' then 'UDC' 
when 'MV1' then 'IM1' 
when 'MV2' then 'IM2' 
when 'MV3' then 'IM3U' 
when 'TMM1' then 'TMTI' 
when 'OP2' then 'TOAM' 
when 'TAH' then 'TAH' 
when 'MFD' then 'MFD' 
end||';'||SYMBOL||';'||SECURITY_DESCRIPTION||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||E.abt||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TRADING_CURRENCY,
           CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   TICK_STRUCTURE_ID,
	   replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
 	   SYMBOL,
           MDS_MULTICAST_CHANNEL_ID,
	   POOL_FACTOR,
           ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
	   SECURITY_DESCRIPTION,
	   MARKET_DATA_CHANNEL_ID,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_EQUITY where market_id='ETFP'
) A left join (
	select case G.TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
		else 'TS_01'
		end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
	from ATSD_TPA_NORMAL G
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
	select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
	select instrument_id, sum(bookvalue) as abt from
	(
        	select instrument_id, 1 as bookvalue from atsd_ord_normal
	        union all
        	select instrument_id, 2 as bookvalue from atsd_ord_bulletin
	        union all
        	select instrument_id, 4 as bookvalue from atsd_ord_off_book
	        union all
        	select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
	) F
	group by instrument_id
) E on a.instrument_id = e.instrument_id
;


spool off;

spool BIT-TAH.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
else TICK_STRUCTURE_ID_TP
end||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;;00;'||SETTLEMENT_DATE||';'||ENDDATE||';'||previous_close||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';;;;;;;;0'||POOL_FACTOR||';;;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
when 6 then 'D'
when 7 then 'D'
when 8 then 'E'
when 9 then 'E'
when 10 then 'F'
when 11 then 'F'
end
||';'||
case PRODUCT_NAME 
when 'ATF' then 'ATFA' 
when 'DMO' then 'ICC' 
when 'EMO' then 'EVC' 
when 'ETC' then 'ETCA' 
when 'ETF' then 'ETFA' 
when 'MM1' then 'MTI' 
when 'UTF' then 'UTFA' 
when 'SD' then 'ILC' 
when 'SDQ' then 'ILCQ' 
when 'MA1' then 'AI1' 
when 'MA2' then 'AI2' 
when 'MA3' then 'AIUR' 
when 'MB1' then 'I1S' 
when 'MB2' then 'I2S' 
when 'MB3' then 'I3U' 
when 'OP1' then 'TOA' 
when 'UMO' then 'UDC' 
when 'MV1' then 'IM1' 
when 'MV2' then 'IM2' 
when 'MV3' then 'IM3U' 
when 'TMM1' then 'TMTI' 
when 'OP2' then 'TOAM' 
when 'TAH' then 'TAH' 
when 'MFD' then 'MFD' 
end||';'||SYMBOL||';'||SECURITY_DESCRIPTION||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||E.abt||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TRADING_CURRENCY,
           --CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   TICK_STRUCTURE_ID,
	   replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   POOL_FACTOR,
	   SYMBOL,
           MDS_MULTICAST_CHANNEL_ID,
           ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
	   SECURITY_DESCRIPTION,
	   MARKET_DATA_CHANNEL_ID,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_EQUITY where (market_id='TAH' or market_id='MTA')
) A left join (
	select case G.TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
                else 'TS_01'
                end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
	from ATSD_TPA_NORMAL G
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
	select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
	select instrument_id, sum(bookvalue) as abt from
	(
        	select instrument_id, 1 as bookvalue from atsd_ord_normal
	        union all
        	select instrument_id, 2 as bookvalue from atsd_ord_bulletin
	        union all
        	select instrument_id, 4 as bookvalue from atsd_ord_off_book
	        union all
        	select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
	) F
	group by instrument_id
) E on a.instrument_id = e.instrument_id
;


spool off;

spool BIT-FI.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
else TICK_STRUCTURE_ID_TP
end||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;;00;'||SETTLEMENT_DATE||';'||ENDDATE||';'||previous_close||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';;;;;;;;'/*||MATURITY_DAY||';'*/||POOL_FACTOR||';'||COUPON||';;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
when 6 then 'D'
when 7 then 'D'
when 8 then 'E'
when 9 then 'E'
when 10 then 'F'
when 11 then 'F'
end
||';'||
case PRODUCT_NAME 
when 'ATF' then 'ATFA' 
when 'DMO' then 'ICC' 
when 'EMO' then 'EVC' 
when 'ETC' then 'ETCA' 
when 'ETF' then 'ETFA' 
when 'MM1' then 'MTI' 
when 'UTF' then 'UTFA' 
when 'SD' then 'ILC' 
when 'SDQ' then 'ILCQ' 
when 'MA1' then 'AI1' 
when 'MA2' then 'AI2' 
when 'MA3' then 'AIUR' 
when 'MB1' then 'I1S' 
when 'MB2' then 'I2S' 
when 'MB3' then 'I3U' 
when 'OP1' then 'TOA' 
when 'UMO' then 'UDC' 
when 'MV1' then 'IM1' 
when 'MV2' then 'IM2' 
when 'MV3' then 'IM3U' 
when 'TMM1' then 'TMTI' 
when 'OP2' then 'TOAM' 
when 'TAH' then 'TAH' 
when 'MFD' then 'MFD' 
end
||';;;'||/*SYMBOL*/SECURITY_DESCRIPTION||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||E.abt||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TRADING_CURRENCY,
           --CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   TICK_STRUCTURE_ID,
	   replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   --MATURITY_DAY,
	   POOL_FACTOR,
	   COUPON,
	   SYMBOL,
           MDS_MULTICAST_CHANNEL_ID,
	   ACTIVE_LOAD_ID,
	   TRADING_PARAMETER,
 	   SECURITY_DESCRIPTION,
 	   MARKET_DATA_CHANNEL_ID,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION
	   from ATSD_INS_BOND where market_id='MOT'
) A left join (
	select case G.TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
                else 'TS_01'
                end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
                --H.NEXT_ENTRY_ID
	from ATSD_TPA_NORMAL G
	--left join
	--ATSD_TEN_SESSION_PARAMETER H
	--on G.session_parameter =  H.table_id
        --where NEXT_ENTRY_ID=3 or NEXT_ENTRY_ID is NULL 
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
	select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
	select instrument_id, sum(bookvalue) as abt from
	(
        	select instrument_id, 1 as bookvalue from atsd_ord_normal
	        union all
        	select instrument_id, 2 as bookvalue from atsd_ord_bulletin
	        union all
        	select instrument_id, 4 as bookvalue from atsd_ord_off_book
	        union all
        	select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
	) F
	group by instrument_id
) E on a.instrument_id = e.instrument_id
;
spool off;

spool BIT-SEDEX.csv;

select PRODUCT_NAME||';'||CUSIP_ISIN||';;'||LOTSIZE||';'||EXCHANGE_MARKET_SIZE||';'||B.MINIMUM_DISCLOSED_SIZE||';;'||
case TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
else TICK_STRUCTURE_ID_TP
end
||';'||C.DISPLAY_NAME||';'||STARTDATE||';'||ENDDATE||';'||TRADING_CURRENCY||';;9;00;'||SETTLEMENT_DATE||';'||ENDDATE||';'||CLOSINGPRICE||';;'||LSEG_MAX_SPREAD_PERCENTAGE||';'||COUNTRY||';;'||DELETION_DATE||';;;'||SYMBOL||';'||A.INSTRUMENT_ID||';'||LSEG_CLEARING_TYPE||';'||UNDERLYING||';;;;;;;;;;'||
case MDS_MULTICAST_CHANNEL_ID
when 0 then 'A'
when 1 then 'A'
when 2 then 'B'
when 3 then 'B'
when 4 then 'C'
when 5 then 'C'
when 6 then 'D'
when 7 then 'D'
when 8 then 'E'
when 9 then 'E'
when 10 then 'F'
when 11 then 'F'
end
||';'||
case PRODUCT_NAME 
when 'ATF' then 'ATFA' 
when 'DMO' then 'ICC' 
when 'EMO' then 'EVC' 
when 'ETC' then 'ETCA' 
when 'ETF' then 'ETFA' 
when 'MM1' then 'MTI' 
when 'UTF' then 'UTFA' 
when 'SD' then 'ILC' 
when 'SDQ' then 'ILCQ' 
when 'MA1' then 'AI1' 
when 'MA2' then 'AI2' 
when 'MA3' then 'AIUR' 
when 'MB1' then 'I1S' 
when 'MB2' then 'I2S' 
when 'MB3' then 'I3U' 
when 'OP1' then 'TOA' 
when 'UMO' then 'UDC' 
when 'MV1' then 'IM1' 
when 'MV2' then 'IM2' 
when 'MV3' then 'IM3U' 
when 'TMM1' then 'TMTI' 
when 'OP2' then 'TOAM' 
when 'TAH' then 'TAH' 
when 'MFD' then 'MFD' 
end||';'||SYMBOL||';'||SECURITY_DESCRIPTION||';'||MARKET_DATA_CHANNEL_ID||';'||MDS_MULTICAST_CHANNEL_ID||';'||ACTIVE_LOAD_ID||';'||E.abt||';'||ALTERNATE_SECURITY_TYPE||';'||LSEG_PRICE_NOTATION from ( 
    select PRODUCT_NAME,
           CUSIP_ISIN, 
           LOTSIZE, 
           EXCHANGE_MARKET_SIZE,
           SECURITY_TYPE,
           replace(first_trading_date,'/','') as STARTDATE,
           replace(last_trading_day,'/','') as ENDDATE,
           TRADING_CURRENCY,
           CLOSINGPRICE,
           LSEG_MAX_SPREAD_PERCENTAGE,
           substr(CUSIP_ISIN, 1, 2) as COUNTRY,
	   TICK_STRUCTURE_ID,
           replace(SETTLEMENT_DATE,'/','') as SETTLEMENT_DATE,
           replace(deletion_date,'/','') as DELETION_DATE,
           INSTRUMENT_ID,
           LSEG_CLEARING_TYPE,
	   SYMBOL,
           MDS_MULTICAST_CHANNEL_ID,
	   ACTIVE_LOAD_ID,
 	   TRADING_PARAMETER,
	   SECURITY_DESCRIPTION,
	   MARKET_DATA_CHANNEL_ID,
	   UNDERLYING,
	   ALTERNATE_SECURITY_TYPE,
	   LSEG_PRICE_NOTATION 
	   from ATSD_INS_DERIVATIVE 
	   where market_id='SEDEX'
) A left join (
	select case G.TICK_STRUCTURE_ID
when 'TS_MTA' then 'TS_MTA'
when 'TS_ETF' then 'TS_ETF'
when 'TS_SDX' then 'TS_SDX'
when 'TS_SDQ_10' then 'TS_SDQ_10'
when 'TS_SDQ_100' then 'TS_SDQ_100'
when 'TS_01' then 'TS_01'
when 'TS_02' then 'TS_02'
when 'TS_03' then 'TS_03'
when 'TS_04' then 'TS_04'
when 'TS_05' then 'TS_05'
when 'TS_06' then 'TS_06'
when 'TS_07' then 'TS_07'
when 'TS_08' then 'TS_08'
when 'TS_09' then 'TS_09'
when 'TS_010' then 'TS_010'
when 'TS_011' then 'TS_011'
when 'TS_012' then 'TS_012'
when 'TS_013' then 'TS_013'
when 'TS_014' then 'TS_014'
when 'TS_015' then 'TS_015'
when 'TS_016' then 'TS_016'
when 'TS_017' then 'TS_017'
when 'TS_018' then 'TS_018'
when 'TS_019' then 'TS_019'
when 'TS_20' then 'TS_20'
when 'TS_21' then 'TS_21'
when 'TS_22' then 'TS_22'
when 'TS_23' then 'TS_23'
when 'TS_24' then 'TS_24'
when 'TS_25' then 'TS_25'
when 'TS_26' then 'TS_26'
when 'TS_27' then 'TS_27'
when 'TS_28' then 'TS_28'
when 'TS_29' then 'TS_29'
when 'TS_30' then 'TS_30'
when 'TS_31' then 'TS_31'
when 'TS_32' then 'TS_32'
when 'TS_33' then 'TS_33'
when 'TS_34' then 'TS_34'
when 'TS_35' then 'TS_35'
when 'TS_36' then 'TS_36'
when 'TS_37' then 'TS_37'
when 'TS_38' then 'TS_38'
when 'TS_39' then 'TS_39'
when 'TS_40' then 'TS_40'
when 'TS_41' then 'TS_41'
when 'TS_42' then 'TS_42'
when 'TS_43' then 'TS_43'
when 'TS_44' then 'TS_44'
when 'TS_45' then 'TS_45'
when 'TS_46' then 'TS_46'
when 'TS_47' then 'TS_47'
when 'TS_48' then 'TS_48'
when 'TS_49' then 'TS_49'
when 'TS_50' then 'TS_50'
when 'TS_51' then 'TS_51'
when 'TS_52' then 'TS_52'
when 'TS_53' then 'TS_53'
when 'TS_54' then 'TS_54'
when 'TS_55' then 'TS_55'
when 'TS_56' then 'TS_56'
when 'TS_57' then 'TS_57'
when 'TS_58' then 'TS_58'
when 'TS_59' then 'TS_59'
when 'TS_60' then 'TS_60'
when 'TS_61' then 'TS_61'
when 'TS_62' then 'TS_62'
when 'TS_63' then 'TS_63'
when 'TS_64' then 'TS_64'
when 'TS_65' then 'TS_65'
when 'TS_66' then 'TS_66'
when 'TS_67' then 'TS_67'
when 'TS_68' then 'TS_68'
when 'TS_69' then 'TS_69'
when 'TS_70' then 'TS_70'
when 'TS_71' then 'TS_71'
when 'TS_72' then 'TS_72'
when 'TS_73' then 'TS_73'
when 'TS_74' then 'TS_74'
when 'TS_75' then 'TS_75'
when 'TS_76' then 'TS_76'
when 'TS_77' then 'TS_77'
when 'TS_78' then 'TS_78'
when 'TS_79' then 'TS_79'
when 'TS_80' then 'TS_80'
when 'TS_81' then 'TS_81'
when 'TS_82' then 'TS_82'
when 'TS_83' then 'TS_83'
when 'TS_84' then 'TS_84'
when 'TS_85' then 'TS_85'
when 'TS_86' then 'TS_86'
when 'TS_87' then 'TS_87'
when 'TS_88' then 'TS_88'
when 'TS_89' then 'TS_89'
when 'TS_90' then 'TS_90'
when 'TS_91' then 'TS_91'
when 'TS_92' then 'TS_92'
when 'TS_93' then 'TS_93'
when 'TS_94' then 'TS_94'
when 'TS_95' then 'TS_95'
when 'TS_96' then 'TS_96'
when 'TS_97' then 'TS_97'
when 'TS_98' then 'TS_98'
when 'TS_99' then 'TS_99'
when 'TS_ATF' then 'TS_ATF'
when 'TS_01MF' then 'TS_01MF'
when 'TS_02MF' then 'TS_02MF'
when 'TS_03MF' then 'TS_03MF'
when 'TS_04MF' then 'TS_04MF'
when 'TS_05MF' then 'TS_05MF'
when 'TS_06MF' then 'TS_06MF'
when 'TS_ETFMF' then 'TS_ETFMF'
                else 'TS_01'
                end TICK_STRUCTURE_ID_TP,
		G.MINIMUM_DISCLOSED_SIZE,
                G.OBJECT_ID
	from ATSD_TPA_NORMAL G
) B on A.TRADING_PARAMETER = B.OBJECT_ID left join (
select DISPLAY_NAME,CONSTANT_VALUE from ATS_CONSTANTS where ENUMERATION_NAME = 'SECURITY_TYPE'
)  C on A.SECURITY_TYPE = C.CONSTANT_VALUE left join (
-- extracting closing price for instruments
	select trim(rtrim(rtrim(to_char(previous_close, '9999990.999999'),'0'), '.')) as previous_close,
             instrument_id from ATSD_WAT_MARKET_WATCH_EQT where book_definition_id='NORMAL'
) D on a.instrument_id = d.instrument_id join (
-- Calculating allowed book types and striiping off instruments which don't have any book allowed
	select instrument_id, sum(bookvalue) as abt from
	(
        	select instrument_id, 1 as bookvalue from atsd_ord_normal
	        union all
        	select instrument_id, 2 as bookvalue from atsd_ord_bulletin
	        union all
        	select instrument_id, 4 as bookvalue from atsd_ord_off_book
	        union all
        	select instrument_id, 8 as bookvalue from atsd_ord_privaterfq
	) F
	group by instrument_id
) E on a.instrument_id = e.instrument_id
;

spool off;

exit;
