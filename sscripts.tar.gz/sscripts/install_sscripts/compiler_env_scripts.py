#!/usr/bin/env python

import logging
import sys
import re
import os
import subprocess
import configparser
import xml.etree.ElementTree as ET
from pprint import pprint
import csv
import cx_Oracle
import shutil


def get_values_from_db(query):
    """
    common function for working with database
    :param query: text of query
    :return: information from db, format: list of tuples
    """

    query_answer = db_cursor.execute(query)
    db_connect.commit()

    try:
        answer = query_answer.fetchall()
    except AttributeError:
        answer = "Query answer is empty - successful upload"
    return answer


def get_list_of_strings(list_of_tuples):
    new = []
    for i in list_of_tuples:
        new.append(i[0])
    return new


def get_single_value(list_of_tuples):
    for i in range(len(list_of_tuples)):
        try:
            for j in list_of_tuples[i]:
                if str(list_of_tuples[i][j]):
                    return str(list_of_tuples[i][j]).replace('(', '').replace(')', '').replace(',', '')
        except TypeError:
            if str(list_of_tuples[i]):
                return str(list_of_tuples[i]).replace('(', '').replace(')', '').replace(',', '')


""" Config processing """


def parse_config(config_file):
    """
    Function for parsing main configuration file (config.xml)
    :param config_file: abs path to config file
    :return: dict with full info where tags in the xml will be keys of dict
    and test of tags - values of the dict[key]
    """
    full_config_info = {}
    tree = ET.parse(config_file)
    root = tree.getroot()
    for child in root:
        if child.tag in ['UpReplicas', 'Multicast', 'FAST', 'Pcaps', 'SPO', 'FSB', 'BSS', 'ML', 'UploadPrices', 'GTP']:
            value = True if child.text == '1' else False
            full_config_info[child.tag] = value
        elif child.tag == 'NumberPartitions':
            if re.match('[1-9]', child.text):
                number_part = child.text
        elif child.tag == 'Processes':
            processes_information, processes_confs = get_processes_information(child, number_part,
                                                                               full_config_info['UpReplicas'])
        else:
            full_config_info[child.tag] = child.text
    full_config_info['number_partitions'] = number_part
    full_config_info['processes'] = processes_information
    full_config_info['processes_configurations'] = processes_confs
    return full_config_info


def get_processes_information(processes_xml_child, number_part, up_replicas):
    """
    Function for getting internal settings for processes.
    Will be used for generate script for update process settings by SSI cmds
    :param processes_xml_child:
    :param number_part:
    :param up_replicas:
    :return:
    """
    def get_process_names(part_def, part_inst_ids, part_inst_sub_id, process_cfg_name, proc_inst_id):
        processes = []
        if part_def in ['FixGroup', 'PostTrade', 'MarketDataOut', 'DSG', 'Pricing']:
            try:
                part_inst_id = re.search('[0-9]{1,}', process_cfg_name).group(0)
            except AttributeError:
                part_inst_id = '1'
            proc_def = process_cfg_name.replace(part_inst_id, '')
            for i in proc_inst_id:
                process_name = part_def + ':' + part_inst_id + ':' + part_inst_sub_id + ':' + proc_def + ':' + i
                processes.append(process_name)
        elif part_def == 'Native':
            part_inst_id = '1'
            proc_inst_id = re.search('[0-9]{1,}', process_cfg_name).group(0)
            proc_def = process_cfg_name.replace(proc_inst_id, '')
            process_name = part_def + ':' + part_inst_id + ':' + part_inst_sub_id + ':' + proc_def + ':' + proc_inst_id
            processes.append(process_name)
        elif part_def == 'Matching':
            for partition in part_inst_ids:
                for i in proc_inst_id:
                    process_name = part_def + ':' + partition + ':' + part_inst_sub_id + ':' + process_cfg_name + ':' + i
                    processes.append(process_name)
        else:
            for i in proc_inst_id:
                process_name = part_def + ':1:' + part_inst_sub_id + ':' + process_cfg_name + ':' + i
                processes.append(process_name)
        return processes

    def get_proc_config(proc):
        """
        Function for getting info about process settings
        :param proc: process_child from xml config
        :return: dict with key as process_name and value as dict with all settings
        """
        proc_config = {}
        for config_group in proc:
            cfg_set = {}
            for config_id in config_group:
                cfg_set[config_id.tag] = config_id.text
            proc_config[config_group.tag] = cfg_set
        return proc_config

    process_list = []
    process_settings = {}
    part_inst_ids = []
    for i in range(1, int(number_part)+1):
        part_inst_ids.append(str(i))
    part_inst_sub_id = '1'
    proc_inst_id = ['1', '2'] if up_replicas else ['1']
    # GENERAL: <PART_DEF>:<PART_INST_ID>:<PART_INST_SUB_ID>:<PROC_DEF>:<PROC_INST_ID>
    for process_group in processes_xml_child:
        part_def = process_group.tag
        if process_group.tag == 'MandatoryReplicas':
            if up_replicas:
                continue
            for i in process_group:
                for proc in i:
                    if proc.text == '0':
                        continue
                    proc_inst_replica_only = ['2']
                    procs = get_process_names(i.tag, part_inst_ids, part_inst_sub_id, proc.tag, proc_inst_replica_only)
                    process_list.extend(procs)
                    proc_config = get_proc_config(proc)
                    if proc_config:
                        for p in procs:
                            process_settings[p] = proc_config
            continue
        for proc in process_group:
            if proc.text == '0':
                continue
            procs = get_process_names(part_def, part_inst_ids, part_inst_sub_id, proc.tag, proc_inst_id)
            process_list.extend(procs)
            proc_config = get_proc_config(proc)
            if proc_config:
                for p in procs:
                    process_settings[p] = proc_config
    return process_list, process_settings


def check_file_exist(file_name, directory):
    """
    Function for check that file is in directory
    :param file_name: file, which must be found
    :param directory: directory for search
    :return: True if file exists, else False
    """
    for i in os.listdir(directory):
        full_path = os.path.join(directory, i)
        if os.path.isfile(full_path) and i == file_name:
            return True
    return False


def parse_csv(csv_file):
    """
    Function for parse csv files
    :param csv_file: abs path of file
    :return: list of dicts, where keys = column_names
    """
    fi = open(csv_file)
    r = csv.reader(fi)
    lines = [l for l in r]
    fi.close()
    csv_info = []
    header = lines[0]
    for line_number in range(1, len(lines)):
        csv_entry = {}
        for column_number in range(len(lines[line_number])):
            tag_name = header[column_number]
            line = lines[line_number]
            csv_entry[tag_name] = line[column_number]
        csv_info.append(csv_entry)
    return header, csv_info


def is_it_exist_in_db(search_value, tag_name, table_name):
    """
    Function for check, that instance not exists in database
    :param sg_db_string: connection string for access to database
    :param search_value: value, that must be searched in the table
    :param tag_name: name of column in the table
    :param table_name: table in database
    :return: True if value has been found, False in value has not been found
    """
    query_text = 'SELECT ' + str(tag_name) + ' FROM ' + str(table_name)
    values_in_db = get_values_from_db(query_text)
    values_set = get_list_of_strings(values_in_db)
    if search_value in values_set:
        common.info_output("Value " + str(search_value) + " found.")
        return True
    else:
        common.info_output("Value " + str(search_value) + " not found in values_set")
        return False


def upload_entry_to_sg_scheme(default_header, entry_body, table_name, db_header):
    db_header_querytext = 'SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'' + table_name + '\''
    db_header_feedback = get_values_from_db(db_header_querytext)
    db_header = get_list_of_strings(db_header_feedback)
    #db_header.reverse()
    unknown_tags = filter(lambda z: z not in default_header, db_header)
    if unknown_tags:
        default_values = {}
        for tag in unknown_tags:
            if tag == 'DESCRIPTION':
                default_value = 'AutoUploaded'
            else:
                query_text = 'SELECT ' + tag + ' FROM ' + table_name
                info_from_db = get_values_from_db(query_text)
                try:
                    default_value = get_single_value(info_from_db)
                except IndexError:
                    default_value = ''
            default_values[tag] = default_value
    query_text = 'INSERT INTO ' + table_name + ' ('
    query_values = ' VALUES('
        print(i)
        if table_name == 'SG4_SCRIPTS':
            tagname = db_header[len(db_header)-i-1]
        else:
            tagname = db_header[i]
        try:
            tagvalue = entry_body[tagname]
        except KeyError:
            tagvalue = default_values[tagname]

        if tagvalue == 'None':
            tagvalue = ''
        if i == 0:
            query_values = query_values + '\'' + tagvalue.replace('\'', '') + '\''
            query_text = query_text + tagname 
        else:
            query_values = query_values + ', \'' + tagvalue.replace('\'', '') + '\''
            query_text = query_text + ', ' + tagname
    query_values = query_values + ') '
    query_text = query_text + ') ' + query_values
    
    common.debug_output(query_text)
    db_query_feedback = get_values_from_db(query_text)
    common.debug_output(db_query_feedback)


def validation_process_list(process_list, bss_cfg):
    for proc in process_list:
        valid_proc = is_it_exist_in_db(proc, 'OWNER', 'SG4_CONFIGS')
        if not valid_proc:
            common.error_output('Process ' + str(proc) + ' has not been found in the database')
            input("Proceed? ")
        if re.search('Pricing', proc) and not bss_cfg:
            common.error_output('Pricing without bss ')
            input("Proceed? ")


def install_multicast(tools_dir, multicast_dir_name, port):
    """
    Function for fully install of multicast.
    :param tools_dir: directory, where tool must be installed
    :param multicast_archive_name: default value = udp.tar.gz. This archive is in tools dir
    :param part_number: value from main config.xml
    :param sg_db_string: connection string for access to database
    :return: nothing
    """
    multicast_directory = os.path.join(tools_dir, multicast_dir_name)
    script_name = 'prepare_udpproxy_itch.sh'
    script_path = os.path.join(tools_dir, script_name)
    process = subprocess.Popen([script_path, port])
    process.wait()
    common.debug_output("script started")
    start_itch_script = 'start_all_itch.sh'
    #deploy_script(start_itch_script, multicast_directory)
    common.debug_output("deploy completed")
    start_itch_script = 'start_itch1.sh'
    #deploy_script(start_itch_script, multicast_directory)


def install_multicast_fast(tools_dir, multicast_dir_name, port):
    multicast_directory = os.path.join(tools_dir, multicast_dir_name)
    script_name = 'prepare_udpproxy_fast.sh'
    script_path = os.path.join(tools_dir, script_name)
    process = subprocess.Popen([script_path, port])
    process.wait()
    common.debug_output("script started")
    start_itch_script = 'start_all_fast.sh'
    #deploy_script(start_itch_script, multicast_directory)
    common.debug_output("deploy completed")
    start_itch_script = 'start_fast1.sh'
    #deploy_script(start_itch_script, multicast_directory)


def make_symlink(path):
    """
    Function for creating symlink in the ~/current/scripts/ directory to some script in path dir
    :param path: abs path to script
    :return: nothing
    """
    common_scripts_dir = os.path.join(os.environ['SYSTEM_HOME'], 'scripts')

    link_name = os.path.basename(path)
    #if link_name in os.listdir(common_scripts_dir):
    #    common.info_output(link_name + " already exist in the " + common_scripts_dir)
    #    return None
    if os.path.islink(os.path.join(common_scripts_dir, link_name)):
        os.remove(os.path.join(common_scripts_dir, link_name))
    current_dir = os.getcwd()
    os.chdir(common_scripts_dir)
    os.symlink(path, link_name)
    os.chdir(current_dir)
    common.info_output("Symlink to " + path + " has been created in the scripts dir: " + common_scripts_dir)


def install_pcap(tools_dir, tool_dir_name):
    """
    Function for fully install pcaps
    """
    pcap_dir = os.path.join(tools_dir, tool_dir_name)
    script_name = 'set_pcap_for_system.sh'
    script_path = os.path.join(tools_dir, script_name)
    ps = subprocess.Popen([script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ps.wait()
    out, err = ps.communicate()
    common.debug_output(str(out))
    start_pcap_script = 'start_all_pcap.sh'
    #deploy_script(start_pcap_script, pcap_dir)


def prepare_proc_set_xml_config(proc_sets, cfg_dir_path):
    config_filename = 'process_settings_SOD.xml'
    config_filepath = os.path.join(cfg_dir_path, config_filename)
    global upd_proc_settings_configpath
    upd_proc_settings_configpath = config_filepath
    xml_root = 'ProcessSettings'
    common.info_output('creating file: ' + config_filename + ' with root = ' + xml_root)
    root = ET.Element(xml_root)
    tree = ET.ElementTree(root)
    tree.write(config_filepath)
    tree = ET.parse(config_filepath)
    root = tree.getroot()
    for proc_name in proc_sets.keys():
        child = ET.SubElement(root, 'ProcessConfiguration')
        subchild = ET.SubElement(child, 'ProcessName')
        subchild.text = proc_name
        for config_group in proc_sets[proc_name].keys():
            cfgg = ET.SubElement(child, config_group)
            for config in proc_sets[proc_name][config_group].keys():
                cfg = ET.SubElement(cfgg, config)
                cfg.text = proc_sets[proc_name][config_group][config]
    tree.write(config_filepath)
    with open(config_filepath) as f:
        x = f.readline().replace('><', ">\n<")
    with open(config_filepath, 'w') as s:
        for i in x:
            s.write(i)


def deploy_script(script_name, dir):
    script_for_upload = os.path.join(dir, script_name)
    make_symlink(script_for_upload)
    script_id = os.path.splitext(script_name)[0]
    header = ['SCRIPT_ID', 'SCRIPT_NAME']
    body = {'SCRIPT_ID': script_id, 'SCRIPT_NAME': script_name}
    script_already_exist = is_it_exist_in_db(script_id, 'SCRIPT_ID', 'SG4_SCRIPTS')
    if script_already_exist:
        common.info_output('Script ' + script_id + ' already exist')
    else:
        SG4_SCRIPTS_header.reverse()
        upload_entry_to_sg_scheme(header, body, 'SG4_SCRIPTS', SG4_SCRIPTS_header)
        machines_tab_body = {}
        machines_tab_body['SCRIPT_ID'] = script_id
        upload_entry_to_sg_scheme(['SCRIPT_ID'], machines_tab_body, 'SG4_SCRIPT_MACHINES', SG4_SCRIPT_MACHINES_header)
        common.info_output('Script ' + script_id + ' has been uploaded to database')


def create_new_sequence_main_entry(sequence_name, sg_db_filling_dir):
    file_name = sequence_name + '.csv'
    seq_main_entry = {}
    if file_name in os.listdir(sg_db_filling_dir):
        seq_main_entry['SEQUENCE_NAME'] = sequence_name
        seq_main_entry['DESCRIPTION'] = 'UploadedAutomatically'
        seq_main_entry['HALT_ON_ERROR'] = '0'
        seq_main_entry['STATUS'] = '1'
    return seq_main_entry


def validate_spo_module(processes_list):
    for process_name in processes_list:
        if re.search('PortalGateway', process_name):
            return True
    return False

def validation_module(seq_mod, processes_list):
    module_exist = False
    mod_type = seq_mod['MODULE_TYPE']
    if mod_type == '0':
        common.info_output("Validation sequence module: process")
        if seq_mod['MODULE_NAME'] in processes_list:
            common.debug_output('Process has been found in the processes_list')
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'DISPLAY_NAME', 'SG4_INSTANCES')
            common.debug_output('module_exist: ' + str(module_exist))
            if not module_exist:
                 common.warning_output('Process has not been found in the database')
                 module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'OWNER', 'SG4_CONFIGS')
        else:
            common.debug_output('Process has not been found in the processes_list. Skip')

    elif mod_type == '1':
        common.info_output("Validation sequence module: process")
        pure_process_name = seq_mod['MODULE_NAME']
        for i in range(1, 40):
            old_val = ':r' + str(i)
            new_val = ':' + str(i)
            pure_process_name = pure_process_name.replace(old_val, new_val)
        if pure_process_name in processes_list:
            module_exist = is_it_exist_in_db(pure_process_name, 'DISPLAY_NAME', 'SG4_INSTANCES')
            if not module_exist:
                module_exist = is_it_exist_in_db(pure_process_name, 'OWNER', 'SG4_CONFIGS')
    elif mod_type == '2':
        common.info_output("Validation sequence module: sequence")
        #if seq_mod['MODULE_NAME'] in processes_list:
        module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'SEQUENCE_NAME', 'SG4_SEQ_MAIN')
        print(' module exist result: ' + str(module_exist))
    elif mod_type == '3':
        common.info_output("Validation sequence module: script")
        if seq_mod['MODULE_NAME'] in ['Delete_SPOGC', 'Truncate_GrosCons_Tables']:
            exist_spo_module = validate_spo_module(processes_list)
            if not exist_spo_module:
                common.info_output("SPO scripts are disabled")
                module_exist = False
            else:
                module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'SCRIPT_ID', 'SG4_SCRIPTS')
        else:
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'SCRIPT_ID', 'SG4_SCRIPTS')
    elif mod_type == '4':
        common.info_output("Validation sequence module: flags")
        if seq_mod['MODULE_NAME'] == 'MASS_CHANGE_SYS_FLAG':
            module_exist = True
        else:
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'FLAG_NAME', 'SG4_FLAG_VALUES')
    elif mod_type == '6':
        common.info_output("Validation sequence module: global configs")
        module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'PARAMETER', 'SG4_CONFIGS')
    elif mod_type == '8':
        common.info_output("Validation sequence module: wait")
        module_exist = True if seq_mod['MODULE_NAME'] == 'WAIT' else False
    elif mod_type == '5':
        common.info_output("Validation sequence module: MASS_CHANGE_START_MODE")
        module_exist = True # if seq_mod['MODULE_NAME'] == 'MASS_CHANGE_START_MODE' else False
    else:
        common.warning_output("Unknown module type: " + str(mod_type))
    if module_exist:
        common.info_output("Module is ok")
        return True
    else:
        common.debug_output("Invalid module")
        return False


def collect_global_settings(full_info):
    global_cfg_info = {}
    global_cfg_info['Global'] = {}
    global_cfg_info['SStart_Steps'] = {}
    global_cfg_info['SStop_steps'] = {}
    global_cfg_info['Flags'] = {}
    global_cfg_info['SStart_sequences'] = {}
    global_cfg_info['SStop_sequences'] = {}
    global_cfg_info['FSB_LIFE_SUP'] = {}
    global_cfg_info['GTP_variables'] = {}
    global_cfg_info['SPO_variables'] = {}
    global_cfg_info['SSM_ARCHIVATOR'] = {}
    global_cfg_info['Global']['TIMER_FLAG'] = '"800"'
    global_cfg_info['Global']['BACKUPS_CFG_NAME'] = '"backups.cfg"'
    global_cfg_info['SStart_Steps']['CHECKPOINTER_SOD_STEP'] = '"Y"'
    global_cfg_info['SStart_Steps']['EXECUTOR_DEMON_STARTUP'] = '"N"'
    global_cfg_info['SStop_steps']['DSG_BACKUP'] = '"Y"'
    global_cfg_info['SStop_steps']['AL_BACKUP'] = '"Y"'
    global_cfg_info['SStop_steps']['TRD_BACKUP'] = '"Y"'
    global_cfg_info['SStop_steps']['RD_BACKUP'] = '"Y"'
    global_cfg_info['SStop_steps']['EOD_RD_UPLOAD'] = '"N"'
    global_cfg_info['SStop_steps']['PROD_RD_SVN_LINK'] = '""'
    global_cfg_info['Flags']['EOD_SET_FLAGS_DONE'] = '"STARTUP_SEQ","FLAG_MDS_EOD","FLAG_AL_EOD","FLAG_PTTPS_EOD","FLAG_EOD_OF_GENERATION","FLAG_EM_EOD","FLAG_END_OF_DAY","FLAG_SYNC_STATUS","FLAG_EOD_NEXT_TRADING_DAY_SET","FLAG_OM_DSG_EOD","FLAG_MD_DSG_EOD","FLAG_PT_DSG_EOD","FLAG_SCG_EOD","FLAG_PS_EOD"'
    global_cfg_info['Flags']['SOD_RESET_FLAGS'] = '"FLAG_END_OF_DAY","FLAG_SYSTEM_CHKPT","FLAG_SOD_OF_LOADING"'
    global_cfg_info['SStart_sequences']['APP_CHKPT_SOD_SEQUENCE_NAME'] = '"SStart_Start_of_AppChkpt"'
    global_cfg_info['SStart_sequences']['SET_SOD_FLAGS_CONFIGURATION_SEQUENCE_NAME']='"SStart_SOD_FlagsConfiguration"'
    global_cfg_info['SStart_sequences']['START_APPLICATION_PROCESSES_SEQUENCE_NAME']='"SStart_Start_All_AppProcesses"'
    global_cfg_info['SStop_sequences']['STOP_APPLICATION_PROCESSES_SEQUENCE_NAME'] = '"SStop_Stop_All_AppProcesses"'
    global_cfg_info['SStop_sequences']['APP_CHKPT_EOD_SEQUENCE_NAME'] = '"SStop_AppChkpt_EOD"'
    global_cfg_info['FSB_LIFE_SUP']['FSB_LIFE_SUPPORTER'] = '"N"'
    global_cfg_info['GTP_variables']['GTP_CHECK_FLAG'] = "None"
    global_cfg_info['GTP_variables']['GTP_CHECKFLAG_SCRIPT'] = "None"
    global_cfg_info['GTP_variables']['GTP_GW_STARTUP_FLAG'] = "None"
    global_cfg_info['GTP_variables']['GTP_RD_COPY'] = "None"
    global_cfg_info['GTP_variables']['GTP_RD_COPY_DIRNAME'] = "None"
    global_cfg_info['GTP_variables']['GTP_RD_COPY_SCRIPT'] = "None"
    global_cfg_info['GTP_variables']['GTP_REMOTE_CONNECTION'] = "None"
    global_cfg_info['GTP_variables']['GTP_SEQUENCE'] = "None"
    global_cfg_info['GTP_variables']['GTP_SSICMD_SCRIPT'] = "None"
    global_cfg_info['GTP_variables']['GTP_START_SCRIPT'] = "None"
    global_cfg_info['GTP_variables']['GTP_TRAD_FILENAME'] = "None"
    global_cfg_info['GTP_variables']['GTP_TRAD_FILEPATH'] = "None"
    global_cfg_info['GTP_variables']['GTP_VENUENAME'] = "None"
    global_cfg_info['GTP_variables']['GTP_VS_SCRIPTS_DIR'] = "None"
    global_cfg_info['SSM_ARCHIVATOR']['SSM_ARCHIVATOR'] = '"N"'
 
    for i in full_info.keys():
        if i in ['AUTOOFFSET_DAYSTART_MIN', 'VENUE']:
            global_cfg_info['Global'][i] = '"' + str(full_info[i]) + '"'
        elif i == 'CleansystemCMD':
            global_cfg_info['Global']['CLEAN_SYSTEM_CMD'] = '"' + str(full_info[i]) + '"'
        elif i == 'StartupCMD':
            global_cfg_info['Global']['START_SYSTEM_CMD'] = '"' + str(full_info[i]) + '"'
        elif i == 'ShutdownCMD':
            global_cfg_info['Global']['SHUTDOWN_SYSTEM_CMD'] = '"' + str(full_info[i]) + '"'
        elif i in ['BSS', 'FAST', 'FSB', 'GTP', 'ML', 'Multicast', 
                   'Pcaps', 'SPO', 'UploadPrices']:
            if i == 'UploadPrices':
                if full_info[i]:
                    global_cfg_info['SStart_sequences']['START_PRICE_UPLOADER_SEQUENCE_NAME'] = '"SStart_StartPriceUploader"'
                    global_cfg_info['SStart_sequences']['STOP_PRICE_UPLOADER_SEQUENCE_NAME'] = '"SStart_StopPriceUploader"'
                ii = 'PRICE_UPLOADER_STEP'
            elif i == 'GTP':
                ii = 'GTP_STEP'
            elif i == 'Pcaps':
                ii = 'PCAP'
            else:
                ii = i.upper()
            if type(full_info[i]) == bool:
                ival = '"Y"' if full_info[i] else '"N"'
            else:
                ival = '"Y"' if full_info[i] == '1' else '"N"'
            global_cfg_info['SStart_Steps'][ii] = ival
        elif i == 'processes_configurations':
            if full_info[i]:
                global_cfg_info['SStart_Steps']['UPDATE_PROCESS_SETTINGS'] = '"Y"'
                global_cfg_info['SStart_Steps']['UPDATE_PROCESS_SETTINGS_CONFIG'] = '"' + str(full_info['Venue']) + '_AggProcSettings.xml"'
            else:
                global_cfg_info['SStart_Steps']['UPDATE_PROCESS_SETTINGS'] = '"N"'
                global_cfg_info['SStart_Steps']['UPDATE_PROCESS_SETTINGS_CONFIG'] = '""'
        elif i in ['GenSODFiles']:
            if full_info[i] == '1': 
                global_cfg_info['SStop_sequences']['GENERATE_SOD_FILES_SEQUENCE_NAME'] = '"SStop_Gen_SOD_Files"'
                global_cfg_info['SStop_steps']['GENERATING_SOD_FILES'] = '"Y"' 
            else:
                global_cfg_info['SStop_sequences']['GENERATE_SOD_FILES_SEQUENCE_NAME'] = '""'
                global_cfg_info['SStop_steps']['GENERATING_SOD_FILES'] = '"N"' 
        elif i in ['SPO_link']:
            global_cfg_info['SPO_variables']['SPO_LINK'] = '"' + str(full_info[i]) + '"' if full_info[i] else  "None"
    return global_cfg_info


def create_cfg(settings, path):
    config = configparser.ConfigParser()
    config.optionxform = lambda option: option
    for section in settings.keys():
        config.add_section(section)
        for i in settings[section].keys():
            config.set(section, i, settings[section][i])
    with open(path, 'w') as config_file:
        config.write(config_file, space_around_delimiters=False)


if __name__ == '__main__':
    try:
        config_file = str(sys.argv[1])
    except IndexError:
        config_file = 'config.xml'

    # logging configuration
    logfile = './compile_env_scripts.log'
    with open(logfile, 'w') as s:
        s.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfile)

    itch_start_port = str(int(os.environ['S_REG_PORT_NO']) - 200)
    fast_start_port = '9090'
    upd_proc_settings_configpath = ''

    # directory paths
    script_home_folder = os.getcwd()
    py_common_module_path = os.path.join(script_home_folder, 'env_maintenance_scripts', 'py_common', 'common.py')
    import env_maintenance_scripts.py_common.common as common
    common.info_output('Preparing. find paths of directories...')

    env_maintenance_directory = os.path.join(script_home_folder, 'env_maintenance_scripts')
    bin_directory = os.path.join(env_maintenance_directory, 'bin')
    cfg_directory = os.path.join(env_maintenance_directory, 'cfg')
    logs_directory = os.path.join(env_maintenance_directory, 'logs')
    tools_directory = os.path.join(env_maintenance_directory, 'tools')
    py_common_directory = os.path.join(env_maintenance_directory, 'py_common')
    sg_db_filling_directory = os.path.join(script_home_folder, 'sg_db_filling')
    if not os.path.isdir(logs_directory):
        os.mkdir(logs_directory)
    common.debug_output('main directory: ' + env_maintenance_directory)
    common.debug_output('bin directory: ' + bin_directory)
    common.debug_output('cfg directory: ' + cfg_directory)
    common.debug_output('logs directory: ' + logs_directory)
    common.debug_output('py common directory: ' + py_common_directory)
    common.debug_output('sysguard db info directory: ' + sg_db_filling_directory)
    shell_work_with_db = os.path.join(script_home_folder, './work_with_db.sh')

    # Parse stuff
    common.info_output("Parse main config...")
    # main config
    is_file_exist = check_file_exist(config_file, script_home_folder)
    if not is_file_exist:
        logging.critical(config_file + ' not found')
        print(common.bcolors.WARNING + config_file + ' not found! Exit' + common.bcolors.ENDC)
        exit()
    config_file_path = os.path.join(script_home_folder, config_file)
    full_config_info = parse_config(config_file_path)
    common.info_output('Parsing of main config has been successfully done')
    # get SG DB connection string
    sg_db_string = common.get_db_string('SG')
    common.info_output(sg_db_string)
    ats_db_string = common.get_db_string('ATS')
    common.info_output(ats_db_string)
    
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()

    # get hostnames
    query_text = """ SELECT HOST FROM SG4_HOSTS """
    hosts_names = get_values_from_db(query_text)
    hosts = get_list_of_strings(hosts_names)

    # validation of all processes 
    validation_process_list(full_config_info['processes'], full_config_info['BSS'])
    common.info_output('All instances that specified in main config file are exist in database. Proceed')

    # headers
    SG4_SEQ_MAIN_header = ['SEQUENCE_NAME', 'DESCRIPTION', 'SEQ_NO', 'HALT_ON_ERROR',
                           'STATUS', 'ESTIMATED_TIME', 'OBSERVATION_COUNT']
    SG4_SEQ_DETAIL_header = ['SEQUENCE_NAME', 'MODULE_NAME', 'POSITION', 'MODULE_TYPE',
                             'VALUE', 'CRITICAL', 'MODULE_INDEX']
    SG4_SCRIPTS_header = ['SCRIPT_ID', 'SCRIPT_NAME', 'PARAMETERS', 'DESCRIPTION',
                          'ACCESS_LEVEL', 'CHECKSUM', 'VALIDATE_SUM']
    SG4_SCRIPT_MACHINES_header = ['SCRIPT_ID', 'HOST', 'PREFERENCE']

    common.debug_output("SG4_SEQ_MAIN_header: " + str(SG4_SEQ_MAIN_header))
    common.debug_output("SG4_SEQ_DETAIL_header: " + str(SG4_SEQ_DETAIL_header))
    common.debug_output("SG4_SCRIPTS_header: " + str(SG4_SCRIPTS_header))
    common.debug_output("SG4_SCRIPT_MACHINES_header: " + str(SG4_SCRIPT_MACHINES_header))

    print('Press enter to start... ')
    #input()
    # Multicast
    common.info_output("Setting ITCH Multicast Proxy")
    """ In this box will fully installed, configured multicast for itch and uploaded scripts for start itch:
    start_all_itch.sh """
    multicast_directory = os.path.join(tools_directory, 'UDPProxy_ITCH')
    if full_config_info['Multicast']:
        common.info_output("Multicast is enabled in the main config. Start settings...")
        if os.path.isdir(multicast_directory):
            install_multicast(tools_directory, 'UDPProxy_ITCH', itch_start_port)
            common.info_output("Deploy and configuration of multicastProxy have been successfully completed")
        else:
            common.error_output("Directory with MulticastProxyTool has not been found. Please, check")
            input("Proceed? ") 
        print('Install ITCH multicast completed. Press enter to continue')
        #input()
    else:
        common.info_output("Multicast is disabled in the main config. Skipped")
        if os.path.isdir(multicast_directory):
            shutil.rmtree(multicast_directory)

    # Multicast_FAST
    common.info_output("Setting FAST Multicast Proxy")
    """ In this box will fully installed, configured multicast and uploaded scripts for start fast:
    start_all_fast.sh and start_fast1.sh"""
    multicast_directory = os.path.join(tools_directory, 'UDPProxy_FAST')
    if full_config_info['FAST']:
        common.info_output("FAST is enabled in the main config. Start settings...")
        if os.path.isdir(multicast_directory):
            install_multicast_fast(tools_directory, 'UDPProxy_FAST', fast_start_port)
            common.info_output("Deploy and configuration of multicastProxy FAST have been successfully completed")
        else:
            common.error_output("Directory with MulticastProxyTool for FAST has not been found. Please, check")
            input("Proceed? ")
        print('Install FAST multicast completed. Press enter to continue')
        #input()
    else:
        common.info_output("FAST is disabled in the main config. Skipped")
        try:
            if os.path.isdir(multicast_directory):
                os.remove(multicast_directory)
        except OSError:
            common.info_output("Directory with FAST has not been found")

    # pcap
    """ In this box will fully installed, configured pcaps and uploaded start_capture.sh"""
    common.info_output("Setting PCAP capturing tool")
    pcap_dir_name = os.path.join(tools_directory, 'pcap')
    if full_config_info['Pcaps']:
        common.info_output("PCAP is enabled in the main config. Start settings...")
        if os.path.isdir(pcap_dir_name):
            install_pcap(tools_directory, 'pcap')
            common.info_output("Deployment and configuration of pcap tool has  been successfully completed")
        else:
            common.error_output("Archive with pcap tool has not been found. Please, check")
            input("Proceed? ")
        print('Install PCAPs completed. Press enter to continue')
        #input()
    else:
        common.info_output("PCAP tool is disabled in the main config. Skipped")
        if os.path.isdir(pcap_dir_name):
            shutil.rmtree(pcap_dir_name)

    # SPO
    """ In this box will uploaded scripts for SPO: Delete_SPOGC.sh and Truncate_GrosCons_Tables.sh """
    common.info_output("Setting SPO")
    if full_config_info['SPO'] and full_config_info['SPO_link']:
        common.info_output("SPO is enabled in main config.")
        script_fullpath = full_config_info['SPO_link']
        directory_spo = os.path.dirname(script_fullpath)
        spo_scriptname = os.path.basename(script_fullpath)
        is_file_exist = check_file_exist(spo_scriptname, directory_spo)
        if not is_file_exist:
            common.warning_output('SPO script not found. Please check')
        deploy_script(spo_scriptname, tools_directory)
        common.info_output("SPO scripts have been sucessfully added to the system")
        print('Press enter to comtinue')
        #input()
    else:
        common.info_output("SPO is disabled in the main config.")

    # FSB
    """ In this box will uploaded FSB_START script. """
    common.info_output("Setting FSB")
    script_name = 'FSB_START.sh'
    if full_config_info['FSB']:
        common.info_output("FSB is enabled in main config.")
        #deploy_script(script_name, tools_directory)
        common.info_output("Script FSB_START has been  sucessfully added to the system")
        print('Press enter to continue')
        #input()
    else:
        common.info_output("FSB is disabled in the main config.")
        script_for_del = os.path.join(tools_directory, script_name)
        if os.path.isfile(script_for_del):
            os.remove(script_for_del)

    # BSS
    """ In this box will uploaded FSB_START script. """
    common.info_output("Setting BSS")
    script_name = 'start_bss.sh'
    bss_tools_directory = os.path.join(tools_directory, 'bss')
    if full_config_info['BSS']:
        common.info_output("BSS is enabled in main config.")
        deploy_script(script_name, bss_tools_directory)
        common.info_output("Script start_bss has been  sucessfully added to the system")
        print('Press enter to comtinue')
        #input()
    else:
        common.info_output("BSS is disabled in the main config.")
        if os.path.isdir(bss_tools_directory):
            shutil.rmtree(bss_tools_directory)

    # ML
    """ In this box will uploaded FSB_START script. """
    common.info_output("MITCH Listener")
    if full_config_info['ML']:
        common.info_output("ML is enabled in main config.")
        common.info_output("MITCH Listener can be setup only on started system")
        common.info_output("Please, use scripts ML_prepare.sh and ML_compile.sh when you'll start the system")
        print('Press enter to comtinue')
        #input()
    else:
        common.info_output("ML is disabled in the main config.")

    # raw_input("UploadPrices...")
    """ In this box will uploaded prepare_closing_prices.sh script. """
    common.info_output("Setting upload prices functionality")
    script_name = 'prepare_closing_prices.sh'
    script_name = 'update_closing_prices.py'
    sequences = ['SStart_StartPriceUploader', 'SStart_StopPriceUploader']
    if full_config_info['UploadPrices']:
        common.info_output("upload prices functionality is enabled in the main config")
        deploy_script(script_name, py_common_directory)
        common.info_output("script " + script_name + " has been upoladed to the system")
        print('Press enter to comtinue')
        #input()
    else:
        common.info_output("upload prices functionality is disabled  in the main config")
        #script_for_del = os.path.join(tools_directory, script_name)
        #if os.path.isfile(script_for_del):
        #    os.remove(script_for_del)
        #for seq_for_del in sequences:
        #    seq_path = os.path.join(sg_db_filling_directory, seq_for_del)
        #    if os.path.isfile(seq_path):
        #        os.remove(seq_path)

    # Update process settings
    """ In this box config file for update_process_settings.sh will be prepared """
    common.info_output("SSI update process settings")
    if full_config_info['processes_configurations']:
        common.info_output("special configurations for process have been added to the main config. Upload script...")
        prepare_proc_set_xml_config(full_config_info['processes_configurations'], cfg_directory)
        print('Press enter to comtinue')
        #input()
    script_name = 'update_process_settings.py'
    script_path = os.path.join(py_common_directory, script_name)
    if os.path.isfile(script_path):
        #deploy_script(script_name, py_common_directory)
        common.info_output("script " + script_name + " has been uploaded to the system")
    # Scripts
    """ In this box will uploaded some necessary scripts
    Such as check_flags_configuration.sh, update_system_times.sh, RAF, CTCR, update_process_settings.sh """
    common.info_output("Upload other scripts to the system")
    scripts = ['check_flags_configuration.py', 'update_system_times.sh', 'RAF', 'CTCR']
    print('Setup of additional tools completed. The next step - is upload SCRIPTS to SG schema')
    print('Press enter to continue')
    #input()

    query_text = 'SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'SG4_SCRIPTS\''
    db_table_header = get_values_from_db(query_text)
    db_header = get_list_of_strings(db_table_header)
    common.debug_output("db_header of table SG4_SCRIPTS: " + str(db_header))
    for script in scripts:
        d = py_common_directory if re.search('.py', script) else bin_directory
        script_path = os.path.join(d, script)
        if not os.path.isfile(script_path):
            common.info_output('ERROR. Script ' + script + ' not found in ' + str(d) + ' directory')
            continue
        #deploy_script(script, d)
        common.info_output("script " + script_name + " has been uploaded to the system")

    # Sequences
    common.info_output("Upload all sequences to the system")
    
    sg4_seq_detail_db_header_query = 'SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'SG4_SEQ_DETAIL\''
    sg4_seq_detail_db_header_feedback = get_values_from_db(sg4_seq_detail_db_header_query)
    sg4_seq_detail_db_header = get_list_of_strings(sg4_seq_detail_db_header_feedback)
    sl = os.listdir(sg_db_filling_directory)
    print(sl)
    for i in sl:
        if re.search('_sub', i):
            z = sl.index(i)
            print('Index of sub sequence: '  + str(z))
            poped_element = sl.pop(z)
            sl.insert(0, poped_element)
    print(sl)
    input()
    for seq in sl:
        if not os.path.splitext(seq)[1] == '.csv':
            continue
        seq_id = os.path.splitext(seq)[0]
        common.info_output("sequence name = " + seq_id)
        new_seq_main = create_new_sequence_main_entry(seq_id, sg_db_filling_directory)
        common.debug_output("seq_entry_body: " + str(new_seq_main))
        seq_exist = is_it_exist_in_db(seq_id, 'SEQUENCE_NAME', 'SG4_SEQ_MAIN')
        if seq_exist:
            common.info_output("Sequence already exist")
            continue
        columns_list = []
        values_list = []
        for tagname in new_seq_main.keys():
            tagvalue = '\'' + new_seq_main[tagname] + '\''
            columns_list.append(tagname)
            values_list.append(tagvalue)
        columns = str(columns_list).replace('[', '').replace(']', '').replace('"', '').replace('\'', '')
        values = str(values_list).replace('[', '').replace(']', '').replace('"', '')
        query_text = ' INSERT INTO SG4_SEQ_MAIN (' + columns + ') values ( ' + values + ') '
        common.debug_output(query_text)
        db_cursor.execute(query_text)
        seq_full_path = os.path.join(sg_db_filling_directory, seq)
        head, sequence_stuffing = parse_csv(seq_full_path)
        if not head == SG4_SEQ_DETAIL_header:
            common.debug_output("header from csv file: " + str(head))
            common.debug_output("default header for table SG4_SEQ_DETAIL: " + str(SG4_SEQ_DETAIL_header))
            common.debug_output("HEADER from csv file not equal default value")
        module_index = 0
        for seq_mod in sequence_stuffing:
            common.debug_output("Upload sequence module " + seq_mod['MODULE_NAME'] + " to the SG4_SEQ_DETAIL table")
            is_valid = validation_module(seq_mod, full_config_info['processes'])
            if is_valid:
                seq_mod['MODULE_INDEX'] = str(module_index)
                if seq_mod['MODULE_TYPE'] == '3' and seq_mod['VALUE']:
                    seq_mod['VALUE'] = hosts[0] + ":" + seq_mod['VALUE']
                elif seq_mod['MODULE_TYPE'] == '3' and not seq_mod['VALUE']:
                    seq_mod['VALUE'] = hosts[0]
                elif seq_mod['MODULE_TYPE'] == '3' and seq_mod['MODULE_NAME'] == 'QH_Start':
                    pricing_exist = False
                    for i in full_config_info['processes']:
                        if re.search('Pricing', i):
                            pricing_exist = True
                            break
                    if not pricing_exist:
                        print('script QH_Start skipped')
                        continue

                elif seq_mod['MODULE_TYPE'] == '4' and seq_mod['VALUE'] == 'FLAG_PS_EOD':
                    pricing_exist = False
                    for i in full_config_info['processes']:
                        if re.search('Pricing', i):
                            pricing_exist = True
                            break
                    if pricing_exist:
                        print('Flag FLAG_PS_EOD skipped')
                        continue
                elif seq_mod['MODULE_TYPE'] == '4' and seq_mod['VALUE'] == 'FLAG_SCG_EOD':
                    scoring_exist = False
                    for i in full_config_info['processes']:
                        if re.search('Scoring', i):
                            scoring_exist = True
                            break
                    if scoring_exist:
                        print('Flag FLAG_SCG_EOD skipped')
                        continue

                columns_list = []
                values_list = []
                for tagname in sg4_seq_detail_db_header:
                    tagvalue = '\'' + seq_mod[tagname] + '\''
                    columns_list.append(tagname)
                    values_list.append(tagvalue)
                columns = str(columns_list).replace('[', '').replace(']', '').replace('"', '').replace('\'', '')
                values = str(values_list).replace('[', '').replace(']', '').replace('"', '')
                query_text = ' INSERT INTO SG4_SEQ_DETAIL (' + columns + ') values ( ' + values + ') '
                common.debug_output('Uploading to SG4_SEQ_DETAIL table...')
                common.debug_output(query_text)
                db_cursor.execute(query_text)

                module_index += 1
                common.debug_output("Sequence module " + seq_mod['MODULE_NAME'] + " has been successfully uploaded")
                common.debug_output(" for sequence_name = " + seq_mod['SEQUENCE_NAME'])
            else:
                common.debug_output("STEP UPLOAD TO DETAIL table. Module " + str(seq_mod) + " cannot be uploaded. Skipped")
    db_connect.commit()
    exit()
    # Generate global.cfg
    global_settings = collect_global_settings(full_config_info)
    # backups.cfg will be hard coded
    global_cfg_path = os.path.join(cfg_directory, 'global.cfg')
    create_cfg(global_settings, global_cfg_path)
    # Create symlinks in $HOME
    current_dir = os.getcwd()
    os.chdir(os.environ['HOME'])
    for script in ['SStart.sh', 'SStop.sh']:
        path = os.path.join(bin_directory, script)
        link_path = os.path.join(os.environ['HOME'], str(script).replace('.sh', ''))
        if not os.path.islink(link_path) and os.path.isfile(path):
            try:
                os.symlink(path, link_path)
            except OSError as e:
                common.error_output(e)
        else:
            common.info_output(str(path) + ' already exist')
    path = os.path.join(cfg_directory, 'ExactproSystemTimes.cfg')
    link_path = os.path.join(os.environ['HOME'], 'ExactproSystemTimes.cfg')
    if not os.path.islink(link_path) and os.path.isfile(path):
        try:
            os.symlink(path, link_path)
        except OSError as e:
            common.error_output(e)
    else:
        common.info_output(str(path) + ' already exist')
    os.chdir(current_dir)
    common.info_output('Compiling of SStart/Stop scripts has been completed.')

    # Copy config file
    #config_name = full_config_info['VENUE'] + '_markets_cycles_settings.cfg'
    #temp_configfile_path = os.path.join(env_maintenance_directory, 'temp', config_name)
    #cfg_configfile_path  = os.path.join(env_maintenance_directory, 'cfg', 'markets_cycles_settings.cfg')
    #shutil.copyfile(temp_configfile_path, cfg_configfile_path)
