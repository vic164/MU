#!/usr/bin/env python

import logging
import sys
import re
import os
import subprocess
import xml.etree.ElementTree as ET
from pprint import pprint
import csv
import cx_Oracle
import shutil
import time
import argparse


def print_about_script():
    """
    Output some info about this tool
    """
    script_name = os.path.basename((__file__))
    lm = time.ctime(os.path.getmtime(__file__))
    print()
    print(str(script_name) + ' @ Exactpro, LLC')
    print('Written by Victoria Shinkarenko. Last modify:' + str(lm))
    print()


def create_argument_parser():
    """
    Function for handling arguments
    Possible arguments for start script:
    -h, --help: for output help and exit
    -a, --action: download sequences or upload
    -b, --backup: create backup of sequences beofre upload
    -s, --sequences: path to sequences
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--action', default='upload', help=' download or upload (sequences)')
    parser.add_argument('-b', '--backup', default=False, help='create backup of sequences beofre upload'),
    parser.add_argument('-s', '--source', default=os.path.join(script_dir, 'Sequences'),
                        help=': directory for getting/saving sequences as xml files')
    return parser


def get_seq_list(upath):
    """
    Function for processing path to sequences
    :param upath: path to dir or to sinle file
    :return: list of files with sequences
    """
    result_list = []
    if os.path.isfile(upath):
        if os.path.splitext(upath)[1] == '.xml':
            result_list.append(upath)
        else:
            logging.error('Bad sequence file ' + str(upath))
    elif os.path.isdir(upath):
        for i in os.listdir(upath):
            ipath = os.path.join(upath, i)
            if os.path.splitext(ipath)[1] == '.xml':
                result_list.append(ipath)
    return result_list


def parse_seq_file(filepath):
    """
    Function for parse sequences in xml format
    :param filepath: full path of xml file
    :return: info for SG4_SEQUENCES and for SG4_SEQ_DETAIL
    """
    seq_detail_data = {}
    seq_tree = ET.parse(filepath)
    seq_root = seq_tree.getroot()
    seq_general_settings = seq_root.attrib
    for module in seq_root:
        module_info = module.attrib
        module_index = module_info['INDEX']
        del module_info['INDEX']
        seq_detail_data[module_index] = module_info
    return seq_general_settings, seq_detail_data


def get_db_header(table_name):
    """
    Function for getting actual db header for table
    :param table_name: name of table in SG schema
    :return: header in list format
    """
    query = "SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'{t}\'".format(t=table_name)
    query_result = get_values_from_db(query)
    return query_result


def get_values_from_db(query):
    """
    common function for working with database (SG schema)
    :param query: text of queryto SG schema
    :return: information from db, format: list of tuples
    """
    answer = []
    query_answer = db_cursor.execute(query)
    db_connect.commit()
    try:
        tuple_answer = query_answer.fetchall()
        for i in tuple_answer:
            answer.append(i[0])
    except AttributeError:
        logging.warning('Empty answer for query: ' + str(query))
    return answer


def check_seq_exists(sequence_name):
    """
    Function if sequence already exists in DB
    :param sequence_name:
    :return: True if exists, False - if not
    """
    query = 'SELECT * FROM {tn} WHERE SEQ_NAME = \'{sn}\''.format(tn=db_table_main_name, sn=sequence_name)
    main_answer = get_values_from_db(query)
    query = 'SELECT * FROM {tn} WHERE SEQ_NAME = \'{sn}\''.format(tn=db_table_detail_name, sn=sequence_name)
    detail_answer = get_values_from_db(query)
    if not main_answer and not detail_answer:
        return False
    else:
        return True


def clear_old_seq(sequence_name):
    """
    Function for deletion previous version of sequence from DB
    :param sequence_name:
    :return:
    """
    query = 'DELETE * FROM {tn} WHERE SEQ_NAME = \'{sn}\''.format(tn=db_table_main_name, sn=sequence_name)
    main_answer = get_values_from_db(query)
    query = 'SELECT * FROM {tn} WHERE SEQ_NAME = \'{sn}\''.format(tn=db_table_detail_name, sn=sequence_name)
    detail_answer = get_values_from_db(query)


def validate_sequence(seq_details, seq_name):
    logging.info('Validation sequence' + str(seq_name))
    for i in seq_details.keys():
        seq_entry = seq_details[i]
        if seq_entry['TYPE'] in ['0', '1']:
            process_name = seq_entry['NAME']
            logging.debug('Validation ' + str(process_name))



def upload_main_sequence(seq_main):
    pass

def upload_details_sequence(seq_details):
    pass


def upload_sequences(seq_path, backup):
    """
    General function for upload sequences
    :param seq_path: path to dir or file with sequences
    :param backup: true|false - for download and backup sequences before upload
    :return:
    """
    sequences = get_seq_list(seq_path)
    logging.debug('Sequences for upload:')
    logging.debug(sequences)
    if backup:
        logging.info('Download old sequences for backup before upload')
        backup_dir = os.path.join(script_dir, script_name + '_sequences_backup')
        os.makedirs(backup_dir)
        download_sequences(backup_dir)
    for seq in sequences:
        logging.info('Sequence: ' + str(seq))
        seq_main, seq_details = parse_seq_file(seq)
        logging.debug('seq main')
        logging.debug(seq_main)
        logging.debug('seq_details')
        logging.debug(pprint(seq_details))
        logging.info('Check sequence already exists')
        seq_exists = check_seq_exists(seq_main['SEQ_NAME'])
        if seq_exists:
            clear_old_seq(seq_main['SEQ_NAME'])
        validate_sequence(seq_main, seq_details)
        upload_main_sequence(seq_main)
        upload_details_sequence(seq_details)


def download_sequences(seq_path):
    pass


if __name__ == '__main__':
    print_about_script()
    script_dir = os.path.dirname(os.path.realpath(__file__))
    script_name = os.path.splitext(os.path.basename(os.path.realpath(__file__)))[0]
    logfilename = os.path.join(script_dir, (script_name + '.log'))
    with open(logfilename, 'w') as s:
        s.write('')
    # Logging setup
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=log_level, filename=logfilename)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    logging.getLogger('').addHandler(console)
    # Work with arguments or getting default values
    parser = create_argument_parser()
    namespace = parser.parse_args(sys.argv[1:])
    action = namespace.action
    seq_dir = namespace.seq_dir
    backups = namespace.backups
    # add common module
    py_common_module_path = os.path.join(script_dir, 'env_maintenance_scripts', 'py_common', 'common.py')
    import env_maintenance_scripts.py_common.common as common
    # Connect to oracle sg schema
    sg_db_string = common.get_db_string('SG')
    logging.info(sg_db_string)
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()

    # Main actions
    db_table_main_name = 'SG4_SEQ_MAIN'
    db_table_detail_name = 'SG4_SEQ_DETAIL'
    db_main_header = get_db_header(db_table_main_name)
    db_detail_header = get_db_header(db_table_detail_name)
    if action == 'download':
        download_sequences(seq_dir)
    elif action == 'upload':
        upload_sequences(seq_dir, backups)
    else:
        logging.error('Unknown action. Please, use download or upload for argument -a (--action)')
        exit(1)