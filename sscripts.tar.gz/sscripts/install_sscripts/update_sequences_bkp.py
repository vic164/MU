#!/usr/bin/env python

import logging
import sys
import re
import os
import subprocess

import xml.etree.ElementTree as ET
from pprint import pprint
import csv
#import cx_Oracle
import shutil


def parse_seq_file(filepath):
    seq_detail_data = {}
    seq_tree = ET.parse(filepath)
    seq_root = seq_tree.getroot()
    seq_general_settings = seq_root.attrib
    for module in seq_root:
        module_info = module.attrib
        module_index = module_info['INDEX']
        del module_info['INDEX']
        seq_detail_data[module_index] = module_info
    return seq_general_settings, seq_detail_data


def check_seq_exists(sequence_name):
    check_main_query = "SELECT SEQUENCE_NAME FROM SG4_SEQ_MAIN WHERE SEQUENCE_NAME = '{s}'".format(s=sequence_name)
    query_main_result = sg_query(check_main_query)
    check_detail_query = "SELECT SEQUENCE_NAME FROM SG4_SEQ_DETAIL WHERE SEQUENCE_NAME = '{s}'".format(s=sequence_name)
    query_detail_result = sg_query(check_detail_query)
    if not query_main_result and not query_detail_result:
        to_be_clear_flag = False
        result = False
    elif query_main_result and query_detail_result:
        to_be_clear_flag = False
        result = True
    else:
        logging.warning('Bad SG setup: sequence exists only in 1 table (SG4_SEQ_MAIN or SG4_SEQ_DETAIL)')
        logging.warning('Please, check')
        print('Are you sure you want to continue?')
        input()
        to_be_clear_flag = True
        result = False
    return result, to_be_clear_flag


def sg_query(q):
    result = []
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()
    query_answer = db_cursor.execute(q)
    try:
        answer = query_answer.fetchall()
    except AttributeError:
        answer = ""
    for i in answer:
        result.append(i[0])
    return result


def download_sequence(sequence_name):
    seq_main_header = get_table_header('SG4_SEQ_MAIN')
    seq_detail_header = get_table_header('SG4_SEQ_DETAIL')
    sg4_seq_main_query = "SELECT * FROM SG4_SEQ_MAIN WHERE SEQUENCE_NAME = '{s}'".format(s=sequence_name)
    sg4_seq_main_result = sg_query(sg4_seq_main_query)
    sg4_seq_detail_query = "SELECT * FROM SG4_SEQ_DETAIL WHERE SEQUENCE_NAME = '{s}'".format(s=sequence_name)
    sg4_seq_detail_result = sg_query(sg4_seq_detail_query)
    sequence_xml = compile_xml_sequence(seq_main_header, seq_detail_header,
                                        sg4_seq_main_result, sg4_seq_detail_result)
    filepath = os.path.join(os.path.dirname(__file__), sequence_name + '.xml')
    save_xml(sequence_xml, filepath)


def get_table_header(table_name):
    query = "SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = '{t}'".format(t=table_name)
    result = sg_query(query)
    return result


def save_sequence_name(header1, header2, data1, data2, filepath):
    new_xml_root = ET.Element('SEQUENCE')
    # header1 = SEQUENCE_NAME, DESCRIPTION, SEQ_NO, HALT_ON_ERROR, STATUS, ESTIMATES_TIME, OBSERVATION_COUNT
    # header2 = SEQUENCE_NAME, MODULE_NAME, POSITION, MODULE_TYPE, VALUE, CRITICAL, MODULE_INDEX
    # root: ACTION, SEQ_NAME, ACTION_ON_ERR, STATUS, DESC, SGE_TYPE,
    # module: ACTION, POSITION, VALUE, NAME, TYPE, INDEX, CRITICALITY, SGE_TYPE
    root_parameters = {}
    root_parameters['ACTION'] = '0' # ?
    root_parameters['SEQ_NAME'] = data1[header1.index('SEQUENCE_NAME')]
    root_parameters['ACTION_ON_ERR'] = '2' # ? HALT_ON_ERROR = '0'
    root_parameters['STATUS'] = data1[header1.index('STATUS')]
    root_parameters['DESC'] = data1[header1.index('DESCRIPTION')]
    root_parameters['SGE_TYPE'] = '13' # -?
    new_xml_root.attrib = root_parameters
    for i in data2:
        module_child = ET.SubElement(new_xml_root, 'Module')
        module_parameters = {}
        module_parameters['ACTION'] = '3' # -?
        module_parameters['POSITION'] = data2[header2['POSITION']]
        module_parameters['VALUE'] = data2[header2['VALUE']]
        module_parameters['NAME'] = data2[header2['MODULE_NAME']]
        module_parameters['TYPE'] = data2[header2['MODULE_TYPE']]
        module_parameters['INDEX'] = data2[header2['MODULE_INDEX']]
        module_parameters['CRITICALITY'] = data2[header2['CRITICAL']]
        module_parameters['SGE_TYPE'] = '228' # -?
        module_child.attrib = module_parameters
    # save xml (i forgot how


def get_values_from_db(query):
    """
    common function for working with database
    :param query: text of query
    :return: information from db, format: list of tuples
    """

    query_answer = db_cursor.execute(query)
    db_connect.commit()

    try:
        answer = query_answer.fetchall()
    except AttributeError:
        answer = "Query answer is empty - successful upload"
    return answer


def get_list_of_strings(list_of_tuples):
    new = []
    for i in list_of_tuples:
        new.append(i[0])
    return new


def get_single_value(list_of_tuples):
    for i in range(len(list_of_tuples)):
        try:
            for j in list_of_tuples[i]:
                if str(list_of_tuples[i][j]):
                    return str(list_of_tuples[i][j]).replace('(', '').replace(')', '').replace(',', '')
        except TypeError:
            if str(list_of_tuples[i]):
                return str(list_of_tuples[i]).replace('(', '').replace(')', '').replace(',', '')


""" Config processing """


def parse_config(config_file):
    """
    Function for parsing main configuration file (config.xml)
    :param config_file: abs path to config file
    :return: dict with full info where tags in the xml will be keys of dict
    and test of tags - values of the dict[key]
    """
    full_config_info = {}
    tree = ET.parse(config_file)
    root = tree.getroot()
    for child in root:
        if child.tag in ['UpReplicas', 'Multicast', 'FAST', 'Pcaps', 'SPO', 'FSB', 'BSS', 'ML', 'UploadPrices']:
            value = True if child.text == '1' else False
            full_config_info[child.tag] = value
        elif child.tag == 'NumberPartitions':
            if re.match('[1-9]', child.text):
                number_part = child.text
        elif child.tag == 'Processes':
            processes_information, processes_confs = get_processes_information(child, number_part,
                                                                               full_config_info['UpReplicas'])
        else:
            full_config_info[child.tag] = child.text
    full_config_info['number_partitions'] = number_part
    full_config_info['processes'] = processes_information
    full_config_info['processes_configurations'] = processes_confs
    return full_config_info


def get_processes_information(processes_xml_child, number_part, up_replicas):
    """
    Function for getting internal settings for processes.
    Will be used for generate script for update process settings by SSI cmds
    :param processes_xml_child:
    :param number_part:
    :param up_replicas:
    :return:
    """
    def get_process_names(part_def, part_inst_ids, part_inst_sub_id, process_cfg_name, proc_inst_id):
        processes = []
        if part_def in ['FixGroup', 'PostTrade', 'MarketDataOut', 'DSG', 'Pricing']:
            try:
                part_inst_id = re.search('[0-9]{1,}', process_cfg_name).group(0)
            except AttributeError:
                part_inst_id = '1'
            proc_def = process_cfg_name.replace(part_inst_id, '')
            for i in proc_inst_id:
                process_name = part_def + ':' + part_inst_id + ':' + part_inst_sub_id + ':' + proc_def + ':' + i
                processes.append(process_name)
        elif part_def == 'Native':
            part_inst_id = '1'
            proc_inst_id = re.search('[0-9]{1,}', process_cfg_name).group(0)
            proc_def = process_cfg_name.replace(proc_inst_id, '')
            process_name = part_def + ':' + part_inst_id + ':' + part_inst_sub_id + ':' + proc_def + ':' + proc_inst_id
            processes.append(process_name)
        elif part_def == 'Matching':
            for partition in part_inst_ids:
                for i in proc_inst_id:
                    process_name = part_def + ':' + partition + ':' + part_inst_sub_id + ':' + process_cfg_name + ':' + i
                    processes.append(process_name)
        else:
            for i in proc_inst_id:
                process_name = part_def + ':1:' + part_inst_sub_id + ':' + process_cfg_name + ':' + i
                processes.append(process_name)
        return processes

    def get_proc_config(proc):
        """
        Function for getting info about process settings
        :param proc: process_child from xml config
        :return: dict with key as process_name and value as dict with all settings
        """
        proc_config = {}
        for config_group in proc:
            cfg_set = {}
            for config_id in config_group:
                cfg_set[config_id.tag] = config_id.text
            proc_config[config_group.tag] = cfg_set
        return proc_config

    process_list = []
    process_settings = {}
    part_inst_ids = []
    for i in range(1, int(number_part)+1):
        part_inst_ids.append(str(i))
    part_inst_sub_id = '1'
    proc_inst_id = ['1', '2'] if up_replicas else ['1']
    # GENERAL: <PART_DEF>:<PART_INST_ID>:<PART_INST_SUB_ID>:<PROC_DEF>:<PROC_INST_ID>
    for process_group in processes_xml_child:
        part_def = process_group.tag
        if process_group.tag == 'MandatoryReplicas':
            if up_replicas:
                continue
            for i in process_group:
                for proc in i:
                    if proc.text == '0':
                        continue
                    proc_inst_replica_only = ['2']
                    procs = get_process_names(i.tag, part_inst_ids, part_inst_sub_id, proc.tag, proc_inst_replica_only)
                    process_list.extend(procs)
                    proc_config = get_proc_config(proc)
                    if proc_config:
                        for p in procs:
                            process_settings[p] = proc_config
            continue
        for proc in process_group:
            if proc.text == '0':
                continue
            procs = get_process_names(part_def, part_inst_ids, part_inst_sub_id, proc.tag, proc_inst_id)
            process_list.extend(procs)
            proc_config = get_proc_config(proc)
            if proc_config:
                for p in procs:
                    process_settings[p] = proc_config
    return process_list, process_settings


def check_file_exist(file_name, directory):
    """
    Function for check that file is in directory
    :param file_name: file, which must be found
    :param directory: directory for search
    :return: True if file exists, else False
    """
    for i in os.listdir(directory):
        full_path = os.path.join(directory, i)
        if os.path.isfile(full_path) and i == file_name:
            return True
    return False


def parse_csv(csv_file):
    """
    Function for parse csv files
    :param csv_file: abs path of file
    :return: list of dicts, where keys = column_names
    """
    fi = open(csv_file)
    r = csv.reader(fi)
    lines = [l for l in r]
    fi.close()
    csv_info = []
    header = lines[0]
    for line_number in range(1, len(lines)):
        csv_entry = {}
        for column_number in range(len(lines[line_number])):
            tag_name = header[column_number]
            line = lines[line_number]
            csv_entry[tag_name] = line[column_number]
        csv_info.append(csv_entry)
    return header, csv_info


def is_it_exist_in_db(search_value, tag_name, table_name):
    """
    Function for check, that instance not exists in database
    :param sg_db_string: connection string for access to database
    :param search_value: value, that must be searched in the table
    :param tag_name: name of column in the table
    :param table_name: table in database
    :return: True if value has been found, False in value has not been found
    """
    query_text = 'SELECT ' + str(tag_name) + ' FROM ' + str(table_name)
    values_in_db = get_values_from_db(query_text)
    values_set = get_list_of_strings(values_in_db)
    if search_value in values_set:
        common.info_output("Value " + str(search_value) + " found.")
        return True
    else:
        common.info_output("Value " + str(search_value) + " not found in values_set")
        return False


def upload_entry_to_sg_scheme(default_header, entry_body, table_name, db_header):
    db_header_querytext = 'SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'' + table_name + '\''
    db_header_feedback = get_values_from_db(db_header_querytext)
    db_header = get_list_of_strings(db_header_feedback)
    unknown_tags = filter(lambda z: z not in default_header, db_header)
    if unknown_tags:
        default_values = {}
        for tag in unknown_tags:
            if tag == 'DESCRIPTION':
                default_value = 'AutoUploaded'
            else:
                query_text = 'SELECT ' + tag + ' FROM ' + table_name
                info_from_db = get_values_from_db(query_text)
                try:
                    default_value = get_single_value(info_from_db)
                except IndexError:
                    default_value = ''
            default_values[tag] = default_value
    query_text = 'INSERT INTO ' + table_name + ' VALUES('
    for i in range(len(db_header)):
        tagname = db_header[i]
        try:
            tagvalue = entry_body[tagname]
        except KeyError:
            tagvalue = default_values[tagname]
        if tagvalue == 'None':
            tagvalue = ''
        if i == 0:
            query_text = query_text + '\'' + tagvalue.replace('\'', '') + '\''
        else:
            query_text = query_text + ', \'' + tagvalue.replace('\'', '') + '\''
    query_text = query_text + ') '
    common.debug_output(query_text)
    db_query_feedback = get_values_from_db(query_text)
    common.debug_output(db_query_feedback)


def validation_process_list(process_list):
    for proc in process_list:
        valid_proc = is_it_exist_in_db(proc, 'OWNER', 'SG4_CONFIGS')
        if not valid_proc:
            common.error_output('Process ' + str(proc) + ' has not been found in the database')
            input("Proceed? ")


def install_multicast(tools_dir, multicast_dir_name, port):
    """
    Function for fully install of multicast.
    :param tools_dir: directory, where tool must be installed
    :param multicast_archive_name: default value = udp.tar.gz. This archive is in tools dir
    :param part_number: value from main config.xml
    :param sg_db_string: connection string for access to database
    :return: nothing
    """
    multicast_directory = os.path.join(tools_dir, multicast_dir_name)
    script_name = 'prepare_udpproxy_itch.sh'
    script_path = os.path.join(tools_dir, script_name)
    process = subprocess.Popen([script_path, port])
    process.wait()
    common.debug_output("script started")
    start_itch_script = 'start_all_itch.sh'
    deploy_script(start_itch_script, multicast_directory)
    common.debug_output("deploy completed")
    start_itch_script = 'start_itch1.sh'
    deploy_script(start_itch_script, multicast_directory)


def install_multicast_fast(tools_dir, multicast_dir_name, port):
    multicast_directory = os.path.join(tools_dir, multicast_dir_name)
    script_name = 'prepare_udpproxy_fast.sh'
    script_path = os.path.join(tools_dir, script_name)
    process = subprocess.Popen([script_path, port])
    process.wait()
    common.debug_output("script started")
    start_itch_script = 'start_all_fast.sh'
    deploy_script(start_itch_script, multicast_directory)
    common.debug_output("deploy completed")
    start_itch_script = 'start_fast1.sh'
    deploy_script(start_itch_script, multicast_directory)


def make_symlink(path):
    """
    Function for creating symlink in the ~/current/scripts/ directory to some script in path dir
    :param path: abs path to script
    :return: nothing
    """
    common_scripts_dir = os.path.join(os.environ['SYSTEM_HOME'], 'scripts')

    link_name = os.path.basename(path)
    if link_name in os.listdir(common_scripts_dir):
        common.info_output(link_name + " already exist in the " + common_scripts_dir)
        return None
    current_dir = os.getcwd()
    os.chdir(common_scripts_dir)
    os.symlink(path, link_name)
    os.chdir(current_dir)
    common.info_output("Symlink to " + path + " has been created in the scripts dir: " + common_scripts_dir)


def install_pcap(tools_dir, tool_dir_name):
    """
    Function for fully install pcaps
    """
    pcap_dir = os.path.join(tools_dir, tool_dir_name)
    script_name = 'set_pcap_for_system.sh'
    script_path = os.path.join(tools_dir, script_name)
    ps = subprocess.Popen([script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    ps.wait()
    out, err = ps.communicate()
    common.debug_output(str(out))
    start_pcap_script = 'start_all_pcap.sh'
    deploy_script(start_pcap_script, pcap_dir)


def prepare_proc_set_xml_config(proc_sets, cfg_dir_path):
    config_filename = 'process_settings_SOD.xml'
    config_filepath = os.path.join(cfg_dir_path, config_filename)
    global upd_proc_settings_configpath
    upd_proc_settings_configpath = config_filepath
    xml_root = 'ProcessSettings'
    common.info_output('creating file: ' + config_filename + ' with root = ' + xml_root)
    root = ET.Element(xml_root)
    tree = ET.ElementTree(root)
    tree.write(config_filepath)
    tree = ET.parse(config_filepath)
    root = tree.getroot()
    for proc_name in proc_sets.keys():
        child = ET.SubElement(root, 'ProcessConfiguration')
        subchild = ET.SubElement(child, 'ProcessName')
        subchild.text = proc_name
        for config_group in proc_sets[proc_name].keys():
            cfgg = ET.SubElement(child, config_group)
            for config in proc_sets[proc_name][config_group].keys():
                cfg = ET.SubElement(cfgg, config)
                cfg.text = proc_sets[proc_name][config_group][config]
    tree.write(config_filepath)
    with open(config_filepath) as f:
        x = f.readline().replace('><', ">\n<")
    with open(config_filepath, 'w') as s:
        for i in x:
            s.write(i)


def deploy_script(script_name, dir):
    script_for_upload = os.path.join(dir, script_name)
    make_symlink(script_for_upload)
    script_id = os.path.splitext(script_name)[0]
    header = ['SCRIPT_ID', 'SCRIPT_NAME']
    body = {'SCRIPT_ID': script_id, 'SCRIPT_NAME': script_name}
    script_already_exist = is_it_exist_in_db(script_id, 'SCRIPT_ID', 'SG4_SCRIPTS')
    if script_already_exist:
        common.info_output('Script ' + script_id + ' already exist')
    else:
        upload_entry_to_sg_scheme(header, body, 'SG4_SCRIPTS', SG4_SCRIPTS_header)
        machines_tab_body = {}
        machines_tab_body['SCRIPT_ID'] = script_id
        upload_entry_to_sg_scheme(['SCRIPT_ID'], machines_tab_body, 'SG4_SCRIPT_MACHINES', SG4_SCRIPT_MACHINES_header)
        common.info_output('Script ' + script_id + ' has been uploaded to database')


def create_new_sequence_main_entry(sequence_name, sg_db_filling_dir):
    file_name = sequence_name + '.csv'
    seq_main_entry = {}
    if file_name in os.listdir(sg_db_filling_dir):
        seq_main_entry['SEQUENCE_NAME'] = sequence_name
        seq_main_entry['DESCRIPTION'] = 'UploadedAutomatically'
        seq_main_entry['HALT_ON_ERROR'] = '0'
        seq_main_entry['STATUS'] = '1'
    return seq_main_entry


def validate_spo_module(processes_list):
    for process_name in processes_list:
        if re.search('PortalGateway', process_name):
            return True
    return False

def validation_module(seq_mod, processes_list):
    module_exist = False
    mod_type = seq_mod['MODULE_TYPE']
    if mod_type == '0':
        common.info_output("Validation sequence module: process")
        if seq_mod['MODULE_NAME'] in processes_list:
            common.debug_output('Process has been found in the processes_list')
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'DISPLAY_NAME', 'SG4_INSTANCES')
            common.debug_output('module_exist: ' + str(module_exist))
            if not module_exist:
                 common.warning_output('Process has not been found in the database')
                 module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'OWNER', 'SG4_CONFIGS')
        else:
            common.debug_output('Process has not been found in the processes_list. Skip')

    elif mod_type == '1':
        common.info_output("Validation sequence module: process")
        pure_process_name = seq_mod['MODULE_NAME']
        for i in range(1, 40):
            old_val = ':r' + str(i)
            new_val = ':' + str(i)
            pure_process_name = pure_process_name.replace(old_val, new_val)
        if pure_process_name in processes_list:
            module_exist = is_it_exist_in_db(pure_process_name, 'DISPLAY_NAME', 'SG4_INSTANCES')
            if not module_exist:
                module_exist = is_it_exist_in_db(pure_process_name, 'OWNER', 'SG4_CONFIGS')
    elif mod_type == '2':
        common.info_output("Validation sequence module: sequence")
        if seq_mod['MODULE_NAME'] in processes_list:
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'SEQUENCE_NAME', 'SG4_SEQ_MAIN')
    elif mod_type == '3':
        common.info_output("Validation sequence module: script")
        if seq_mod['MODULE_NAME'] in ['Delete_SPOGC', 'Truncate_GrosCons_Tables']:
            exist_spo_module = validate_spo_module(processes_list)
            if not exist_spo_module:
                common.info_output("SPO scripts are disabled")
                module_exist = False
            else:
                module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'SCRIPT_ID', 'SG4_SCRIPTS')
        else:
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'SCRIPT_ID', 'SG4_SCRIPTS')
    elif mod_type == '4':
        common.info_output("Validation sequence module: flags")
        if seq_mod['MODULE_NAME'] == 'MASS_CHANGE_SYS_FLAG':
            module_exist = True
        else:
            module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'FLAG_NAME', 'SG4_FLAG_VALUES')
    elif mod_type == '6':
        common.info_output("Validation sequence module: global configs")
        module_exist = is_it_exist_in_db(seq_mod['MODULE_NAME'], 'PARAMETER', 'SG4_CONFIGS')
    elif mod_type == '8':
        common.info_output("Validation sequence module: wait")
        module_exist = True if seq_mod['MODULE_NAME'] == 'WAIT' else False
    elif mod_type == '5':
        common.info_output("Validation sequence module: MASS_CHANGE_START_MODE")
        module_exist = True # if seq_mod['MODULE_NAME'] == 'MASS_CHANGE_START_MODE' else False
    else:
        common.warning_output("Unknown module type: " + str(mod_type))
    if module_exist:
        common.info_output("Module is ok")
        return True
    else:
        common.debug_output("Invalid module")
        return False


if __name__ == '__main__':
    sequences = ['/Users/victoria.shinkarenko/Programming/Exactpro/sscripts/LSE_SStart_Start_All_AppProcesses.xml']
    logging.debug('Sequences for upload:')
    logging.debug(sequences)
    db_table_main_name = 'SG4_SEQUENCES'
    db_table_detail_name = 'SG4_SEQ_DETAIL'
    db_main_header = get_db_header(db_table_main_name)
    db_detail_header = get_db_header(db_table_detail_name)
    for seq in sequences:
        logging.info('Sequence: ' + str(seq))
        seq_main, seq_details = parse_seq_file(seq)
        logging.debug('seq main')
        logging.debug(seq_main)
        logging.debug('seq_details')
        logging.debug(pprint(seq_details))

        sg4_seq_detail_db_header_query = 'SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'SG4_SEQ_DETAIL\''
        sg4_seq_detail_db_header_feedback = get_values_from_db(sg4_seq_detail_db_header_query)
        sg4_seq_detail_db_header = get_list_of_strings(sg4_seq_detail_db_header_feedback)


    exit()
    try:
        config_file = str(sys.argv[1])
    except IndexError:
        config_file = 'config.xml'

    # logging configuration
    logfile = './compile_env_scripts.log'
    with open(logfile, 'w') as s:
        s.write('')
    logging.basicConfig(format=u'%(levelname)-8s [%(asctime)s] %(message)s', level=logging.DEBUG, filename=logfile)

    itch_start_port = '8080'
    fast_start_port = '9090'
    upd_proc_settings_configpath = ''

    # directory paths
    script_home_folder = os.getcwd()
    py_common_module_path = os.path.join(script_home_folder, 'env_maintenance_scripts', 'py_common', 'common.py')
    import env_maintenance_scripts.py_common.common as common
    common.info_output('Preparing. find paths of directories...')

    env_maintenance_directory = os.path.join(script_home_folder, 'env_maintenance_scripts')
    bin_directory = os.path.join(env_maintenance_directory, 'bin')
    cfg_directory = os.path.join(env_maintenance_directory, 'cfg')
    logs_directory = os.path.join(env_maintenance_directory, 'logs')
    tools_directory = os.path.join(env_maintenance_directory, 'tools')
    py_common_directory = os.path.join(env_maintenance_directory, 'py_common')
    sg_db_filling_directory = os.path.join(script_home_folder, 'sg_db_filling')
    if not os.path.isdir(logs_directory):
        os.mkdir(logs_directory)
    common.debug_output('main directory: ' + env_maintenance_directory)
    common.debug_output('bin directory: ' + bin_directory)
    common.debug_output('cfg directory: ' + cfg_directory)
    common.debug_output('logs directory: ' + logs_directory)
    common.debug_output('py common directory: ' + py_common_directory)
    common.debug_output('sysguard db info directory: ' + sg_db_filling_directory)
    shell_work_with_db = os.path.join(script_home_folder, './work_with_db.sh')

    # Parse stuff
    common.info_output("Parse main config...")
    # main config
    is_file_exist = check_file_exist(config_file, script_home_folder)
    if not is_file_exist:
        logging.critical(config_file + ' not found')
        print(common.bcolors.WARNING + config_file + ' not found! Exit' + common.bcolors.ENDC)
        exit()
    config_file_path = os.path.join(script_home_folder, config_file)
    full_config_info = parse_config(config_file_path)
    common.info_output('Parsing of main config has been successfully done')

    # get SG DB connection string
    sg_db_string = common.get_db_string('SG')
    common.info_output(sg_db_string)
    ats_db_string = common.get_db_string('ATS')
    common.info_output(ats_db_string)
    
    db_connect = cx_Oracle.connect(sg_db_string)
    db_cursor = db_connect.cursor()

    # get hostnames
    query_text = """ SELECT HOST FROM SG4_HOSTS """
    hosts_names = get_values_from_db(query_text)
    hosts = get_list_of_strings(hosts_names)

    # validation of all processes 
    validation_process_list(full_config_info['processes'])
    common.info_output('All instances that specified in main config file are exist in database. Proceed')

    # headers
    SG4_SEQ_MAIN_header = ['SEQUENCE_NAME', 'DESCRIPTION', 'SEQ_NO', 'HALT_ON_ERROR',
                           'STATUS', 'ESTIMATED_TIME', 'OBSERVATION_COUNT']
    SG4_SEQ_DETAIL_header = ['SEQUENCE_NAME', 'MODULE_NAME', 'POSITION', 'MODULE_TYPE',
                             'VALUE', 'CRITICAL', 'MODULE_INDEX']
    SG4_SCRIPTS_header = ['SCRIPT_ID', 'SCRIPT_NAME', 'PARAMETERS', 'DESCRIPTION',
                          'ACCESS_LEVEL', 'CHECKSUM', 'VALIDATE_SUM']
    SG4_SCRIPT_MACHINES_header = ['SCRIPT_ID', 'HOST', 'PREFERENCE']

    common.debug_output("SG4_SEQ_MAIN_header: " + str(SG4_SEQ_MAIN_header))
    common.debug_output("SG4_SEQ_DETAIL_header: " + str(SG4_SEQ_DETAIL_header))
    common.debug_output("SG4_SCRIPTS_header: " + str(SG4_SCRIPTS_header))
    common.debug_output("SG4_SCRIPT_MACHINES_header: " + str(SG4_SCRIPT_MACHINES_header))

    common.info_output("Upload all sequences to the system")
    
    sg4_seq_detail_db_header_query = 'SELECT COLUMN_NAME FROM USER_TAB_COLUMNS WHERE TABLE_NAME = \'SG4_SEQ_DETAIL\''
    sg4_seq_detail_db_header_feedback = get_values_from_db(sg4_seq_detail_db_header_query)
    sg4_seq_detail_db_header = get_list_of_strings(sg4_seq_detail_db_header_feedback)

    for seq in os.listdir(sg_db_filling_directory):
        if not os.path.splitext(seq)[1] == '.csv':
            continue
        seq_id = os.path.splitext(seq)[0]
        common.info_output("sequence name = " + seq_id)
        new_seq_main = create_new_sequence_main_entry(seq_id, sg_db_filling_directory)
        common.debug_output("seq_entry_body: " + str(new_seq_main))
        seq_exist = is_it_exist_in_db(seq_id, 'SEQUENCE_NAME', 'SG4_SEQ_MAIN')
        if seq_exist:
            common.info_output("Sequence already exist")
            continue
        columns_list = []
        values_list = []
        for tagname in new_seq_main.keys():
            tagvalue = '\'' + new_seq_main[tagname] + '\''
            columns_list.append(tagname)
            values_list.append(tagvalue)
        columns = str(columns_list).replace('[', '').replace(']', '').replace('"', '').replace('\'', '')
        values = str(values_list).replace('[', '').replace(']', '').replace('"', '')
        query_text = ' INSERT INTO SG4_SEQ_MAIN (' + columns + ') values ( ' + values + ') '
        common.debug_output(query_text)
        db_cursor.execute(query_text)
        seq_full_path = os.path.join(sg_db_filling_directory, seq)
        head, sequence_stuffing = parse_csv(seq_full_path)
        if not head == SG4_SEQ_DETAIL_header:
            common.debug_output("header from csv file: " + str(head))
            common.debug_output("default header for table SG4_SEQ_DETAIL: " + str(SG4_SEQ_DETAIL_header))
            common.debug_output("HEADER from csv file not equal default value")
        module_index = 0
        for seq_mod in sequence_stuffing:
            common.debug_output("Upload sequence module " + seq_mod['MODULE_NAME'] + " to the SG4_SEQ_DETAIL table")
            is_valid = validation_module(seq_mod, full_config_info['processes'])
            if is_valid:
                seq_mod['MODULE_INDEX'] = str(module_index)
                if seq_mod['MODULE_TYPE'] == '3' and seq_mod['VALUE']:
                    seq_mod['VALUE'] = hosts[0] + ":" + seq_mod['VALUE']
                elif seq_mod['MODULE_TYPE'] == '3' and not seq_mod['VALUE']:
                    seq_mod['VALUE'] = hosts[0]
                elif seq_mod['MODULE_TYPE'] == '4' and seq_mod['VALUE'] == 'FLAG_PS_EOD':
                    pricing_exist = False
                    for i in full_config_info['processes']:
                        if re.search('Pricing', i):
                            pricing_exist = True
                            break
                    if pricing_exist:
                        print('Flag FLAG_PS_EOD skipped')
                        continue
                elif seq_mod['MODULE_TYPE'] == '4' and seq_mod['VALUE'] == 'FLAG_SCG_EOD':
                    scoring_exist = False
                    for i in full_config_info['processes']:
                        if re.search('Scoring', i):
                            scoring_exist = True
                            break
                    if scoring_exist:
                        print('Flag FLAG_SCG_EOD skipped')
                        continue

                columns_list = []
                values_list = []
                for tagname in sg4_seq_detail_db_header:
                    tagvalue = '\'' + seq_mod[tagname] + '\''
                    columns_list.append(tagname)
                    values_list.append(tagvalue)
                columns = str(columns_list).replace('[', '').replace(']', '').replace('"', '').replace('\'', '')
                values = str(values_list).replace('[', '').replace(']', '').replace('"', '')
                query_text = ' INSERT INTO SG4_SEQ_DETAIL (' + columns + ') values ( ' + values + ') '
                common.debug_output('Uploading to SG4_SEQ_DETAIL table...')
                common.debug_output(query_text)
                db_cursor.execute(query_text)

                module_index += 1
                common.debug_output("Sequence module " + seq_mod['MODULE_NAME'] + " has been successfully uploaded")
                common.debug_output(" for sequence_name = " + seq_mod['SEQUENCE_NAME'])
            else:
                common.debug_output("STEP UPLOAD TO DETAIL table. Module " + str(seq_mod) + " cannot be uploaded. Skipped")
    db_connect.commit()
